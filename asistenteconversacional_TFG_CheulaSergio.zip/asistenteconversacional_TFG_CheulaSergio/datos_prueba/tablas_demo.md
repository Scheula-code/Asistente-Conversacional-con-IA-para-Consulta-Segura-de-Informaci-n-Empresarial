# Tablas del DWH demo: qué cargar en "Tablas habilitadas"

Esquema `demo`. Columna de área (para el nivel `lectura_area`): `area` en FACT_VENTAS, FACT_STOCK_ALMACEN y
FACT_CUENTA_CORRIENTE; `area_comercial` en DIM_CLIENTE y DIM_ALMACEN. Dejar vacía en el resto.
Los valores de área del DWH son `Comercial Norte` y `Comercial Sur`: el área de cada usuario debe escribirse igual.

| Tabla | Objetivo | Aclaraciones |
|---|---|---|
| DIM_PERIODO | Calendario mensual de los 25 periodos disponibles | `periodo` es el primer día del mes. `es_mes_cerrado = 0` marca el mes en curso, que está incompleto. `meses_atras = 1` es el último mes cerrado. |
| DIM_PRODUCTO | Catálogo de productos farmacéuticos con línea terapéutica, categoría y precio de lista | Categoría: Etico, OTC o Generico. Los productos se nombran por principio activo, dosis y presentación. |
| DIM_CLIENTE | Clientes: droguerías, cadenas de farmacias, hospitales y clínicas, obras sociales y distribuidores | `area_comercial` es Comercial Norte o Comercial Sur. `condicion_pago_dias` define el vencimiento de las facturas. |
| FACT_VENTAS | Ventas mensuales por producto y cliente, con descuentos y contribución marginal | `venta_neta = venta_bruta - descuentos`. `contribucion_marginal` ya viene calculada (venta neta menos costo de ventas). El mes en curso está incompleto: no usarlo para comparar ni proyectar. |
| FACT_PYL_PRODUCTO | Estado de resultados mensual por producto, real y presupuestado | `escenario` es Real o Presupuesto; si el usuario no aclara, usar Real. Resultado operativo = contribución marginal menos gastos comerciales, de marketing, de distribución y de estructura. El escenario Real coincide con FACT_VENTAS. |
| DIM_ALMACEN | Almacenes donde está el stock: propios y en consignación (depósitos ubicados en una droguería) | `tipo_almacen` es Propio o Consignacion. En los de consignación `id_cliente` es la droguería titular del depósito; en los propios es nulo. |
| FACT_STOCK_ALMACEN | Stock de cierre mensual de cada producto en cada almacén | `unidades_disponibles` es lo vendible; `unidades_cuarentena` espera la liberación de calidad y no está disponible. Hay cierres de los últimos 12 meses cerrados; el stock actual es el del último cierre (`meses_atras = 1`). El stock en consignación es el de los almacenes de tipo Consignacion. |
| FACT_CUENTA_CORRIENTE | Movimientos de cuenta corriente de los clientes: facturas, recibos y notas de crédito | Saldo de un cliente = SUM(debe) - SUM(haber). Los recibos y las notas de crédito referencian la factura en `comprobante_ref`. |
| COSTO_UNITARIO | Costo unitario por producto y mes (información sensible) | Tabla restringida: no darla a roles comerciales. |

## Roles de ejemplo (`permisos_demo.csv`)
Crear primero los roles `comercial_todo` y `comercial_ventas_contribucion` en Roles y permisos y después importar el CSV.
- `comercial_todo`: todas las tablas menos COSTO_UNITARIO, y todas las categorías de documentos.
- `comercial_ventas_contribucion`: ventas y contribución solamente; la tabla FACT_VENTAS va acotada al área del usuario
  (`lectura_area`) y la columna `descuentos` está denegada. Documentos de la categoría `Comercial`.
