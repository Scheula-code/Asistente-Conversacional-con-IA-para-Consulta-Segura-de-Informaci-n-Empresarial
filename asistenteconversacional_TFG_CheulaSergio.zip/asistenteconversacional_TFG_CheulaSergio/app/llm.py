"""Acceso al modelo de lenguaje (API de OpenAI) a traves de LangChain.

Comportamiento ante fallas, segun la seccion Disponibilidad del TFG: se reintenta un numero
acotado de veces con espera creciente; si aun asi no hay respuesta se informa que el servicio
no esta disponible, en lugar de devolver un resultado incompleto.
"""
from __future__ import annotations

import logging
import time
from functools import lru_cache
from typing import Callable, TypeVar

import numpy as np

from .config import get_settings

log = logging.getLogger("asistente.llm")
T = TypeVar("T")


class ErrorModelo(Exception):
    """Falla al usar el modelo (configuracion, solicitud invalida, etc.)."""


class ServicioLLMNoDisponible(ErrorModelo):
    """El servicio externo no responde o la salida a internet esta interrumpida."""


def _reintentables() -> tuple[type[BaseException], ...]:
    import openai

    return (openai.APIConnectionError, openai.APITimeoutError, openai.RateLimitError, openai.InternalServerError)


def con_reintentos(fn: Callable[[], T]) -> T:
    s = get_settings()
    if not s.openai_api_key:
        raise ErrorModelo("OPENAI_API_KEY no está configurada.")
    import openai

    espera = 1.0
    for intento in range(1, max(1, s.llm_reintentos) + 1):
        try:
            return fn()
        except _reintentables() as e:
            log.warning("Llamada al modelo fallida (intento %s/%s): %s", intento, s.llm_reintentos, e)
            if intento >= s.llm_reintentos:
                raise ServicioLLMNoDisponible(str(e)) from e
            time.sleep(espera)
            espera *= 2
        except openai.APIError as e:  # autenticacion, solicitud invalida, etc.: no se reintenta
            log.error("Error del modelo: %s", e)
            raise ErrorModelo(str(e)) from e
    raise ServicioLLMNoDisponible("sin respuesta")  # pragma: no cover


def _crear_chat(modelo: str, *, reasoning_effort: str = "", omitir_temperatura: bool = False, temperatura: float = 0.0):
    from langchain_openai import ChatOpenAI

    s = get_settings()

    class _ChatOpenAI(ChatOpenAI):
        def _get_request_payload(self, *args, **kwargs):
            payload = super()._get_request_payload(*args, **kwargs)
            if omitir_temperatura:
                payload.pop("temperature", None)
            return payload

    return _ChatOpenAI(
        model=modelo,
        api_key=s.openai_api_key or "sin-clave",
        temperature=0 if omitir_temperatura else temperatura,
        timeout=s.llm_timeout_s,
        max_retries=0,  # los reintentos los administra con_reintentos()
        extra_body={"reasoning_effort": reasoning_effort} if reasoning_effort else None,
    )


@lru_cache(maxsize=1)
def chat_model():
    """Modelo de chat principal. Dos ajustes opcionales para modelos de razonamiento (por ejemplo la familia GPT-5):
      OPENAI_REASONING_EFFORT=none  -> se envia reasoning_effort (la API lo exige para usar herramientas)
      OPENAI_TEMPERATURE=omitir     -> no se envia temperature (esos modelos pueden rechazarla)
    """
    s = get_settings()
    omitir = s.openai_temperature.strip().lower() in ("omitir", "none", "no")
    return _crear_chat(
        s.openai_model, reasoning_effort=s.openai_reasoning_effort, omitir_temperatura=omitir,
        temperatura=0.0 if omitir else float(s.openai_temperature or 0),
    )


@lru_cache(maxsize=1)
def chat_model_aux():
    """Modelo para tareas cortas (reordenar resultados, resumir documentos). OPENAI_AUX_MODEL vacio = el principal.
    El modelo auxiliar se usa con ajustes estandar (sin reasoning_effort): pensado para modelos como gpt-4o-mini."""
    s = get_settings()
    if not s.openai_aux_model or s.openai_aux_model == s.openai_model:
        return chat_model()
    return _crear_chat(s.openai_aux_model)


@lru_cache(maxsize=1)
def embeddings_model():
    from langchain_openai import OpenAIEmbeddings

    s = get_settings()
    return OpenAIEmbeddings(
        model=s.openai_embedding_model,
        api_key=s.openai_api_key or "sin-clave",
        timeout=s.llm_timeout_s,
        max_retries=0,
        # Evita que langchain descargue el tokenizador (tiktoken) desde internet: los fragmentos
        # ya se acotan por caracteres y quedan muy por debajo del limite del modelo.
        check_embedding_ctx_length=False,
    )


def _normalizar(m: np.ndarray) -> np.ndarray:
    m = np.ascontiguousarray(m, dtype="float32")
    n = np.linalg.norm(m, axis=1, keepdims=True)
    n[n == 0] = 1.0
    return m / n


def embed_documentos(textos: list[str]) -> np.ndarray:
    if not textos:
        return np.zeros((0, get_settings().embedding_dim), dtype="float32")
    vectores = con_reintentos(lambda: embeddings_model().embed_documents(textos))
    return _normalizar(np.array(vectores))


def embed_consulta(texto: str) -> np.ndarray:
    v = con_reintentos(lambda: embeddings_model().embed_query(texto))
    return _normalizar(np.array([v]))[0]
