"""Acceso a SQL Server por pyodbc.

Hay dos conexiones con propositos y credenciales distintos:
  * la base propia del prototipo (lectura/escritura, con DENY de UPDATE/DELETE sobre AUDITORIA);
  * el datawarehouse, con un usuario de SOLO LECTURA (HU-011).
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Iterator, Sequence

from .config import get_settings


def _pyodbc():
    import pyodbc  # import diferido: permite probar la logica sin el driver instalado

    return pyodbc


def _conn_str(server: str, database: str, user: str, password: str, readonly: bool = False) -> str:
    s = get_settings()
    partes = [
        f"DRIVER={{{s.odbc_driver}}}",
        f"SERVER={server}",
        f"DATABASE={database}",
        f"TrustServerCertificate={s.db_trust_cert}",
    ]
    if s.db_trusted:  # autenticacion de Windows (p. ej. LocalDB): sin usuario ni clave
        partes.append("Trusted_Connection=yes")
    else:
        partes += [f"UID={user}", f"PWD={password}"]
    if readonly:
        partes.append("ApplicationIntent=ReadOnly")
    return ";".join(partes)


def conectar_app(autocommit: bool = False):
    s = get_settings()
    return _pyodbc().connect(
        _conn_str(s.app_db_server, s.app_db_name, s.app_db_user, s.app_db_password),
        autocommit=autocommit,
        timeout=15,
    )


def conectar_dwh():
    """Conexion de solo lectura al datawarehouse."""
    s = get_settings()
    conn = _pyodbc().connect(
        _conn_str(s.dwh_server, s.dwh_name, s.dwh_user, s.dwh_password, readonly=True),
        autocommit=True,
        timeout=15,
    )
    conn.timeout = s.sql_timeout_s  # tiempo maximo por consulta
    return conn


def filas_a_dicts(cur) -> list[dict[str, Any]]:
    if cur.description is None:
        return []
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, fila)) for fila in cur.fetchall()]


@contextmanager
def transaccion() -> Iterator[Any]:
    """Cursor sobre la base propia; confirma al salir sin error y revierte si hubo una excepcion."""
    conn = conectar_app()
    try:
        cur = conn.cursor()
        yield cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def consultar(sql: str, params: Sequence[Any] = ()) -> list[dict[str, Any]]:
    with transaccion() as cur:
        cur.execute(sql, params)
        return filas_a_dicts(cur)


def consultar_uno(sql: str, params: Sequence[Any] = ()) -> dict[str, Any] | None:
    filas = consultar(sql, params)
    return filas[0] if filas else None


def ejecutar(sql: str, params: Sequence[Any] = ()) -> int:
    with transaccion() as cur:
        cur.execute(sql, params)
        return cur.rowcount


def insertar(sql: str, params: Sequence[Any] = ()) -> int:
    """INSERT ... OUTPUT INSERTED.<id> ...  devuelve el identificador generado."""
    with transaccion() as cur:
        cur.execute(sql, params)
        return int(cur.fetchone()[0])
