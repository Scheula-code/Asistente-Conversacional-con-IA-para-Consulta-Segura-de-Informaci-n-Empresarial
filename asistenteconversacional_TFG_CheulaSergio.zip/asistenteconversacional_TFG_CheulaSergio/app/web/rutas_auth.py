"""Pantallas de acceso: inicio y cierre de sesion, y cambio de contrasena."""
from __future__ import annotations

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse

from ..config import get_settings
from ..security import auth
from .deps import COOKIE, contexto_base, contexto_opcional, exigir_sesion, ip_cliente, plantillas

router = APIRouter()


def _destino(ctx: auth.Contexto) -> str:
    if ctx.requiere_cambio_clave:
        return "/cambiar-clave"
    return "/admin" if ctx.es_admin else "/"


@router.get("/login")
def login_form(request: Request):
    ctx = contexto_opcional(request)
    if ctx:
        return RedirectResponse(_destino(ctx), status_code=303)
    return plantillas.TemplateResponse(request, "login.html", contexto_base(request, None))


@router.post("/login")
def login(request: Request, email: str = Form(""), clave: str = Form("")):
    try:
        token, ctx = auth.iniciar_sesion(email, clave, ip_cliente(request))
    except auth.ErrorAuth as e:
        return plantillas.TemplateResponse(
            request, "login.html", contexto_base(request, None, mensaje=str(e), email=email), status_code=401
        )
    resp = RedirectResponse(_destino(ctx), status_code=303)
    resp.set_cookie(
        COOKIE, token, httponly=True, samesite="lax", secure=get_settings().cookie_secure, path="/",
    )  # cookie de sesion: se descarta al cerrar el navegador
    return resp


@router.post("/logout")
def logout(request: Request, ctx: auth.Contexto = Depends(exigir_sesion)):
    auth.cerrar_sesion(ctx)
    resp = RedirectResponse("/login", status_code=303)
    resp.delete_cookie(COOKIE, path="/")
    return resp


@router.get("/cambiar-clave")
def cambiar_clave_form(request: Request, ctx: auth.Contexto = Depends(exigir_sesion)):
    s = get_settings()
    return plantillas.TemplateResponse(
        request, "cambiar_clave.html",
        contexto_base(request, ctx, errores=[], min_largo=s.clave_min_largo, historial=s.clave_historial),
    )


@router.post("/cambiar-clave")
def cambiar_clave(
    request: Request,
    actual: str = Form(""), nueva: str = Form(""), confirmacion: str = Form(""),
    ctx: auth.Contexto = Depends(exigir_sesion),
):
    errores = auth.cambiar_clave(ctx, actual, nueva, confirmacion)
    if errores:
        s = get_settings()
        return plantillas.TemplateResponse(
            request, "cambiar_clave.html",
            contexto_base(request, ctx, errores=errores, min_largo=s.clave_min_largo, historial=s.clave_historial),
            status_code=400,
        )
    return RedirectResponse("/admin" if ctx.es_admin else "/", status_code=303)


@router.get("/api/health")
def health():
    """Para el monitoreo: que el servicio responda."""
    return {"estado": "ok"}
