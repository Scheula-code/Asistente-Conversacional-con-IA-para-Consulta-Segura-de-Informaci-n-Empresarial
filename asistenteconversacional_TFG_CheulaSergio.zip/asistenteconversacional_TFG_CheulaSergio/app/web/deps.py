"""Dependencias de FastAPI: sesion por cookie, rol administrador y redirecciones."""
from __future__ import annotations

from pathlib import Path
from urllib.parse import quote

from fastapi import Depends, HTTPException, Request
from fastapi.templating import Jinja2Templates

from ..config import get_settings
from ..security import auth

COOKIE = "asistente_sid"
BASE = Path(__file__).parent
plantillas = Jinja2Templates(directory=str(BASE / "templates"))


class Redireccion(Exception):
    def __init__(self, url: str):
        self.url = url


def ip_cliente(request: Request) -> str | None:
    # No se confia en X-Forwarded-For: si hay un proxy inverso, configurarlo aguas arriba.
    return request.client.host if request.client else None


def contexto_opcional(request: Request) -> auth.Contexto | None:
    if not hasattr(request.state, "ctx"):
        request.state.ctx = auth.contexto_desde_token(request.cookies.get(COOKIE), ip_cliente(request))
    return request.state.ctx


def exigir_sesion(request: Request) -> auth.Contexto:
    ctx = contexto_opcional(request)
    if ctx is None:
        if request.url.path.startswith("/api/") or request.url.path.startswith("/admin/api/"):
            raise HTTPException(status_code=401, detail="Sesión no válida o expirada.")
        raise Redireccion("/login")
    if ctx.requiere_cambio_clave and request.url.path not in ("/cambiar-clave", "/logout"):
        if request.url.path.startswith("/api/"):
            raise HTTPException(status_code=403, detail="Debe cambiar su contraseña.")
        raise Redireccion("/cambiar-clave")
    return ctx


def exigir_admin(ctx: auth.Contexto = Depends(exigir_sesion)) -> auth.Contexto:
    if not ctx.es_admin:
        raise HTTPException(status_code=403, detail="Esta sección es exclusiva del rol de administración.")
    return ctx


def exigir_consultante(request: Request, ctx: auth.Contexto = Depends(exigir_sesion)) -> auth.Contexto:
    """El rol de administracion no consulta informacion de negocio."""
    if not ctx.consulta:
        if request.url.path.startswith("/api/"):
            raise HTTPException(status_code=403, detail="Su usuario no tiene roles de consulta.")
        raise Redireccion("/admin")
    return ctx


def redirigir_con_mensaje(url: str, ok: str | None = None, error: str | None = None) -> str:
    sep = "&" if "?" in url else "?"
    if error:
        return f"{url}{sep}error={quote(error[:300])}"
    if ok:
        return f"{url}{sep}ok={quote(ok[:300])}"
    return url


def contexto_base(request: Request, ctx: auth.Contexto | None, **extra) -> dict:
    return {
        "ctx": ctx,
        "ok": request.query_params.get("ok"),
        "error": request.query_params.get("error"),
        "inactividad_min": get_settings().sesion_inactividad_min,
        **extra,
    }
