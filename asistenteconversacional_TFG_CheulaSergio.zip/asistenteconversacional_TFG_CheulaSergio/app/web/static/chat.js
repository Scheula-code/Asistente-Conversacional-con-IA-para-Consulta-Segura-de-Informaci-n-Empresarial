"use strict";
(function () {
  const hilo = document.getElementById("hilo");
  const form = document.getElementById("form");
  const caja = document.getElementById("pregunta");
  const boton = document.getElementById("enviar");
  const lista = document.getElementById("conversaciones");
  let conversacionActual = null;

  const NF = new Intl.NumberFormat("es-AR", { maximumFractionDigits: 2 });
  const NS = "http://www.w3.org/2000/svg";
  const PALETA = ["#3B4A5C", "#FF0032", "#6C8EAD", "#E8A13A", "#4F9D7A", "#9B6BB5", "#C75C5C", "#2E86AB", "#B0A160", "#7F8C8D", "#5D6D7E", "#D98880"];
  const ETIQUETA_FUENTE = {
    documental: "Fuente: documentos", datos: "Fuente: datawarehouse", mixta: "Fuente: documentos y datawarehouse",
    bloqueada: "Consulta bloqueada", error: "Error", general: "",
  };

  function el(tag, clase, texto) {
    const e = document.createElement(tag);
    if (clase) e.className = clase;
    if (texto !== undefined && texto !== null) e.textContent = texto;
    return e;
  }
  function svgEl(tag, atributos) {
    const e = document.createElementNS(NS, tag);
    Object.keys(atributos || {}).forEach((k) => e.setAttribute(k, atributos[k]));
    return e;
  }
  function texto(svg, x, y, contenido, atributos) {
    const t = svgEl("text", Object.assign({ x, y }, atributos || {}));
    t.textContent = contenido;
    svg.appendChild(t);
    return t;
  }
  function recortar(s, n) { s = String(s); return s.length > n ? s.slice(0, n - 1) + "…" : s; }

  async function api(url, opciones) {
    const r = await fetch(url, Object.assign({ credentials: "same-origin" }, opciones || {}));
    if (r.status === 401) { window.location.href = "/login"; throw new Error("sesion"); }
    const cuerpo = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(cuerpo.detail || "Error " + r.status);
    return cuerpo;
  }

  function fmt(v) {
    if (v === null || v === undefined) return "";
    if (typeof v === "number") return NF.format(v);
    return String(v);
  }

  // ------------------------------------------------------------------ análisis del resultado
  const ES_ID = /(^id$|^id_|_id$|^codigo$|^(mes|trimestre|semestre|dia|semana)$)/i;
  const PARTE_TIEMPO = /^(mes|trimestre|semestre|dia|semana)$/i;
  const NOMBRE_ANIO = /(^|_)(anio|ano|year|periodo|ejercicio)(_|$)|^año$/i;
  const ES_ANIO = /^(19|20|21)\d{2}$/;
  function muestra(datos, i) { return datos.filas.slice(0, 60).map((f) => f[i]).filter((v) => v !== null && v !== undefined); }
  function esNumerica(datos, i) { const m = muestra(datos, i); return m.length > 0 && m.every((v) => typeof v === "number"); }
  function esAnio(datos, i) { const m = muestra(datos, i); return m.length > 0 && NOMBRE_ANIO.test(datos.columnas[i]) && m.every((v) => ES_ANIO.test(String(v))); }
  function esPeriodo(datos, i) {
    const m = muestra(datos, i);
    return m.length > 0 && (m.every((v) => typeof v === "string" && /^\d{4}-\d{2}(-\d{2})?/.test(v)) || esAnio(datos, i));
  }

  function analizar(datos) {
    const cols = datos.columnas;
    const idx = cols.map((_, i) => i);
    const colPeriodo = idx.find((i) => esPeriodo(datos, i));
    const colValor = idx.find((i) => i !== colPeriodo && esNumerica(datos, i) && !ES_ID.test(cols[i]));
    let colEtiqueta = idx.find((i) => i !== colPeriodo && (!esNumerica(datos, i) || PARTE_TIEMPO.test(cols[i])));
    if (colEtiqueta === undefined && colPeriodo !== undefined) colEtiqueta = colPeriodo;
    const periodos = colPeriodo === undefined ? 0 : new Set(datos.filas.map((f) => String(f[colPeriodo]).slice(0, 7))).size;
    return { colPeriodo, colValor, colEtiqueta, periodos, nombreValor: colValor === undefined ? "" : cols[colValor] };
  }

  function agrupar(datos, colEtiqueta, colValor, recortePeriodo) {
    const mapa = new Map();
    datos.filas.forEach((f) => {
      const v = f[colValor];
      if (typeof v !== "number") return;
      let k = f[colEtiqueta];
      k = k === null || k === undefined ? "(sin dato)" : (recortePeriodo ? String(k).slice(0, 7) : String(k));
      mapa.set(k, (mapa.get(k) || 0) + v);
    });
    return Array.from(mapa.entries()).map(([etiqueta, valor]) => ({ etiqueta, valor }));
  }

  function tiposDisponibles(info, datos) {
    const t = [];
    if (info.colValor === undefined) return t;
    const hayEtiqueta = info.colEtiqueta !== undefined && datos.filas.length >= 2;
    if (hayEtiqueta) { t.push("barras"); t.push("torta"); }
    if ((info.colPeriodo !== undefined && info.periodos >= 2) || hayEtiqueta) t.push("linea");
    return t;
  }

  function tipoAutomatico(info, disponibles) {
    if (info.periodos >= 3 && disponibles.includes("linea")) return "linea";
    if (disponibles.includes("barras")) return "barras";
    return disponibles[0] || "tabla";
  }

  // ------------------------------------------------------------------ gráficos
  function nota(textoNota) { return el("div", "pequeno", textoNota); }

  function barras(datos, info) {
    const esTiempo = info.colEtiqueta === info.colPeriodo;
    let items = agrupar(datos, info.colEtiqueta, info.colValor, esTiempo);
    if (!esTiempo) items.sort((a, b) => b.valor - a.valor);
    const total = items.length;
    items = items.slice(0, 15);
    const max = Math.max(...items.map((i) => i.valor), 0) || 1;
    const filaAlto = 24, izq = 190, ancho = 640, derecha = 70, alto = items.length * filaAlto + 12;
    const svg = svgEl("svg", { viewBox: `0 0 ${ancho} ${alto}`, class: "grafico auto", role: "img" });
    svg.setAttribute("aria-label", "Gráfico de barras de " + info.nombreValor);
    items.forEach((it, i) => {
      const y = 6 + i * filaAlto;
      const w = Math.max(1, (it.valor / max) * (ancho - izq - derecha));
      texto(svg, izq - 8, y + 15, recortar(it.etiqueta, 30), { class: "etq", "text-anchor": "end" });
      const r = svgEl("rect", { x: izq, y, width: w, height: filaAlto - 6, class: "barra" });
      const t = svgEl("title"); t.textContent = `${it.etiqueta}: ${NF.format(it.valor)}`; r.appendChild(t);
      svg.appendChild(r);
      texto(svg, izq + w + 6, y + 15, NF.format(it.valor), { class: "etq" });
    });
    const cont = el("div");
    cont.appendChild(svg);
    if (total > 15) cont.appendChild(nota(`Se grafican los 15 mayores de ${total}.`));
    if (!esTiempo && datos.filas.length > total) cont.appendChild(nota("Se suman los valores repetidos de cada categoría (por ejemplo, varios períodos)."));
    return cont;
  }

  function torta(datos, info) {
    const esTiempo = info.colEtiqueta === info.colPeriodo;
    let items = agrupar(datos, info.colEtiqueta, info.colValor, esTiempo).filter((i) => i.valor > 0);
    if (!items.length) return nota("No se puede graficar en torta: no hay valores positivos.");
    items.sort((a, b) => b.valor - a.valor);
    if (items.length > 12) {
      const resto = items.slice(11).reduce((s, i) => s + i.valor, 0);
      items = items.slice(0, 11).concat([{ etiqueta: "Otros", valor: resto }]);
    }
    const suma = items.reduce((s, i) => s + i.valor, 0);
    const cx = 130, cy = 130, r = 112;
    const alto = Math.max(260, items.length * 22 + 20);
    const svg = svgEl("svg", { viewBox: `0 0 640 ${alto}`, class: "grafico auto", role: "img" });
    svg.setAttribute("aria-label", "Gráfico de torta de " + info.nombreValor);
    let ang = -Math.PI / 2;
    items.forEach((it, i) => {
      const color = PALETA[i % PALETA.length];
      const frac = it.valor / suma;
      let forma;
      if (items.length === 1 || frac >= 0.9999) {
        forma = svgEl("circle", { cx, cy, r, fill: color });
      } else {
        const fin = ang + frac * 2 * Math.PI;
        const x1 = cx + r * Math.cos(ang), y1 = cy + r * Math.sin(ang);
        const x2 = cx + r * Math.cos(fin), y2 = cy + r * Math.sin(fin);
        forma = svgEl("path", { d: `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${frac > 0.5 ? 1 : 0} 1 ${x2} ${y2} Z`, fill: color, stroke: "#fff", "stroke-width": 1.5 });
        ang = fin;
      }
      const t = svgEl("title"); t.textContent = `${it.etiqueta}: ${NF.format(it.valor)} (${NF.format(frac * 100)} %)`;
      forma.appendChild(t); svg.appendChild(forma);
      const y = 22 + i * 22;
      svg.appendChild(svgEl("rect", { x: 270, y: y - 11, width: 12, height: 12, fill: color }));
      texto(svg, 290, y, `${recortar(it.etiqueta, 26)} · ${NF.format(it.valor)} (${NF.format(frac * 100)} %)`, { class: "etq" });
    });
    const cont = el("div");
    cont.appendChild(svg);
    if (!esTiempo && datos.filas.length > new Set(datos.filas.map((f) => String(f[info.colEtiqueta]))).size) {
      cont.appendChild(nota("Se suman los valores repetidos de cada categoría (por ejemplo, varios períodos)."));
    }
    return cont;
  }

  function trazar(pts, info, nReal, etiquetasX) {
    const W = 640, H = 170, m = 34;
    const ys = pts.map((p) => p.y), min = Math.min(...ys), max = Math.max(...ys), rango = max - min || 1;
    const px = (i) => m + (i * (W - 2 * m)) / (pts.length - 1);
    const py = (y) => H - m - ((y - min) / rango) * (H - 2 * m);
    const svg = svgEl("svg", { viewBox: `0 0 ${W} ${H}`, class: "grafico", role: "img" });
    svg.setAttribute("aria-label", "Gráfico de línea de " + info.nombreValor);
    texto(svg, 4, py(max) + 4, NF.format(max), { "text-anchor": "start" });
    texto(svg, 4, py(min) + 4, NF.format(min), { "text-anchor": "start" });
    svg.appendChild(svgEl("polyline", { class: "linea", points: pts.slice(0, nReal).map((p, i) => `${px(i)},${py(p.y)}`).join(" ") }));
    if (nReal < pts.length) {
      svg.appendChild(svgEl("polyline", { class: "linea", "stroke-dasharray": "5 4", points: pts.slice(nReal - 1).map((p, i) => `${px(nReal - 1 + i)},${py(p.y)}`).join(" ") }));
    }
    pts.forEach((p, i) => {
      const c = svgEl("circle", { cx: px(i), cy: py(p.y), r: p.proy ? 3.5 : 2.5, class: "punto" });
      const t = svgEl("title"); t.textContent = `${p.x}: ${NF.format(p.y)}${p.proy ? " (proyección)" : ""}`;
      c.appendChild(t); svg.appendChild(c);
    });
    [0, Math.floor((pts.length - 1) / 2), pts.length - 1].forEach((i, k) => {
      texto(svg, px(i), H - 8, recortar(pts[i].x, 16), { "text-anchor": k === 0 ? "start" : k === 2 ? "end" : "middle" });
    });
    return svg;
  }

  function lineaSerie(datos, info) {
    const reales = agrupar(datos, info.colPeriodo, info.colValor, true).sort((a, b) => (a.etiqueta < b.etiqueta ? -1 : 1));
    const pts = reales.map((p) => ({ x: p.etiqueta, y: p.valor, proy: false }));
    const proy = datos.proyeccion && datos.proyeccion.proyectable ? datos.proyeccion.proyeccion : [];
    proy.forEach((p) => pts.push({ x: p.periodo, y: p.valor, proy: true }));
    if (pts.length < 2) return nota("No hay suficientes períodos para dibujar una línea.");
    const cont = el("div");
    cont.appendChild(trazar(pts, info, reales.length));
    if (datos.filas.length > reales.length && info.colEtiqueta !== undefined && info.colEtiqueta !== info.colPeriodo) {
      cont.appendChild(nota("Suma de todas las categorías por período."));
    }
    return cont;
  }

  function lineaCategorias(datos, info) {
    const items = agrupar(datos, info.colEtiqueta, info.colValor, false);
    if (items.length < 2) return nota("No hay suficientes categorías para dibujar una línea.");
    const cont = el("div");
    cont.appendChild(trazar(items.map((i) => ({ x: i.etiqueta, y: i.valor, proy: false })), info, items.length));
    cont.appendChild(nota("Este resultado no tiene una evolución en el tiempo: la línea une las categorías en el orden de la tabla. Para ver la evolución, pedí por ejemplo «evolución mensual de …»."));
    return cont;
  }

  function lineaMulti(datos, info) {
    const periodos = Array.from(new Set(datos.filas.map((f) => String(f[info.colPeriodo]).slice(0, 7)))).sort();
    const grupos = new Map();
    datos.filas.forEach((f) => {
      const v = f[info.colValor];
      if (typeof v !== "number") return;
      const g = f[info.colEtiqueta] === null || f[info.colEtiqueta] === undefined ? "(sin dato)" : String(f[info.colEtiqueta]);
      const per = String(f[info.colPeriodo]).slice(0, 7);
      if (!grupos.has(g)) grupos.set(g, new Map());
      grupos.get(g).set(per, (grupos.get(g).get(per) || 0) + v);
    });
    const totales = Array.from(grupos.entries()).map(([g, m]) => [g, Array.from(m.values()).reduce((a, b) => a + b, 0)]).sort((a, b) => b[1] - a[1]);
    const elegidos = totales.slice(0, 6).map((t) => t[0]);
    const todos = [];
    elegidos.forEach((g) => grupos.get(g).forEach((v) => todos.push(v)));
    const min = Math.min(...todos), max = Math.max(...todos), rango = max - min || 1;
    const W = 640, m = 34, H = 170, alto = H + 22 * Math.ceil(elegidos.length / 2) + 6;
    const px = (i) => m + (i * (W - 2 * m)) / (periodos.length - 1);
    const py = (y) => H - m - ((y - min) / rango) * (H - 2 * m);
    const svg = svgEl("svg", { viewBox: `0 0 ${W} ${alto}`, class: "grafico auto", role: "img" });
    svg.setAttribute("aria-label", "Evolución de " + info.nombreValor + " por " + datos.columnas[info.colEtiqueta]);
    texto(svg, 4, py(max) + 4, NF.format(max), { "text-anchor": "start" });
    texto(svg, 4, py(min) + 4, NF.format(min), { "text-anchor": "start" });
    elegidos.forEach((g, k) => {
      const color = PALETA[k % PALETA.length];
      const puntos = [];
      periodos.forEach((per, i) => { if (grupos.get(g).has(per)) puntos.push({ i, per, v: grupos.get(g).get(per) }); });
      svg.appendChild(svgEl("polyline", { points: puntos.map((p) => `${px(p.i)},${py(p.v)}`).join(" "), fill: "none", stroke: color, "stroke-width": 2 }));
      puntos.forEach((p) => {
        const c = svgEl("circle", { cx: px(p.i), cy: py(p.v), r: 2.5, fill: color });
        const t = svgEl("title"); t.textContent = `${g} · ${p.per}: ${NF.format(p.v)}`;
        c.appendChild(t); svg.appendChild(c);
      });
      const lx = k % 2 === 0 ? 10 : 330, ly = H + 14 + Math.floor(k / 2) * 22;
      svg.appendChild(svgEl("rect", { x: lx, y: ly - 10, width: 12, height: 12, fill: color }));
      texto(svg, lx + 18, ly, recortar(g, 34), { class: "etq" });
    });
    [0, Math.floor((periodos.length - 1) / 2), periodos.length - 1].forEach((i, k) => {
      texto(svg, px(i), H - 8, periodos[i], { "text-anchor": k === 0 ? "start" : k === 2 ? "end" : "middle" });
    });
    const cont = el("div");
    cont.appendChild(svg);
    if (totales.length > 6) cont.appendChild(nota(`Se grafican las 6 series de mayor total de ${totales.length}.`));
    return cont;
  }

  function linea(datos, info) {
    const esSerie = info.colPeriodo !== undefined && info.periodos >= 2;
    if (!esSerie) return lineaCategorias(datos, info);
    const grupos = info.colEtiqueta !== undefined && info.colEtiqueta !== info.colPeriodo
      ? new Set(datos.filas.map((f) => String(f[info.colEtiqueta]))).size : 0;
    return grupos >= 2 ? lineaMulti(datos, info) : lineaSerie(datos, info);
  }

  function dibujar(tipo, datos, info) {
    if (tipo === "barras") return barras(datos, info);
    if (tipo === "torta") return torta(datos, info);
    if (tipo === "linea") return linea(datos, info);
    return null;
  }

  // ------------------------------------------------------------------ resultado
  function resultado(datos, idMensaje) {
    const caja = el("div", "resultado");
    const info = analizar(datos);
    const disponibles = tiposDisponibles(info, datos);
    const pedido = datos.grafico || "auto";
    if (pedido !== "ninguno") {
      const tipo = pedido === "auto" ? (disponibles.length ? tipoAutomatico(info, disponibles) : null) : pedido;
      if (tipo && !disponibles.includes(tipo)) {
        caja.appendChild(nota("No se puede dibujar el gráfico pedido con este resultado: hace falta una categoría (o un período) y un valor numérico."));
      } else if (tipo) {
        const nodo = dibujar(tipo, datos, info);
        if (nodo) caja.appendChild(nodo);
      }
    }

    const scroll = el("div", "tabla-scroll");
    const tabla = el("table");
    const cab = el("tr");
    datos.columnas.forEach((c) => cab.appendChild(el("th", null, c)));
    const thead = el("thead"); thead.appendChild(cab); tabla.appendChild(thead);
    const tb = el("tbody");
    const anios = datos.columnas.map((_, i) => esAnio(datos, i));   // un año se muestra 2025, no 2.025
    datos.filas.slice(0, 200).forEach((f) => {
      const tr = el("tr");
      f.forEach((v, j) => tr.appendChild(el("td", typeof v === "number" && !anios[j] ? "num" : null, anios[j] ? String(v) : fmt(v))));
      tb.appendChild(tr);
    });
    tabla.appendChild(tb); scroll.appendChild(tabla); caja.appendChild(scroll);
    if (datos.filas.length > 200 || datos.truncado) {
      caja.appendChild(el("div", "pequeno", "Se muestran las primeras filas; el resultado completo es más extenso."));
    }
    const p = datos.proyeccion;
    if (p) {
      const d = el("div", "proyeccion");
      if (p.proyectable) {
        d.appendChild(el("strong", null, "Proyección (estimación). "));
        d.appendChild(document.createTextNode(
          `Regla: ${p.regla}. Base: ${p.periodo_base}. ` +
          p.proyeccion.map((x) => `${x.periodo}: ${NF.format(x.valor)}`).join(" · ") +
          ` · Total del horizonte: ${NF.format(p.total_horizonte)}.`));
      } else {
        d.appendChild(el("strong", null, "Sin proyección. "));
        d.appendChild(document.createTextNode(p.motivo || ""));
      }
      caja.appendChild(d);
    }
    if (datos.sql) {
      const det = el("details");
      det.appendChild(el("summary", "pequeno", "Ver la consulta ejecutada"));
      det.appendChild(el("pre", "sql", datos.sql));
      caja.appendChild(det);
    }
    if (idMensaje) {
      const bajar = el("a", "boton sec chico", "Descargar Excel");
      bajar.href = "/api/mensajes/" + idMensaje + "/excel";
      bajar.setAttribute("download", "");
      bajar.title = "Tabla, gráfico y datos de la consulta en un archivo de Excel";
      caja.appendChild(bajar);
    }
    caja.appendChild(el("div", "pie", "Consulta ejecutada en modo solo lectura y registrada en la auditoría."));
    return caja;
  }

  function citas(listaCitas) {
    const d = el("div", "citas");
    d.appendChild(el("strong", null, "Documentos citados"));
    const ul = el("ul");
    listaCitas.forEach((c) => {
      const li = el("li");
      let t = `[${c.n}] ${c.codigo} v${c.version} — ${c.titulo}`;
      if (c.seccion) t += ` — ${c.seccion}`;
      if (c.pagina) t += ` (pág. ${c.pagina})`;
      // la cita abre el PDF original en una pestaña nueva, en la página citada
      const enlace = el("a", null, t);
      enlace.href = "/documentos/" + encodeURIComponent(c.codigo) + "/" + encodeURIComponent(c.version) + (c.pagina ? "#page=" + c.pagina : "");
      enlace.target = "_blank";
      enlace.rel = "noopener";
      enlace.title = "Abrir el documento" + (c.pagina ? " en la página " + c.pagina : "");
      li.appendChild(enlace);
      if (c.advertencia) { li.appendChild(document.createTextNode(" ")); li.appendChild(el("span", "etiqueta aviso", c.advertencia)); }
      ul.appendChild(li);
    });
    d.appendChild(ul);
    return d;
  }

  function pintar(emisor, textoMsg, detalle, idMensaje) {
    const d = detalle || {};
    const m = el("div", "msg " + emisor + (d.fuente === "bloqueada" ? " bloqueada" : ""));
    const b = el("div", "burbuja", textoMsg);
    m.appendChild(b);
    if (emisor === "asistente") {
      if (d.citas && d.citas.length) b.appendChild(citas(d.citas));
      if (d.datos) b.appendChild(resultado(d.datos, idMensaje));
      const f = ETIQUETA_FUENTE[d.fuente] || "";
      if (f) { const pie = el("div", "fuente"); pie.appendChild(el("span", "etiqueta", f)); m.appendChild(pie); }
    }
    hilo.appendChild(m);
    hilo.scrollTop = hilo.scrollHeight;
    return m;
  }

  async function cargarLista() {
    try {
      const cs = await api("/api/conversaciones");
      lista.replaceChildren();
      cs.forEach((c) => {
        const b = el("button", "item" + (c.id === conversacionActual ? " activo" : ""), c.titulo);
        b.type = "button"; b.title = c.titulo;
        b.addEventListener("click", () => abrir(c.id));
        lista.appendChild(b);
      });
    } catch (e) { /* la sesión vencida redirige sola */ }
  }

  async function abrir(id) {
    const msgs = await api("/api/conversaciones/" + id);
    conversacionActual = id;
    hilo.replaceChildren();
    msgs.forEach((m) => pintar(m.emisor, m.texto, m.detalle, m.id_mensaje));
    cargarLista();
  }

  function nueva() {
    conversacionActual = null;
    hilo.replaceChildren();
    pintar("asistente", "Hola. Puede preguntarme por un procedimiento o por un dato de negocio. Yo decido dónde buscar, dentro de los permisos de su rol.", {});
    cargarLista();
    caja.focus();
  }

  async function enviar(ev) {
    ev.preventDefault();
    const pregunta = caja.value.trim();
    if (!pregunta) return;
    pintar("usuario", pregunta);
    caja.value = "";
    boton.disabled = true;
    const espera = pintar("asistente", "Buscando…");
    espera.querySelector(".burbuja").classList.add("pensando");
    try {
      const r = await api("/api/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pregunta, id_conversacion: conversacionActual }),
      });
      espera.remove();
      const primera = conversacionActual === null;
      conversacionActual = r.id_conversacion;
      pintar("asistente", r.texto, { fuente: r.fuente, citas: r.citas, datos: r.datos }, r.id_mensaje);
      if (primera) cargarLista();
    } catch (e) {
      espera.remove();
      pintar("asistente", "No se pudo completar la consulta: " + e.message, { fuente: "error" });
    } finally {
      boton.disabled = false;
      caja.focus();
    }
  }

  caja.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); }
  });
  form.addEventListener("submit", enviar);
  document.getElementById("nueva").addEventListener("click", nueva);
  nueva();
})();
