"""Pantalla de consulta (Figuras 6 y 7) y su API."""
from __future__ import annotations

import json
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field

from .. import exportar, orquestador, repo
from ..config import get_settings
from ..rag import servicio as servicio_rag
from ..security.auth import Contexto, auditar
from .deps import contexto_base, exigir_consultante, plantillas

router = APIRouter()


class PreguntaIn(BaseModel):
    pregunta: str = Field(min_length=1, max_length=orquestador.MAX_PREGUNTA)
    id_conversacion: int | None = None


@router.get("/")
def pantalla(request: Request, ctx: Contexto = Depends(exigir_consultante)):
    return plantillas.TemplateResponse(request, "chat.html", contexto_base(request, ctx))


@router.get("/api/conversaciones")
def conversaciones(ctx: Contexto = Depends(exigir_consultante)):
    return [
        {"id": c["id_conversacion"], "titulo": c["titulo"], "fecha": c["fecha_inicio"].isoformat()}
        for c in repo.listar_conversaciones(ctx.id_usuario)
    ]


@router.get("/api/conversaciones/{id_conversacion}")
def conversacion(id_conversacion: int, ctx: Contexto = Depends(exigir_consultante)):
    """Recupera una conversacion anterior (HU-014). Las advertencias de version se recalculan al mostrarla."""
    if not repo.conversacion_de_usuario(id_conversacion, ctx.id_usuario):
        raise HTTPException(status_code=404, detail="Conversación no encontrada.")
    salida = []
    for m in repo.mensajes_de_conversacion(id_conversacion):
        detalle = json.loads(m["detalle_json"]) if m["detalle_json"] else {}
        if not get_settings().mostrar_sql and detalle.get("datos"):
            detalle["datos"].pop("sql", None)   # conversaciones guardadas antes del cambio: tampoco muestran el SQL
        for c in detalle.get("citas") or []:
            c["advertencia"] = servicio_rag.advertencia_version(c["codigo"], c["version"])
        salida.append({"id_mensaje": m["id_mensaje"], "emisor": m["emisor"], "texto": m["texto"], "fecha": m["fecha"].isoformat(), "detalle": detalle})
    return salida


@router.get("/api/mensajes/{id_mensaje}/excel")
def descargar_excel(id_mensaje: int, ctx: Contexto = Depends(exigir_consultante)):
    """Descarga en Excel el resultado de una respuesta del asistente: tabla, grafico pedido y datos de la consulta.
    Sale de lo que el usuario ya vio (guardado en el mensaje): no se vuelve a ejecutar nada contra el datawarehouse.
    Solo se pueden bajar resultados de las propias conversaciones, y cada descarga queda en la auditoria."""
    m = repo.mensaje_de_usuario(id_mensaje, ctx.id_usuario)
    if not m or not m["detalle_json"]:
        raise HTTPException(status_code=404, detail="No se encontró el resultado.")
    datos = (json.loads(m["detalle_json"]) or {}).get("datos")
    if not datos or not datos.get("columnas"):
        raise HTTPException(status_code=404, detail="Esa respuesta no tiene una tabla de resultados para descargar.")
    ahora = datetime.now()
    contenido = exportar.a_excel(
        datos, pregunta=repo.pregunta_previa(m["id_conversacion"], id_mensaje) or "", usuario=ctx.email,
        roles=ctx.rol_nombre, fecha=ahora, mostrar_sql=get_settings().mostrar_sql,
    )
    auditar("DESCARGA", "ok", ctx, detalle=f"mensaje {id_mensaje}: {len(datos.get('filas') or [])} filas a Excel")
    return Response(
        content=contenido,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="consulta_{id_mensaje}_{ahora:%Y%m%d_%H%M}.xlsx"'},
    )


@router.post("/api/chat")
def chat(entrada: PreguntaIn, ctx: Contexto = Depends(exigir_consultante)):
    try:
        r = orquestador.responder(ctx, entrada.pregunta, entrada.id_conversacion)
    except orquestador.ConversacionInexistente:
        raise HTTPException(status_code=404, detail="Conversación no encontrada.")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {
        "id_conversacion": r.id_conversacion, "id_mensaje": r.id_mensaje, "texto": r.texto, "fuente": r.fuente,
        "estado": r.estado, "citas": r.citas, "datos": r.datos,
    }
