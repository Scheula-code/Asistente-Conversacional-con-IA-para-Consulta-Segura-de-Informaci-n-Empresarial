"""Pantallas del rol de administracion (Figura 8 y complementarias)."""
from __future__ import annotations

import csv
import io
import shutil
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.responses import RedirectResponse, Response

from .. import admin_servicio as adm
from .. import repo
from ..config import get_settings
from ..datos import esquema as esquema_mod
from ..rag import servicio as servicio_rag
from ..rag.indice import obtener_indice
from ..security.auth import Contexto
from .deps import contexto_base, exigir_admin, plantillas, redirigir_con_mensaje

router = APIRouter(prefix="/admin")


def _ir(url: str, ok: str | None = None, error: str | None = None) -> RedirectResponse:
    return RedirectResponse(redirigir_con_mensaje(url, ok, error), status_code=303)


def _csv_seguro(v) -> str:
    """Evita la inyeccion de formulas al abrir el CSV en Excel."""
    s = "" if v is None else str(v)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s


def _csv_respuesta(nombre: str, encabezados: list[str], filas: list[list]) -> Response:
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(encabezados)
    for f in filas:
        w.writerow([_csv_seguro(c) for c in f])
    return Response(
        content=("\ufeff" + buf.getvalue()).encode("utf-8"),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{nombre}"'},
    )


@router.get("")
def inicio(ctx: Contexto = Depends(exigir_admin)):
    return _ir("/admin/documentos")


# ============================================================================ documentos
def _pagina_documentos(request: Request, ctx: Contexto, resultados: list[dict] | None = None):
    return plantillas.TemplateResponse(
        request, "admin/documentos.html",
        contexto_base(
            request, ctx, seccion="documentos", documentos=repo.listar_documentos(), resultados=resultados or [],
            tipos=servicio_rag.TIPOS, categorias=repo.listar_categorias(), vectores=obtener_indice().total,
        ),
    )


@router.get("/documentos")
def documentos(request: Request, ctx: Contexto = Depends(exigir_admin)):
    return _pagina_documentos(request, ctx)


@router.post("/documentos/subir")
def subir_documentos(
    request: Request,
    archivos: list[UploadFile] = File(...),
    tipo: str = Form("SOP"), categoria: str = Form(""), version: str = Form("1"),
    ctx: Contexto = Depends(exigir_admin),
):
    resultados = []
    for f in archivos:
        nombre = f.filename or "sin_nombre.pdf"
        if not f.filename:
            continue
        try:
            r = servicio_rag.registrar(
                f.file.read(), nombre, codigo=Path(nombre).stem, titulo=None, tipo=tipo, version=version,
                categoria=categoria, ctx=ctx,
            )
            msg = "Indexado." if r["indexado"] else f"Registrado, pero NO indexado: {r['error']}"
            if r["retiradas"]:
                msg += f" Se retiró del índice la versión anterior ({', '.join(r['retiradas'])})."
            resultados.append({"archivo": nombre, "ok": r["indexado"], "mensaje": msg})
        except servicio_rag.ErrorDocumento as e:
            resultados.append({"archivo": nombre, "ok": False, "mensaje": str(e)})
    return _pagina_documentos(request, ctx, resultados)


@router.post("/documentos/{id_documento}/reindexar")
def reindexar(id_documento: int, ctx: Contexto = Depends(exigir_admin)):
    try:
        n = servicio_rag.indexar_documento(id_documento, ctx)
        return _ir("/admin/documentos", ok=f"Documento reindexado ({n} fragmentos).")
    except servicio_rag.ErrorDocumento as e:
        return _ir("/admin/documentos", error=str(e))


@router.post("/documentos/{id_documento}/baja")
def baja(id_documento: int, ctx: Contexto = Depends(exigir_admin)):
    try:
        servicio_rag.dar_de_baja(id_documento, ctx)
        return _ir("/admin/documentos", ok="Documento dado de baja: sus fragmentos dejan de recuperarse.")
    except servicio_rag.ErrorDocumento as e:
        return _ir("/admin/documentos", error=str(e))


@router.get("/documentos/{id_documento}/editar")
def editar_documento_form(id_documento: int, request: Request, ctx: Contexto = Depends(exigir_admin)):
    d = repo.documento_por_id(id_documento)
    if not d:
        return _ir("/admin/documentos", error="El documento no existe.")
    return plantillas.TemplateResponse(
        request, "admin/documento_editar.html",
        contexto_base(request, ctx, seccion="documentos", d=d, tipos=servicio_rag.TIPOS, categorias=repo.listar_categorias()),
    )


@router.post("/documentos/{id_documento}/editar")
def editar_documento(
    id_documento: int,
    titulo: str = Form(""), tipo: str = Form("SOP"), categoria: str = Form(""),
    proceso_replicado: str = Form(""), capacidad_validada: str = Form(""),
    ctx: Contexto = Depends(exigir_admin),
):
    try:
        servicio_rag.actualizar_metadatos(
            id_documento, titulo=titulo, tipo=tipo, categoria=categoria,
            proceso_replicado=proceso_replicado, capacidad_validada=capacidad_validada, ctx=ctx,
        )
        return _ir("/admin/documentos", ok="Documento actualizado.")
    except servicio_rag.ErrorDocumento as e:
        return _ir(f"/admin/documentos/{id_documento}/editar", error=str(e))


@router.post("/documentos/reindexar-todo")
def reindexar_todo(ctx: Contexto = Depends(exigir_admin)):
    r = servicio_rag.reindexar_todo(ctx)
    if r["errores"]:
        return _ir("/admin/documentos", error=f"{r['indexados']} indexados; con error: " + " | ".join(r["errores"][:5]))
    return _ir("/admin/documentos", ok=f"Índice reconstruido: {r['indexados']} documentos.")


@router.get("/documentos/registro.csv")
def registro_documentos(ctx: Contexto = Depends(exigir_admin)):
    """Registro documento por documento del conjunto de validacion (codigo, version, fecha, proceso, capacidad)."""
    filas = [
        [d["codigo"], d["version"], d["fecha_alta"].strftime("%d/%m/%Y"), d["titulo"], servicio_rag.TIPOS.get(d["tipo"], d["tipo"]),
         d["categoria"], d["proceso_replicado"], d["capacidad_validada"],
         "sí" if d["vigente"] else "no", "sí" if d["indexado"] else "no", d["fragmentos"]]
        for d in repo.listar_documentos()
    ]
    return _csv_respuesta(
        "registro_documentos.csv",
        ["Código", "Versión", "Fecha de alta", "Título", "Tipo", "Categoría",
         "Proceso que replica", "Capacidad que permite validar", "Vigente", "Indexado", "Fragmentos"],
        filas,
    )


# ============================================================================ usuarios
def _pagina_usuarios(request: Request, ctx: Contexto, **extra):
    return plantillas.TemplateResponse(
        request, "admin/usuarios.html",
        contexto_base(request, ctx, seccion="usuarios", usuarios=repo.listar_usuarios(), roles=repo.listar_roles(), **extra),
    )


@router.get("/usuarios")
def usuarios(request: Request, ctx: Contexto = Depends(exigir_admin)):
    return _pagina_usuarios(request, ctx)


@router.post("/usuarios")
def crear_usuario(
    request: Request, nombre: str = Form(""), email: str = Form(""), area: str = Form(""), ids_roles: list[int] = Form(default=[]),
    ctx: Contexto = Depends(exigir_admin),
):
    try:
        _, temporal = adm.crear_usuario(ctx, nombre, email, area, ids_roles)
    except adm.ErrorAdmin as e:
        return _ir("/admin/usuarios", error=str(e))
    # La clave temporal se muestra una unica vez, en esta respuesta; no se guarda en ningun otro lado.
    return _pagina_usuarios(request, ctx, clave_temporal=temporal, usuario_temporal=email.strip().lower())


@router.post("/usuarios/{id_usuario}/editar")
def editar_usuario(
    id_usuario: int, nombre: str = Form(""), area: str = Form(""), ids_roles: list[int] = Form(default=[]), activo: str | None = Form(None),
    ctx: Contexto = Depends(exigir_admin),
):
    try:
        adm.actualizar_usuario(ctx, id_usuario, nombre, area, ids_roles, activo is not None)
        return _ir("/admin/usuarios", ok="Usuario actualizado. El cambio rige desde su próxima consulta.")
    except adm.ErrorAdmin as e:
        return _ir("/admin/usuarios", error=str(e))


@router.post("/usuarios/{id_usuario}/desbloquear")
def desbloquear(id_usuario: int, ctx: Contexto = Depends(exigir_admin)):
    try:
        adm.desbloquear(ctx, id_usuario)
        return _ir("/admin/usuarios", ok="Cuenta habilitada nuevamente.")
    except adm.ErrorAdmin as e:
        return _ir("/admin/usuarios", error=str(e))


@router.post("/usuarios/{id_usuario}/reset-clave")
def reset_clave(id_usuario: int, request: Request, ctx: Contexto = Depends(exigir_admin)):
    try:
        temporal = adm.resetear_clave(ctx, id_usuario)
    except adm.ErrorAdmin as e:
        return _ir("/admin/usuarios", error=str(e))
    u = repo.usuario_por_id(id_usuario)
    return _pagina_usuarios(request, ctx, clave_temporal=temporal, usuario_temporal=u["email"] if u else "")


# ============================================================================ roles y permisos (Figura 8)
@router.get("/roles")
def roles(request: Request, id_rol: int | None = None, ctx: Contexto = Depends(exigir_admin)):
    todos = repo.listar_roles()
    consultables = [r for r in todos if r["codigo"].lower() != "administracion"]
    elegido = next((r for r in consultables if r["id_rol"] == id_rol), consultables[0] if consultables else None)
    return plantillas.TemplateResponse(
        request, "admin/roles.html",
        contexto_base(
            request, ctx, seccion="roles", roles=consultables, rol=elegido,
            resumen=adm.resumen_rol(elegido["id_rol"]) if elegido else None, tablas=repo.listar_tablas(),
            categorias=repo.listar_categorias(),
        ),
    )


@router.post("/roles/nuevo")
def nuevo_rol(codigo: str = Form(""), descripcion: str = Form(""), ctx: Contexto = Depends(exigir_admin)):
    try:
        id_rol = adm.crear_rol(ctx, codigo, descripcion)
        return _ir(f"/admin/roles?id_rol={id_rol}", ok="Rol creado. Asígnele categorías de documentos y tablas.")
    except adm.ErrorAdmin as e:
        return _ir("/admin/roles", error=str(e))


@router.post("/roles/{id_rol}/editar")
def editar_rol(id_rol: int, descripcion: str = Form(""), ctx: Contexto = Depends(exigir_admin)):
    try:
        adm.actualizar_rol(ctx, id_rol, descripcion)
        return _ir(f"/admin/roles?id_rol={id_rol}", ok="Rol actualizado.")
    except adm.ErrorAdmin as e:
        return _ir(f"/admin/roles?id_rol={id_rol}", error=str(e))


@router.post("/roles/{id_rol}/eliminar")
def eliminar_rol(id_rol: int, ctx: Contexto = Depends(exigir_admin)):
    try:
        adm.eliminar_rol(ctx, id_rol)
        return _ir("/admin/roles", ok="Rol eliminado.")
    except adm.ErrorAdmin as e:
        return _ir(f"/admin/roles?id_rol={id_rol}", error=str(e))


@router.post("/roles/permiso")
def agregar_permiso(
    id_rol: int = Form(...), tipo_recurso: str = Form(...), recurso: str = Form(""), nivel_acceso: str = Form(...),
    origen: str = Form("manual"), ctx: Contexto = Depends(exigir_admin),
):
    try:
        adm.guardar_permiso(ctx, id_rol, tipo_recurso, recurso, nivel_acceso, origen)
        return _ir(f"/admin/roles?id_rol={id_rol}", ok="Permiso guardado. Rige desde la próxima consulta.")
    except adm.ErrorAdmin as e:
        return _ir(f"/admin/roles?id_rol={id_rol}", error=str(e))


@router.post("/roles/permiso/{id_permiso}/quitar")
def quitar_permiso(id_permiso: int, id_rol: int = Form(...), ctx: Contexto = Depends(exigir_admin)):
    try:
        adm.quitar_permiso(ctx, id_permiso)
        return _ir(f"/admin/roles?id_rol={id_rol}", ok="Permiso quitado.")
    except adm.ErrorAdmin as e:
        return _ir(f"/admin/roles?id_rol={id_rol}", error=str(e))


@router.post("/roles/importar")
def importar_permisos(
    archivo: UploadFile = File(...), reemplazar: str | None = Form(None), ctx: Contexto = Depends(exigir_admin),
):
    try:
        r = adm.importar_permisos_csv(ctx, archivo.file.read(), reemplazar is not None)
        return _ir("/admin/roles", ok=f"Importados {r['importados']} permisos ({r['reemplazados']} reemplazados).")
    except adm.ErrorAdmin as e:
        return _ir("/admin/roles", error=str(e))


# ============================================================================ tablas habilitadas
@router.get("/tablas")
def tablas(request: Request, ctx: Contexto = Depends(exigir_admin)):
    return plantillas.TemplateResponse(
        request, "admin/tablas.html", contexto_base(request, ctx, seccion="tablas", tablas=repo.listar_tablas())
    )


@router.post("/tablas")
def crear_tabla(
    esquema: str = Form(""), nombre_tabla: str = Form(""), objetivo: str = Form(""),
    aclaraciones: str = Form(""), filtro_registros: str = Form(""), ctx: Contexto = Depends(exigir_admin),
):
    try:
        id_tabla = adm.crear_tabla(ctx, esquema, nombre_tabla, objetivo, aclaraciones, filtro_registros)
        return _ir(f"/admin/tablas/{id_tabla}", ok="Tabla declarada. Revise el esquema leído y cargue los permisos del rol.")
    except adm.ErrorAdmin as e:
        return _ir("/admin/tablas", error=str(e))


@router.get("/tablas/{id_tabla}")
def tabla_detalle(id_tabla: int, request: Request, ctx: Contexto = Depends(exigir_admin)):
    t = repo.tabla_por_id(id_tabla)
    if not t:
        return _ir("/admin/tablas", error="La tabla no existe.")
    leida, error = None, None
    try:
        esq = esquema_mod._leer([t])  # lectura directa, sin cache, para ver el esquema real
        leida = esq.tablas.get(f"{t['esquema']}.{t['nombre_tabla']}".lower())
        if not leida:
            error = "La tabla no se encuentra en el datawarehouse (o el usuario de lectura no la ve)."
    except Exception:
        error = "No se pudo leer el esquema del datawarehouse."
    return plantillas.TemplateResponse(
        request, "admin/tabla_detalle.html",
        contexto_base(request, ctx, seccion="tablas", t=t, leida=leida, error_lectura=error),
    )


@router.post("/tablas/{id_tabla}")
def editar_tabla(
    id_tabla: int, objetivo: str = Form(""), aclaraciones: str = Form(""), filtro_registros: str = Form(""),
    activa: str | None = Form(None), ctx: Contexto = Depends(exigir_admin),
):
    try:
        adm.actualizar_tabla(ctx, id_tabla, objetivo, aclaraciones, filtro_registros, activa is not None)
        return _ir(f"/admin/tablas/{id_tabla}", ok="Configuración guardada. Se aplica a la consulta siguiente.")
    except adm.ErrorAdmin as e:
        return _ir(f"/admin/tablas/{id_tabla}", error=str(e))


# ============================================================================ auditoria y metricas
@router.get("/auditoria")
def auditoria(
    request: Request, tipo_evento: str = "", resultado: str = "", usuario: str = "", ctx: Contexto = Depends(exigir_admin),
):
    filas = repo.listar_auditoria(tipo_evento or None, resultado or None, usuario or None, limite=300)
    return plantillas.TemplateResponse(
        request, "admin/auditoria.html",
        contexto_base(request, ctx, seccion="auditoria", filas=filas, f_tipo=tipo_evento, f_resultado=resultado, f_usuario=usuario),
    )


@router.get("/auditoria/exportar.csv")
def auditoria_csv(tipo_evento: str = "", resultado: str = "", usuario: str = "", ctx: Contexto = Depends(exigir_admin)):
    filas = repo.listar_auditoria(tipo_evento or None, resultado or None, usuario or None, limite=5000)
    return _csv_respuesta(
        "auditoria.csv",
        ["Fecha (UTC)", "Evento", "Resultado", "Usuario", "Rol", "Tipo de consulta", "Herramienta", "SQL generado",
         "Motivo de bloqueo", "Detalle", "IP", "Duración (ms)"],
        [[a["fecha"].strftime("%Y-%m-%d %H:%M:%S"), a["tipo_evento"], a["resultado"], a["usuario"], a["rol"],
          a["tipo_consulta"], a["herramienta"], a["sql_generado"], a["motivo_bloqueo"], a["detalle"], a["ip"], a["duracion_ms"]]
         for a in filas],
    )


@router.get("/api/metricas")
def metricas(ctx: Contexto = Depends(exigir_admin)):
    """Los cuatro indicadores del monitoreo propio: servicio, tiempo de punta a punta, errores del modelo y espacio."""
    s = get_settings()
    s.data_dir.mkdir(parents=True, exist_ok=True)
    libre = shutil.disk_usage(s.data_dir).free / (1024**3)
    return {
        "servicio": "ok",
        "consultas_ultimos_7_dias": repo.metricas(7),
        "vectores_en_indice": obtener_indice().total,
        "espacio_libre_gb": round(libre, 1),
    }
