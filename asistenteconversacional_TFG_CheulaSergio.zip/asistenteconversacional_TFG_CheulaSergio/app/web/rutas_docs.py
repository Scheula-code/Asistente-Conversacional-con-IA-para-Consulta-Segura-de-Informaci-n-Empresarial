"""Visor de documentos: abre el PDF original desde una cita (HU-003: mostrar de que documento y seccion sale la respuesta)."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse

from .. import repo
from ..config import get_settings
from ..security import rbac
from ..security.auth import Contexto, auditar
from .deps import exigir_sesion

router = APIRouter()
_NO_DISPONIBLE = "No se encontró el documento, o su rol no tiene acceso a él."


@router.get("/documentos/{codigo}/{version}")
def ver_documento(codigo: str, version: str, ctx: Contexto = Depends(exigir_sesion)):
    """Devuelve el PDF para verlo en el navegador. El vinculo de la cita agrega #page=N para abrir en la pagina citada.
    Se aplica el mismo alcance por categorias que a la busqueda; el administrador puede ver todos. Cada apertura queda auditada.
    Un usuario comun no puede abrir una version que ya no esta vigente (un procedimiento reemplazado no debe usarse)."""
    doc = next((d for d in repo.documentos_por_codigo(codigo) if d["version"] == version), None)
    if not doc:
        raise HTTPException(status_code=404, detail=_NO_DISPONIBLE)
    if not ctx.es_admin:
        alcance = rbac.alcance_documental(repo.permisos_de_roles(ctx.ids_roles))
        if not rbac.puede_ver_documento(doc["categoria"], alcance):
            raise HTTPException(status_code=404, detail=_NO_DISPONIBLE)  # misma respuesta que si no existiera
        if not doc["vigente"]:
            vigente = repo.documento_vigente_por_codigo(codigo)
            hay = f" La versión vigente es la {vigente['version']}." if vigente else " El documento fue dado de baja."
            raise HTTPException(status_code=404, detail=f"La versión {version} de {codigo} ya no está vigente.{hay}")
    ruta = get_settings().docs_dir / doc["archivo"]
    if not ruta.is_file():
        raise HTTPException(status_code=404, detail="El archivo del documento no está disponible. Avise a Sistemas.")
    auditar("DOC_VISTA", "ok", ctx, detalle=f"{doc['codigo']} v{doc['version']}")
    return FileResponse(
        ruta, media_type="application/pdf", filename=f"{doc['codigo']}_v{doc['version']}.pdf", content_disposition_type="inline",
        # el visor de PDF del navegador no convive con la politica restrictiva del resto de la aplicacion
        headers={"Content-Security-Policy": "frame-ancestors 'none'"},
    )
