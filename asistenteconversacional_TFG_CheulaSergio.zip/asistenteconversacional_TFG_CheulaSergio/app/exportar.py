"""Exportacion de un resultado a Excel (.xlsx).

El libro lleva tres hojas:
  * Resultado: la tabla tal como la devolvio la consulta (con formatos de fecha y numero y filtros);
  * Grafico  : el grafico pedido como grafico nativo de Excel (se puede editar), con sus datos agregados al lado;
  * Consulta : la pregunta, quien la hizo, cuando, el SQL ejecutado y el resumen/proyeccion calculados.

El contenido sale de lo que el usuario ya vio (se guarda en el mensaje), no se vuelve a ejecutar la consulta.
Las celdas de texto se escriben SIEMPRE como texto: un valor que empiece con = + - @ no se interpreta como formula.
La logica de eleccion del grafico replica la de la pantalla (static/chat.js).
"""
from __future__ import annotations

import io
import re
from datetime import date, datetime
from typing import Any

from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, PieChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

FUENTE = "Arial"
PIZARRA = "3B4A5C"
_RE_FECHA = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_RE_FECHA_HORA = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}")
_RE_PERIODO = re.compile(r"^\d{4}-\d{2}(-\d{2})?")
_ES_ID = re.compile(r"(^id$|^id_|_id$|^codigo$|^(mes|trimestre|semestre|dia|semana)$)", re.IGNORECASE)
_PARTE_TIEMPO = re.compile(r"^(mes|trimestre|semestre|dia|semana)$", re.IGNORECASE)
_NOMBRE_ANIO = re.compile(r"(^|_)(anio|ano|year|periodo|ejercicio)(_|$)|^año$", re.IGNORECASE)
_RE_ANIO = re.compile(r"^(19|20|21)\d{2}$")
NOMBRE_HOJA_GRAFICO = "Gráfico"


# ----------------------------------------------------------------------------
# Celdas
# ----------------------------------------------------------------------------
def _fuente(negrita: bool = False, color: str | None = None, tam: int = 10) -> Font:
    return Font(name=FUENTE, size=tam, bold=negrita, color=color)


def _escribir(ws, fila: int, col: int, valor: Any, plano: bool = False):
    """Escribe un valor con su formato. Los textos quedan como texto, nunca como formula.
    plano=True escribe los enteros sin separador de miles (anos: 2025, no 2,025)."""
    c = ws.cell(row=fila, column=col)
    c.font = _fuente()
    if valor is None:
        return c
    if isinstance(valor, bool):
        c.value = "Sí" if valor else "No"
    elif isinstance(valor, int):
        c.value, c.number_format = valor, ("0" if plano else "#,##0")
    elif isinstance(valor, float):
        c.value, c.number_format = valor, "#,##0.00"
    elif isinstance(valor, str):
        if _RE_FECHA.match(valor):
            try:
                c.value, c.number_format = date.fromisoformat(valor), "yyyy-mm-dd"
                return c
            except ValueError:
                pass
        if _RE_FECHA_HORA.match(valor):
            try:
                c.value, c.number_format = datetime.fromisoformat(valor), "yyyy-mm-dd hh:mm"
                return c
            except ValueError:
                pass
        c.value = valor
        c.data_type = "s"  # texto literal: evita que "=..." se evalue como formula
    else:
        c.value = str(valor)
        c.data_type = "s"
    return c


def _encabezado(ws, fila: int, nombres: list[str]) -> None:
    relleno = PatternFill("solid", start_color=PIZARRA, end_color=PIZARRA)
    for j, n in enumerate(nombres, start=1):
        c = ws.cell(row=fila, column=j, value=str(n))
        c.font = _fuente(True, "FFFFFF")
        c.fill = relleno
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _anchos(ws, columnas: list[str], filas: list[list[Any]]) -> None:
    for j, nombre in enumerate(columnas):
        largo = max([len(str(nombre))] + [len(f"{f[j]:,.2f}" if isinstance(f[j], float) else str(f[j])) for f in filas[:300] if f[j] is not None] or [8])
        ws.column_dimensions[get_column_letter(j + 1)].width = max(12, min(50, largo + 3))


# ----------------------------------------------------------------------------
# Analisis del resultado (misma logica que chat.js)
# ----------------------------------------------------------------------------
def _muestra(filas, i):
    return [f[i] for f in filas[:60] if f[i] is not None]


def _es_numerica(filas, i) -> bool:
    m = _muestra(filas, i)
    return bool(m) and all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in m)


def _es_anio(columnas, filas, i) -> bool:
    m = _muestra(filas, i)
    return bool(m) and bool(_NOMBRE_ANIO.search(columnas[i])) and all(_RE_ANIO.match(str(v)) for v in m)


def _es_periodo(columnas, filas, i) -> bool:
    m = _muestra(filas, i)
    return bool(m) and (all(isinstance(v, str) and _RE_PERIODO.match(v) for v in m) or _es_anio(columnas, filas, i))


def analizar(columnas: list[str], filas: list[list[Any]]) -> dict:
    idx = range(len(columnas))
    col_periodo = next((i for i in idx if _es_periodo(columnas, filas, i)), None)
    col_valor = next((i for i in idx if i != col_periodo and _es_numerica(filas, i) and not _ES_ID.search(columnas[i])), None)
    col_etiqueta = next((i for i in idx if i != col_periodo and (not _es_numerica(filas, i) or _PARTE_TIEMPO.match(columnas[i]))), None)
    if col_etiqueta is None and col_periodo is not None:
        col_etiqueta = col_periodo
    periodos = len({str(f[col_periodo])[:7] for f in filas}) if col_periodo is not None else 0
    return {"col_periodo": col_periodo, "col_valor": col_valor, "col_etiqueta": col_etiqueta, "periodos": periodos}


def tipos_disponibles(info: dict, filas: list) -> list[str]:
    if info["col_valor"] is None:
        return []
    hay_etiqueta = info["col_etiqueta"] is not None and len(filas) >= 2
    t = []
    if hay_etiqueta:
        t += ["barras", "torta"]
    if (info["col_periodo"] is not None and info["periodos"] >= 2) or hay_etiqueta:
        t.append("linea")
    return t


def tipo_automatico(info: dict, disponibles: list[str]) -> str | None:
    if info["periodos"] >= 3 and "linea" in disponibles:
        return "linea"
    if "barras" in disponibles:
        return "barras"
    return disponibles[0] if disponibles else None


def _agrupar(filas, col_etiqueta, col_valor, recorte_periodo=False) -> list[tuple[str, float]]:
    acumulado: dict[str, float] = {}
    for f in filas:
        v = f[col_valor]
        if not isinstance(v, (int, float)) or isinstance(v, bool):
            continue
        k = f[col_etiqueta]
        k = "(sin dato)" if k is None else (str(k)[:7] if recorte_periodo else str(k))
        acumulado[k] = acumulado.get(k, 0.0) + float(v)
    return list(acumulado.items())


# ----------------------------------------------------------------------------
# Hoja del grafico
# ----------------------------------------------------------------------------
def _agregar(ws, chart, ancla: str) -> None:
    for serie in getattr(chart, "series", []):
        if isinstance(chart, LineChart):
            serie.smooth = False          # la linea une los puntos reales, sin curvas inventadas
    ws.add_chart(chart, ancla)


def _estilo_ejes(chart, titulo_x: str | None, titulo_y: str | None) -> None:
    # openpyxl 3.1 deja los ejes ocultos en Excel moderno si no se fuerza delete = False
    chart.x_axis.delete = False
    chart.y_axis.delete = False
    chart.y_axis.number_format = "#,##0"
    if titulo_x:
        chart.x_axis.title = titulo_x
    if titulo_y:
        chart.y_axis.title = titulo_y


def _hoja_grafico(wb: Workbook, columnas, filas, info: dict, tipo: str, proyeccion: dict | None) -> str | None:
    ws = wb.create_sheet(NOMBRE_HOJA_GRAFICO)
    nombre_valor = columnas[info["col_valor"]]
    c_val, c_eti, c_per = info["col_valor"], info["col_etiqueta"], info["col_periodo"]
    es_tiempo = c_eti == c_per

    def tabla(encabezados, filas_datos):
        _encabezado(ws, 1, encabezados)
        for i, fila in enumerate(filas_datos, start=2):
            for j, v in enumerate(fila, start=1):
                _escribir(ws, i, j, v)
        ws.column_dimensions["A"].width = 34
        for j in range(2, len(encabezados) + 1):
            ws.column_dimensions[get_column_letter(j)].width = 18

    if tipo in ("barras", "torta"):
        items = _agrupar(filas, c_eti, c_val, es_tiempo)
        if tipo == "torta":
            items = sorted([i for i in items if i[1] > 0], key=lambda x: -x[1])
            if not items:
                wb.remove(ws)
                return "No se puede graficar en torta: no hay valores positivos."
            if len(items) > 12:
                items = items[:11] + [("Otros", sum(v for _, v in items[11:]))]
        else:
            items = items if es_tiempo else sorted(items, key=lambda x: -x[1])
            items = items[:15]
        tabla([columnas[c_eti], nombre_valor], [[k, v] for k, v in items])
        n = len(items)
        datos = Reference(ws, min_col=2, min_row=1, max_row=n + 1)
        cats = Reference(ws, min_col=1, min_row=2, max_row=n + 1)
        if tipo == "torta":
            ch = PieChart()
            ch.add_data(datos, titles_from_data=True)
            ch.set_categories(cats)
            ch.dataLabels = DataLabelList()
            ch.dataLabels.showPercent = True
            ch.dataLabels.showVal = False
            ch.dataLabels.showCatName = False
            ch.dataLabels.showSerName = False
            ch.dataLabels.showLeaderLines = False
            ch.height, ch.width = 10, 17
        else:
            ch = BarChart()
            ch.type = "bar"                       # barras horizontales: legibles con etiquetas largas
            ch.add_data(datos, titles_from_data=True)
            ch.set_categories(cats)
            ch.legend = None
            ch.x_axis.scaling.orientation = "maxMin"  # el mayor arriba
            _estilo_ejes(ch, None, nombre_valor)
            ch.height, ch.width = max(8, 0.65 * n + 3), 20
        ch.title = f"{nombre_valor} por {columnas[c_eti]}"
        _agregar(ws, ch, "D2")
        return None

    # ---------------------------------------------------------- linea
    ch = LineChart()
    ch.height, ch.width = 10, 22
    es_serie = c_per is not None and info["periodos"] >= 2
    if es_serie:
        grupos = sorted({str(f[c_eti]) for f in filas}) if (c_eti is not None and c_eti != c_per) else []
        if len(grupos) >= 2:
            periodos = sorted({str(f[c_per])[:7] for f in filas})
            por_grupo: dict[str, dict[str, float]] = {}
            for f in filas:
                v = f[c_val]
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    g, p = str(f[c_eti]), str(f[c_per])[:7]
                    por_grupo.setdefault(g, {})
                    por_grupo[g][p] = por_grupo[g].get(p, 0.0) + float(v)
            top = [g for g, _ in sorted(((g, sum(m.values())) for g, m in por_grupo.items()), key=lambda x: -x[1])[:6]]
            tabla([columnas[c_per]] + top, [[p] + [por_grupo[g].get(p) for g in top] for p in periodos])
            data = Reference(ws, min_col=2, max_col=1 + len(top), min_row=1, max_row=len(periodos) + 1)
            cats = Reference(ws, min_col=1, min_row=2, max_row=len(periodos) + 1)
            ch.add_data(data, titles_from_data=True)
            ch.set_categories(cats)
            ch.title = f"Evolución de {nombre_valor} por {columnas[c_eti]}"
            _estilo_ejes(ch, columnas[c_per], nombre_valor)
            _agregar(ws, ch, f"{get_column_letter(len(top) + 3)}2")
            return None
        reales = sorted(_agrupar(filas, c_per, c_val, True))
        proy = proyeccion["proyeccion"] if proyeccion and proyeccion.get("proyectable") else []
        encab = [columnas[c_per], nombre_valor] + (["Proyección"] if proy else [])
        filas_datos = [[p, v] + ([None] if proy else []) for p, v in reales]
        if proy and filas_datos:
            filas_datos[-1][2] = filas_datos[-1][1]            # la proyeccion arranca en el ultimo dato real
            filas_datos += [[x["periodo"], None, x["valor"]] for x in proy]
        tabla(encab, filas_datos)
        n = len(filas_datos)
        data = Reference(ws, min_col=2, max_col=len(encab), min_row=1, max_row=n + 1)
        cats = Reference(ws, min_col=1, min_row=2, max_row=n + 1)
        ch.add_data(data, titles_from_data=True)
        ch.set_categories(cats)
        if proy and len(ch.series) == 2:
            ch.series[1].graphicalProperties.line.dashStyle = "dash"
        ch.title = f"Evolución de {nombre_valor}"
        _estilo_ejes(ch, columnas[c_per], nombre_valor)
        _agregar(ws, ch, f"{get_column_letter(len(encab) + 2)}2")
        return None

    items = _agrupar(filas, c_eti, c_val, False)
    if len(items) < 2:
        wb.remove(ws)
        return "No hay suficientes categorías para dibujar una línea."
    tabla([columnas[c_eti], nombre_valor], [[k, v] for k, v in items])
    data = Reference(ws, min_col=2, min_row=1, max_row=len(items) + 1)
    cats = Reference(ws, min_col=1, min_row=2, max_row=len(items) + 1)
    ch.add_data(data, titles_from_data=True)
    ch.set_categories(cats)
    ch.legend = None
    ch.title = f"{nombre_valor} por {columnas[c_eti]} (la línea une las categorías: el resultado no es una serie en el tiempo)"
    _estilo_ejes(ch, columnas[c_eti], nombre_valor)
    _agregar(ws, ch, "D2")
    return None


# ----------------------------------------------------------------------------
# Hoja de la consulta
# ----------------------------------------------------------------------------
def _hoja_consulta(wb: Workbook, datos: dict, *, pregunta: str, usuario: str, roles: str, fecha: datetime,
                   mostrar_sql: bool, aviso_grafico: str | None) -> None:
    ws = wb.create_sheet("Consulta")
    filas: list[tuple[str, Any]] = [
        ("Pregunta", pregunta),
        ("Usuario", usuario),
        ("Roles", roles),
        ("Generado", fecha.strftime("%d/%m/%Y %H:%M")),
        ("Filas", len(datos.get("filas") or [])),
    ]
    if datos.get("truncado"):
        filas.append(("Aviso", "El resultado se cortó en el límite de filas; hay más datos en el datawarehouse."))
    if aviso_grafico:
        filas.append(("Gráfico", aviso_grafico))
    r = datos.get("resumen")
    if r:
        filas.append(("Primer período", f"{r['primer_periodo']['periodo']}: {r['primer_periodo']['valor']:,.2f}"))
        filas.append(("Último período considerado", f"{r['ultimo_periodo_considerado']['periodo']}: {r['ultimo_periodo_considerado']['valor']:,.2f}"))
        filas.append(("Variación", f"{r['variacion_absoluta']:,.2f}" + (f" ({r['variacion_porcentual']} %)" if r.get("variacion_porcentual") is not None else "")))
        if r.get("nota"):
            filas.append(("Nota", r["nota"]))
    p = datos.get("proyeccion")
    if p:
        if p.get("proyectable"):
            filas.append(("Proyección (estimación)", f"{p['regla']}. Base: {p['periodo_base']}. " + " · ".join(f"{x['periodo']}: {x['valor']:,.2f}" for x in p["proyeccion"]) + f" · Total del horizonte: {p['total_horizonte']:,.2f}"))
        else:
            filas.append(("Proyección", "No disponible: " + str(p.get("motivo", ""))))
    if mostrar_sql and datos.get("sql"):
        filas.append(("SQL ejecutado (solo lectura)", datos["sql"]))
    filas.append(("Origen", "Asistente conversacional. Datos del datawarehouse consultados en modo solo lectura; la consulta quedó registrada en la auditoría."))
    for i, (k, v) in enumerate(filas, start=1):
        a = ws.cell(row=i, column=1, value=k)
        a.font = _fuente(True)
        a.alignment = Alignment(vertical="top")
        b = _escribir(ws, i, 2, v)
        b.alignment = Alignment(wrap_text=True, vertical="top")
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 100


# ----------------------------------------------------------------------------
def a_excel(datos: dict, *, pregunta: str, usuario: str, roles: str, fecha: datetime | None = None,
            mostrar_sql: bool = False) -> bytes:
    columnas = [str(c) for c in datos.get("columnas") or []]
    filas = datos.get("filas") or []
    wb = Workbook()
    wb._named_styles["Normal"].font = _fuente()
    ws = wb.active
    ws.title = "Resultado"
    _encabezado(ws, 1, columnas)
    anios = [_es_anio(columnas, filas, j) for j in range(len(columnas))]
    for i, fila in enumerate(filas, start=2):
        for j, v in enumerate(fila, start=1):
            _escribir(ws, i, j, v, plano=anios[j - 1])
    if columnas:
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = f"A1:{get_column_letter(len(columnas))}{len(filas) + 1}"
        _anchos(ws, columnas, filas)

    aviso = None
    pedido = datos.get("grafico") or "auto"
    if pedido != "ninguno" and filas:
        info = analizar(columnas, filas)
        disponibles = tipos_disponibles(info, filas)
        tipo = (tipo_automatico(info, disponibles) if pedido == "auto" else pedido) if disponibles else None
        if tipo and tipo not in disponibles:
            aviso = "No se pudo dibujar el gráfico pedido con este resultado."
        elif tipo:
            aviso = _hoja_grafico(wb, columnas, filas, info, tipo, datos.get("proyeccion"))
    _hoja_consulta(wb, datos, pregunta=pregunta, usuario=usuario, roles=roles, fecha=fecha or datetime.now(),
                   mostrar_sql=mostrar_sql, aviso_grafico=aviso)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
