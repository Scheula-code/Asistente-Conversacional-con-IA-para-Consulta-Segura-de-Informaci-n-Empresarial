"""Operaciones del rol de administracion (HU-005, HU-008, HU-015). Cada cambio queda en AUDITORIA.

Altas, bajas y cambios de rol/permiso tienen efecto en la consulta siguiente del usuario afectado,
porque el rol y los permisos se leen de la base en cada pedido.
"""
from __future__ import annotations

import csv
import io
import re

from . import repo
from .datos import esquema as esquema_mod
from .security import passwords, rbac
from .security.auth import Contexto, auditar

_RE_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_RE_IDENT = re.compile(r"^[A-Za-z0-9_]{1,120}$")
TIPOS_RECURSO = ("documento", "tabla", "columna")
NIVELES = {
    "documento": ("lectura",),
    "tabla": ("lectura", "lectura_area"),
    "columna": ("lectura", "denegado"),
}


class ErrorAdmin(Exception):
    """Mensaje apto para mostrar al administrador."""


# ----------------------------------------------------------------------------
# Roles
# ----------------------------------------------------------------------------
_RE_ROL = re.compile(r"^[A-Za-z0-9_\-]{2,60}$")
ROL_SISTEMA = "administracion"


def _es_rol_sistema(rol: dict) -> bool:
    return rol["codigo"].lower() == ROL_SISTEMA


def crear_rol(ctx: Contexto, codigo: str, descripcion: str | None) -> int:
    codigo = (codigo or "").strip()
    if not _RE_ROL.match(codigo):
        raise ErrorAdmin("El nombre del rol admite letras, números, guion y guion bajo (de 2 a 60 caracteres), sin espacios.")
    if codigo.lower() == ROL_SISTEMA or repo.rol_por_codigo(codigo):
        raise ErrorAdmin("Ya existe un rol con ese nombre.")
    id_rol = repo.crear_rol(codigo, (descripcion or "").strip()[:300] or None)
    auditar("ROL_ALTA", "ok", ctx, detalle=codigo)
    return id_rol


def actualizar_rol(ctx: Contexto, id_rol: int, descripcion: str | None) -> None:
    rol = repo.rol_por_id(id_rol)
    if not rol:
        raise ErrorAdmin("El rol no existe.")
    if _es_rol_sistema(rol):
        raise ErrorAdmin("El rol de administración es del sistema y no se modifica.")
    repo.actualizar_rol(id_rol, (descripcion or "").strip()[:300] or None)
    auditar("ROL_MODIFICADO", "ok", ctx, detalle=rol["codigo"])


def eliminar_rol(ctx: Contexto, id_rol: int) -> None:
    rol = repo.rol_por_id(id_rol)
    if not rol:
        raise ErrorAdmin("El rol no existe.")
    if _es_rol_sistema(rol):
        raise ErrorAdmin("El rol de administración es del sistema y no se elimina.")
    if rol["usuarios"]:
        raise ErrorAdmin(f"El rol {rol['codigo']} tiene {rol['usuarios']} usuario(s) asignado(s): quítelo de ellos antes de eliminarlo.")
    repo.eliminar_rol(id_rol)
    auditar("ROL_BAJA", "ok", ctx, detalle=rol["codigo"])


# ----------------------------------------------------------------------------
# Usuarios
# ----------------------------------------------------------------------------
def _roles_validos(ids_roles) -> list[dict]:
    ids = list(dict.fromkeys(int(i) for i in (ids_roles or [])))
    if not ids:
        raise ErrorAdmin("Debe asignar al menos un rol.")
    roles = []
    for i in ids:
        r = repo.rol_por_id(i)
        if not r:
            raise ErrorAdmin("Un rol seleccionado no existe.")
        roles.append(r)
    return roles


def crear_usuario(ctx: Contexto, nombre: str, email: str, area: str | None, ids_roles) -> tuple[int, str]:
    nombre, email = (nombre or "").strip(), (email or "").strip().lower()
    if not nombre or len(nombre) > 100:
        raise ErrorAdmin("El nombre es obligatorio (máx. 100 caracteres).")
    if not _RE_EMAIL.match(email) or len(email) > 120:
        raise ErrorAdmin("El correo no es válido.")
    if repo.usuario_por_email(email):
        raise ErrorAdmin("Ya existe un usuario con ese correo.")
    roles = _roles_validos(ids_roles)
    temporal = passwords.generar_temporal()
    id_usuario = repo.crear_usuario(
        nombre, email, (area or "").strip()[:80] or None, [r["id_rol"] for r in roles], passwords.hashear(temporal)
    )
    auditar("USUARIO_ALTA", "ok", ctx, detalle=f"{email} con roles {', '.join(r['codigo'] for r in roles)}")
    return id_usuario, temporal


def actualizar_usuario(ctx: Contexto, id_usuario: int, nombre: str, area: str | None, ids_roles, activo: bool) -> None:
    u = repo.usuario_por_id(id_usuario)
    if not u:
        raise ErrorAdmin("El usuario no existe.")
    if not (nombre or "").strip():
        raise ErrorAdmin("El nombre es obligatorio.")
    nuevos = _roles_validos(ids_roles)
    previos = repo.roles_de_usuario(id_usuario)
    if id_usuario == ctx.id_usuario and (not any(_es_rol_sistema(r) for r in nuevos) or not activo):
        raise ErrorAdmin("No puede quitarse a sí mismo el rol de administración ni darse de baja.")
    repo.actualizar_usuario(id_usuario, nombre, (area or "").strip()[:80] or None, [r["id_rol"] for r in nuevos], activo)
    antes, despues = sorted(r["codigo"] for r in previos), sorted(r["codigo"] for r in nuevos)
    if antes != despues:
        auditar("CAMBIO_ROL", "ok", ctx, detalle=f"{u['email']}: [{', '.join(antes)}] -> [{', '.join(despues)}]")
    if bool(u["activo"]) != activo:
        auditar("USUARIO_BAJA" if not activo else "USUARIO_ALTA", "ok", ctx, detalle=u["email"])
        if not activo:
            repo.cerrar_sesiones_de_usuario(id_usuario, "baja_usuario")
    if (u["area"] or "") != ((area or "").strip() or ""):
        auditar("USUARIO_MODIFICADO", "ok", ctx, detalle=f"{u['email']}: área '{u['area'] or ''}' -> '{(area or '').strip()}'")


def desbloquear(ctx: Contexto, id_usuario: int) -> None:
    u = repo.usuario_por_id(id_usuario)
    if not u:
        raise ErrorAdmin("El usuario no existe.")
    repo.desbloquear_usuario(id_usuario)
    auditar("CUENTA_DESBLOQUEADA", "ok", ctx, detalle=u["email"])


def resetear_clave(ctx: Contexto, id_usuario: int) -> str:
    u = repo.usuario_por_id(id_usuario)
    if not u:
        raise ErrorAdmin("El usuario no existe.")
    temporal = passwords.generar_temporal()
    repo.guardar_clave(id_usuario, passwords.hashear(temporal), forzar_cambio=True)
    repo.cerrar_sesiones_de_usuario(id_usuario, "reseteo_clave")
    auditar("RESET_CLAVE", "ok", ctx, detalle=u["email"])
    return temporal


# ----------------------------------------------------------------------------
# Permisos (Figura 8)
# ----------------------------------------------------------------------------
def _validar_permiso(tipo: str, recurso: str, nivel: str) -> str:
    recurso = (recurso or "").strip()
    if tipo not in TIPOS_RECURSO:
        raise ErrorAdmin("Tipo de recurso inválido.")
    if nivel not in NIVELES[tipo]:
        raise ErrorAdmin(f"Para '{tipo}' el nivel debe ser: {', '.join(NIVELES[tipo])}.")
    if not recurso or len(recurso) > 120:
        raise ErrorAdmin("El recurso es obligatorio (máx. 120 caracteres).")
    if tipo == "documento" and len(recurso) > 80:
        raise ErrorAdmin("La categoría de documentos admite hasta 80 caracteres ('*' para todas).")
    if tipo == "tabla" and recurso.count(".") != 1:
        raise ErrorAdmin("Para tablas el recurso es 'esquema.tabla'.")
    if tipo == "columna" and recurso.count(".") != 2:
        raise ErrorAdmin("Para columnas el recurso es 'esquema.tabla.columna'.")
    return recurso.lower() if tipo != "documento" else recurso


def guardar_permiso(ctx: Contexto, id_rol: int, tipo: str, recurso: str, nivel: str, origen: str) -> None:
    rol = repo.rol_por_id(id_rol)
    if not rol:
        raise ErrorAdmin("El rol no existe.")
    if _es_rol_sistema(rol):
        raise ErrorAdmin("El rol de administración no consulta información de negocio: no admite permisos de consulta.")
    recurso = _validar_permiso(tipo, recurso, nivel)
    origen = (origen or "manual").strip()[:40] or "manual"
    repo.guardar_permiso(id_rol, tipo, recurso, nivel, origen)
    auditar("CAMBIO_PERMISO", "ok", ctx, detalle=f"{rol['codigo']}: +{tipo} {recurso} [{nivel}] origen={origen}")


def quitar_permiso(ctx: Contexto, id_permiso: int) -> None:
    p = repo.permiso_por_id(id_permiso)
    if not p:
        raise ErrorAdmin("El permiso no existe.")
    rol = repo.rol_por_id(p["id_rol"])
    repo.quitar_permiso(id_permiso)
    auditar("CAMBIO_PERMISO", "ok", ctx,
            detalle=f"{rol['codigo'] if rol else p['id_rol']}: -{p['tipo_recurso']} {p['recurso']} [{p['nivel_acceso']}]")


def importar_permisos_csv(ctx: Contexto, contenido: bytes, reemplazar_origen: bool) -> dict:
    """CSV con columnas: rol, tipo_recurso, recurso, nivel_acceso, origen (separador coma o punto y coma).
    Sirve para volcar los permisos vigentes de la intranet y de la capa de reportes (tarea 19 del sprint 2)."""
    try:
        texto = contenido.decode("utf-8-sig")
    except UnicodeDecodeError:
        texto = contenido.decode("latin-1")
    muestra = texto[:2048]
    delimitador = ";" if muestra.count(";") > muestra.count(",") else ","
    lector = csv.DictReader(io.StringIO(texto), delimiter=delimitador)
    faltan = {"rol", "tipo_recurso", "recurso", "nivel_acceso", "origen"} - {(c or "").strip().lower() for c in (lector.fieldnames or [])}
    if faltan:
        raise ErrorAdmin(f"Faltan columnas en el CSV: {', '.join(sorted(faltan))}.")
    roles = {r["codigo"].lower(): r for r in repo.listar_roles()}
    filas, errores = [], []
    for n, fila in enumerate(lector, start=2):
        f = {(k or "").strip().lower(): (v or "").strip() for k, v in fila.items()}
        try:
            rol = roles.get(f["rol"].lower())
            if not rol:
                raise ErrorAdmin(f"rol desconocido '{f['rol']}'")
            if _es_rol_sistema(rol):
                raise ErrorAdmin("el rol de administración no admite permisos de consulta")
            recurso = _validar_permiso(f["tipo_recurso"], f["recurso"], f["nivel_acceso"])
            filas.append((rol, f["tipo_recurso"], recurso, f["nivel_acceso"], (f["origen"] or "importado")[:40]))
        except ErrorAdmin as e:
            errores.append(f"Línea {n}: {e}")
    if errores:  # todo o nada: si una fila es invalida no se aplica ninguna
        raise ErrorAdmin("No se importó nada. " + " | ".join(errores[:10]) + (" ..." if len(errores) > 10 else ""))
    borrados = 0
    if reemplazar_origen:
        for id_rol, origen in {(r["id_rol"], o) for r, _, _, _, o in filas}:
            borrados += repo.quitar_permisos_por_origen(id_rol, origen)
    for rol, tipo, recurso, nivel, origen in filas:
        repo.guardar_permiso(rol["id_rol"], tipo, recurso, nivel, origen)
    auditar("CAMBIO_PERMISO", "ok", ctx, detalle=f"importación CSV: {len(filas)} permisos, {borrados} reemplazados")
    return {"importados": len(filas), "reemplazados": borrados}


def resumen_rol(id_rol: int) -> dict:
    """Lo que ve la pantalla de la Figura 8: documentos, tablas y columnas habilitados y su origen."""
    permisos = repo.permisos_de_rol(id_rol)
    tablas = repo.listar_tablas()
    activas = {rbac.clave_tabla(t["esquema"], t["nombre_tabla"]): t for t in tablas if t["activa"]}
    return {
        "documentos": [p for p in permisos if p["tipo_recurso"] == "documento"],
        "tablas": [dict(p, habilitada=(p["recurso"].lower() in activas)) for p in permisos if p["tipo_recurso"] == "tabla"],
        "columnas": [p for p in permisos if p["tipo_recurso"] == "columna"],
    }


# ----------------------------------------------------------------------------
# Tablas habilitadas (HU-005)
# ----------------------------------------------------------------------------
def _verificar_en_dwh(esquema: str, nombre: str, filtro: str | None) -> None:
    cfg = [{"id_tabla": 0, "esquema": esquema, "nombre_tabla": nombre, "objetivo": "", "aclaraciones": None, "filtro_registros": filtro}]
    try:
        esq = esquema_mod._leer(cfg)
    except Exception as e:
        raise ErrorAdmin("No se pudo consultar el datawarehouse para verificar la tabla.") from e
    t = esq.tablas.get(rbac.clave_tabla(esquema, nombre))
    if not t:
        raise ErrorAdmin(f"La tabla {esquema}.{nombre} no existe en el datawarehouse o el usuario de lectura no la ve.")
    if filtro and filtro.lower() not in {c.nombre.lower() for c in t.columnas}:
        raise ErrorAdmin(f"La columna '{filtro}' no existe en {esquema}.{nombre}.")


def crear_tabla(ctx: Contexto, esquema: str, nombre: str, objetivo: str, aclaraciones: str | None, filtro: str | None) -> int:
    esquema, nombre, filtro = (esquema or "").strip(), (nombre or "").strip(), ((filtro or "").strip() or None)
    if not _RE_IDENT.match(esquema) or not _RE_IDENT.match(nombre):
        raise ErrorAdmin("Esquema y tabla admiten solo letras, números y guion bajo.")
    if filtro and not _RE_IDENT.match(filtro):
        raise ErrorAdmin("La columna de área admite solo letras, números y guion bajo.")
    if not (objetivo or "").strip():
        raise ErrorAdmin("El objetivo es obligatorio: es lo único que se declara de la tabla.")
    if any(t["esquema"].lower() == esquema.lower() and t["nombre_tabla"].lower() == nombre.lower() for t in repo.listar_tablas()):
        raise ErrorAdmin("Esa tabla ya está declarada.")
    _verificar_en_dwh(esquema, nombre, filtro)
    id_tabla = repo.crear_tabla(esquema, nombre, objetivo.strip()[:500], (aclaraciones or "").strip()[:1000] or None, filtro)
    esquema_mod.invalidar_cache()
    auditar("TABLA_CONFIG", "ok", ctx, detalle=f"alta de {esquema}.{nombre}")
    return id_tabla


def actualizar_tabla(ctx: Contexto, id_tabla: int, objetivo: str, aclaraciones: str | None, filtro: str | None, activa: bool) -> None:
    t = repo.tabla_por_id(id_tabla)
    if not t:
        raise ErrorAdmin("La tabla no existe.")
    filtro = (filtro or "").strip() or None
    if filtro and not _RE_IDENT.match(filtro):
        raise ErrorAdmin("La columna de área admite solo letras, números y guion bajo.")
    if not (objetivo or "").strip():
        raise ErrorAdmin("El objetivo es obligatorio.")
    if filtro and filtro != t["filtro_registros"]:
        _verificar_en_dwh(t["esquema"], t["nombre_tabla"], filtro)
    repo.actualizar_tabla(id_tabla, objetivo.strip()[:500], (aclaraciones or "").strip()[:1000] or None, filtro, activa)
    esquema_mod.invalidar_cache()
    auditar("TABLA_CONFIG", "ok", ctx, detalle=f"cambio en {t['esquema']}.{t['nombre_tabla']} (activa={int(activa)})")
