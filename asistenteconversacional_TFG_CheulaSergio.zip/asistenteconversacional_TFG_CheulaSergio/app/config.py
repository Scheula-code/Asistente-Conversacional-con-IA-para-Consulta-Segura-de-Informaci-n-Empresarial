"""Configuracion del prototipo. Todo sale de variables de entorno (.env)."""
from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()


def _s(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def _i(name: str, default: int) -> int:
    v = _s(name)
    return int(v) if v else default


def _f(name: str, default: float) -> float:
    v = _s(name)
    return float(v) if v else default


def _b(name: str, default: bool) -> bool:
    v = _s(name).lower()
    if not v:
        return default
    return v in ("1", "true", "yes", "si", "sí")


@dataclass(frozen=True)
class Settings:
    # Base propia
    app_db_server: str
    app_db_name: str
    app_db_user: str
    app_db_password: str
    # Datawarehouse (solo lectura)
    dwh_server: str
    dwh_name: str
    dwh_user: str
    dwh_password: str
    odbc_driver: str
    db_trust_cert: str
    db_trusted: bool
    # Modelo
    openai_api_key: str
    openai_model: str
    openai_aux_model: str
    openai_embedding_model: str
    openai_reasoning_effort: str
    openai_temperature: str
    llm_timeout_s: int
    llm_reintentos: int
    # Archivos
    data_dir: Path
    max_upload_mb: int
    # Sesion y claves (valores declarados en la seccion Seguridad del documento)
    sesion_inactividad_min: int
    sesion_max_horas: int
    cookie_secure: bool
    allowed_origins: tuple[str, ...]
    clave_min_largo: int
    clave_vence_dias: int
    clave_historial: int
    max_intentos: int
    # RAG
    chunk_chars: int
    chunk_overlap: int
    rag_top_k: int
    rag_score_minimo: float
    rag_candidatos: int
    rag_rerank: bool
    embedding_dim: int
    # Text-to-SQL
    sql_max_filas: int
    sql_timeout_s: int
    sql_reintentos_reparacion: int
    mostrar_sql: bool
    schema_cache_s: int
    # Proyeccion (regla declarada en el objetivo especifico 2)
    proy_meses_base: int
    proy_horizonte: int
    # Conversacion
    historial_mensajes: int

    @property
    def docs_dir(self) -> Path:
        return self.data_dir / "documentos"

    @property
    def indice_dir(self) -> Path:
        return self.data_dir / "indice"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    data_dir = Path(_s("DATA_DIR", "./data")).resolve()
    return Settings(
        app_db_server=_s("APP_DB_SERVER", "localhost"),
        app_db_name=_s("APP_DB_NAME", "ASISTENTE_IA"),
        app_db_user=_s("APP_DB_USER"),
        app_db_password=_s("APP_DB_PASSWORD"),
        dwh_server=_s("DWH_SERVER", "localhost"),
        dwh_name=_s("DWH_NAME"),
        dwh_user=_s("DWH_USER"),
        dwh_password=_s("DWH_PASSWORD"),
        odbc_driver=_s("ODBC_DRIVER", "ODBC Driver 18 for SQL Server"),
        db_trust_cert=_s("DB_TRUST_CERT", "yes"),
        db_trusted=_b("DB_TRUSTED", False),
        openai_api_key=_s("OPENAI_API_KEY"),
        openai_model=_s("OPENAI_MODEL", "gpt-4o"),
        openai_aux_model=_s("OPENAI_AUX_MODEL"),
        openai_embedding_model=_s("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small"),
        openai_reasoning_effort=_s("OPENAI_REASONING_EFFORT"),
        openai_temperature=_s("OPENAI_TEMPERATURE", "0"),
        llm_timeout_s=_i("LLM_TIMEOUT_S", 60),
        llm_reintentos=_i("LLM_REINTENTOS", 3),
        data_dir=data_dir,
        max_upload_mb=_i("MAX_UPLOAD_MB", 30),
        sesion_inactividad_min=_i("SESION_INACTIVIDAD_MIN", 30),
        sesion_max_horas=_i("SESION_MAX_HORAS", 8),
        cookie_secure=_b("COOKIE_SECURE", False),
        allowed_origins=tuple(
            o.strip().rstrip("/") for o in _s("ALLOWED_ORIGINS").split(",") if o.strip()
        ),
        clave_min_largo=_i("CLAVE_MIN_LARGO", 12),
        clave_vence_dias=_i("CLAVE_VENCE_DIAS", 90),
        clave_historial=_i("CLAVE_HISTORIAL", 5),
        max_intentos=_i("MAX_INTENTOS", 5),
        chunk_chars=_i("CHUNK_CHARS", 1200),
        chunk_overlap=_i("CHUNK_OVERLAP", 200),
        rag_top_k=_i("RAG_TOP_K", 6),
        rag_score_minimo=_f("RAG_SCORE_MINIMO", 0.30),
        rag_candidatos=_i("RAG_CANDIDATOS", 24),
        rag_rerank=_b("RAG_RERANK", True),
        embedding_dim=_i("EMBEDDING_DIM", 1536),
        sql_max_filas=_i("SQL_MAX_FILAS", 500),
        sql_timeout_s=_i("SQL_TIMEOUT_S", 30),
        sql_reintentos_reparacion=_i("SQL_REINTENTOS_REPARACION", 2),
        mostrar_sql=_b("MOSTRAR_SQL", False),
        schema_cache_s=_i("SCHEMA_CACHE_S", 600),
        proy_meses_base=_i("PROY_MESES_BASE", 12),
        proy_horizonte=_i("PROY_HORIZONTE", 3),
        historial_mensajes=_i("HISTORIAL_MENSAJES", 10),
    )
