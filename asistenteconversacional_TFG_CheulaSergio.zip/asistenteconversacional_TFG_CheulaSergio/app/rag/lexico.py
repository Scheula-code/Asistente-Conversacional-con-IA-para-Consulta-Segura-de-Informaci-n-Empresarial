"""Busqueda por palabras (BM25) sobre los fragmentos, para complementar a los embeddings.

Los embeddings encuentran fragmentos que "significan" algo parecido a la pregunta, pero fallan con terminos exactos
(un codigo de documento, una sigla, un nombre propio). BM25 acierta justo ahi. Se combinan con una fusion por rangos.

El indice vive en memoria y se arma una vez, a pedido, desde los fragmentos vigentes; se descarta (invalidar) cada vez
que cambia el indice vectorial. Es adecuado para el volumen de este prototipo; con decenas de miles de documentos
convendria pasar a la busqueda de texto completo del propio SQL Server.
El filtro por permisos se aplica antes de puntuar, igual que en el indice vectorial.
"""
from __future__ import annotations

import math
import re
import threading
import unicodedata
from collections import Counter, defaultdict
from typing import Callable, Iterable

_STOP = frozenset(
    """a al algo algun alguna algunos ante antes aqui asi aun cada como con contra cual cuales cuando cuanto de del desde donde dos
    el ella ellas ellos en entre era eran es esa esas ese eso esos esta estas este esto estos fue fueron ha han hasta hay la las le les
    lo los mas me mi muy ni no nos nosotros o os otra otro para pero por porque que quien se sea segun ser si sin sobre su sus tambien
    te tiene tienen todo todos tu tus un una uno unos y ya yo""".split()
)
_RE_TOKEN = re.compile(r"[a-z0-9]+")


def tokenizar(texto: str) -> list[str]:
    t = unicodedata.normalize("NFKD", (texto or "").lower())
    t = "".join(c for c in t if not unicodedata.combining(c))
    salida = []
    for tok in _RE_TOKEN.findall(t):
        if tok in _STOP or (len(tok) < 3 and not tok.isdigit()):
            continue
        if len(tok) > 3 and tok.endswith("s"):   # plural simple: lotes -> lote, agentes -> agente (consistente con el singular)
            tok = tok[:-1]
        salida.append(tok)
    return salida


def tokenizar_plano(texto: str) -> list[str]:
    """Palabras normalizadas (sin tildes, minusculas), SIN descartar siglas cortas ni plurales: para comparar codigos como M1L2."""
    t = unicodedata.normalize("NFKD", (texto or "").lower())
    return _RE_TOKEN.findall("".join(c for c in t if not unicodedata.combining(c)))


class BM25:
    K1, B = 1.5, 0.75

    def __init__(self, documentos: Iterable[tuple[int, str, dict]]):
        self.ids: list[int] = []
        self.meta: list[dict] = []
        self.largos: list[int] = []
        self.postings: dict[str, list[tuple[int, int]]] = defaultdict(list)
        for id_, texto, meta in documentos:
            tokens = tokenizar(texto)
            n = len(self.ids)
            self.ids.append(id_)
            self.meta.append(meta)
            self.largos.append(len(tokens))
            for termino, tf in Counter(tokens).items():
                self.postings[termino].append((n, tf))
        self.promedio = (sum(self.largos) / len(self.largos)) if self.largos else 0.0

    def __len__(self) -> int:
        return len(self.ids)

    def buscar(
        self, consulta: str, k: int, permitido: Callable[[dict], bool], min_terminos: int = 1
    ) -> list[tuple[int, float, int]]:
        """[(id, puntaje, terminos_coincidentes)] de mayor a menor, solo entre los fragmentos que `permitido` habilita."""
        terminos = list(dict.fromkeys(tokenizar(consulta)))
        if not terminos or not self.ids:
            return []
        n_docs = len(self.ids)
        puntaje: dict[int, float] = defaultdict(float)
        coincidencias: dict[int, int] = defaultdict(int)
        cache_permiso: dict[int, bool] = {}
        for termino in terminos:
            lista = self.postings.get(termino)
            if not lista:
                continue
            idf = math.log(1 + (n_docs - len(lista) + 0.5) / (len(lista) + 0.5))
            for n, tf in lista:
                if n not in cache_permiso:
                    cache_permiso[n] = bool(permitido(self.meta[n]))
                if not cache_permiso[n]:
                    continue
                norma = 1 - self.B + self.B * self.largos[n] / (self.promedio or 1.0)
                puntaje[n] += idf * tf * (self.K1 + 1) / (tf + self.K1 * norma)
                coincidencias[n] += 1
        minimo = min(min_terminos, len(terminos))
        ranking = sorted(((n, p) for n, p in puntaje.items() if coincidencias[n] >= minimo), key=lambda x: -x[1])[:k]
        return [(self.ids[n], round(p, 4), coincidencias[n]) for n, p in ranking]


_indice: BM25 | None = None
_lock = threading.Lock()


def invalidar() -> None:
    global _indice
    with _lock:
        _indice = None


def obtener(cargar: Callable[[], Iterable[tuple[int, str, dict]]]) -> BM25:
    global _indice
    with _lock:
        if _indice is None:
            _indice = BM25(cargar())
        return _indice
