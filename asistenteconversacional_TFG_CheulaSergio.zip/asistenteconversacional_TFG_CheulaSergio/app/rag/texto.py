"""Extraccion de texto de los PDF y fragmentacion (indexacion documental, HU-002 y HU-003).

Cada fragmento conserva la pagina y la seccion de origen para poder citarlos. Las secciones se
detectan por heuristica (numeracion tipo '5.2 Titulo' o lineas en mayusculas): es suficiente para
SOP con estructura numerada, pero no garantiza acierto en cualquier maquetacion.
"""
from __future__ import annotations

import io
import re
from dataclasses import dataclass

_RE_TITULO_NUM = re.compile(r"^\s*(\d+(?:\.\d+){0,4})[\.\)]?\s+[A-Za-zÁÉÍÓÚÑáéíóúñ¿¡]")


class ErrorExtraccion(Exception):
    pass


@dataclass(frozen=True)
class Pagina:
    numero: int
    texto: str


def extraer_paginas(contenido: bytes) -> tuple[list[Pagina], str | None]:
    """Devuelve las paginas con texto y el titulo de los metadatos del PDF, si lo tiene."""
    from pypdf import PdfReader
    from pypdf.errors import PyPdfError

    try:
        lector = PdfReader(io.BytesIO(contenido))
        if lector.is_encrypted:
            raise ErrorExtraccion("El PDF está protegido con contraseña.")
        paginas = [Pagina(i + 1, (p.extract_text() or "")) for i, p in enumerate(lector.pages)]
        titulo = None
        if lector.metadata and lector.metadata.title:
            titulo = str(lector.metadata.title).strip() or None
    except ErrorExtraccion:
        raise
    except (PyPdfError, ValueError, OSError, KeyError) as e:
        raise ErrorExtraccion(f"No se pudo leer el PDF: {e}") from e
    if sum(len(p.texto.strip()) for p in paginas) < 50:
        raise ErrorExtraccion("El PDF no tiene capa de texto (¿está escaneado?). Este prototipo no hace OCR.")
    return paginas, titulo


_RE_PRIMERA_ORACION = re.compile(r"(?<=[a-záéíóúñ0-9\)])\.\s+(?=[A-ZÁÉÍÓÚÑ])")
_RE_NUM_PREFIJO = re.compile(r"^(\d+(?:\.\d+){0,4}\.?)\s+(.*)$")


def _es_titulo(linea: str) -> bool:
    t = linea.strip()
    if not t:
        return False
    if _RE_TITULO_NUM.match(t):
        # titulo numerado corto, o titulo con el parrafo pegado en la misma linea (la extraccion de PDF las une, y la linea puede ser larga)
        corto = len(t) < 70 and not t.endswith((",", ";"))
        pegado = bool(_RE_NUM_PREFIJO.match(t)) and len(_RE_PRIMERA_ORACION.split(_RE_NUM_PREFIJO.match(t).group(2), maxsplit=1)[0]) <= 80 \
            and bool(_RE_PRIMERA_ORACION.search(t))
        return corto or pegado
    letras = [c for c in t if c.isalpha()]
    return len(t) <= 120 and len(letras) >= 4 and t.upper() == t and len(t) < 80 and not t.endswith(".")


def limpiar_titulo(linea: str) -> str:
    """Nombre de seccion para citar: con el parrafo pegado, se queda con la primera oracion ('1. Titulo.')."""
    m = _RE_NUM_PREFIJO.match(linea.strip())
    if not m:
        return linea.strip()[:200]
    prefijo, resto = m.groups()
    return f"{prefijo} {_RE_PRIMERA_ORACION.split(resto, maxsplit=1)[0]}".strip()[:200]


def _partir_larga(linea: str, maximo: int) -> list[str]:
    if len(linea) <= maximo:
        return [linea]
    piezas, actual = [], ""
    for palabra in linea.split(" "):
        if len(actual) + len(palabra) + 1 > maximo and actual:
            piezas.append(actual)
            actual = palabra
        else:
            actual = f"{actual} {palabra}".strip()
    if actual:
        piezas.append(actual)
    return piezas


def fragmentar(paginas: list[Pagina], max_chars: int = 1200, solapamiento: int = 200) -> list[dict]:
    """Agrupa lineas en fragmentos de hasta max_chars, con solapamiento entre fragmentos contiguos."""
    # 1) lineas con su pagina y la seccion vigente en ese punto
    lineas: list[tuple[int, str, str]] = []  # (pagina, seccion, texto)
    seccion = ""
    for p in paginas:
        for cruda in p.texto.splitlines():
            linea = " ".join(cruda.split())
            if not linea:
                continue
            if _es_titulo(linea):
                seccion = limpiar_titulo(linea)
            for pieza in _partir_larga(linea, max_chars):
                lineas.append((p.numero, seccion, pieza))

    fragmentos: list[dict] = []
    buffer: list[tuple[int, str, str]] = []
    inicio_nuevo = 0  # indice, dentro del buffer, donde empieza el contenido no solapado

    def emitir() -> None:
        texto = "\n".join(t for _, _, t in buffer).strip()
        if len(texto.replace("\n", "").replace(" ", "")) < 30:
            return
        ref = buffer[inicio_nuevo] if inicio_nuevo < len(buffer) else buffer[0]
        fragmentos.append(
            {"orden": len(fragmentos) + 1, "pagina": ref[0], "seccion": ref[1] or None, "texto": texto[:4000]}
        )

    largo = 0
    for ln in lineas:
        if buffer and largo + len(ln[2]) + 1 > max_chars:
            emitir()
            # solapamiento: conservar las ultimas lineas hasta `solapamiento` caracteres
            cola: list[tuple[int, str, str]] = []
            acumulado = 0
            for previa in reversed(buffer):
                if acumulado + len(previa[2]) > solapamiento:
                    break
                cola.insert(0, previa)
                acumulado += len(previa[2]) + 1
            buffer = cola
            inicio_nuevo = len(buffer)
            largo = acumulado
        buffer.append(ln)
        largo += len(ln[2]) + 1
    if buffer and inicio_nuevo < len(buffer):
        emitir()
    return fragmentos
