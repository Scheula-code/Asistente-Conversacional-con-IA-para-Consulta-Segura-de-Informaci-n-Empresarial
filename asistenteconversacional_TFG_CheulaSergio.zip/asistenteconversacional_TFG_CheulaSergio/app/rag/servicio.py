"""Servicio documental: alta de PDF, indexacion, baja, reindexacion y busqueda (HU-001, 002, 003, 009).

Solo las versiones vigentes estan en el indice. Al subir una version posterior de un codigo ya
cargado, la anterior se retira del indice (sus fragmentos dejan de recuperarse).
"""
from __future__ import annotations

import hashlib
import logging
import math
import re
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .. import llm, repo
from ..config import get_settings
from ..security import rbac
from ..security.auth import Contexto, auditar
from . import lexico, refinar, texto
from .indice import obtener_indice

log = logging.getLogger("asistente.rag")

TIPOS = {"SOP": "SOP", "PROCESO": "Documento de proceso", "GUIA": "Guía de trabajo"}
_RE_CODIGO = re.compile(r"^[A-Za-z0-9._-]{1,30}$")
_RE_VERSION = re.compile(r"^[A-Za-z0-9._-]{1,10}$")


class ErrorDocumento(Exception):
    """Mensaje apto para mostrar al administrador."""


def clave_version(v: str) -> tuple[int, ...]:
    nums = re.findall(r"\d+", v or "")
    return tuple(int(n) for n in nums) or (0,)


def _validar_meta(codigo: str, version: str | None, tipo: str, categoria: str) -> None:
    if not _RE_CODIGO.match(codigo or ""):
        raise ErrorDocumento("El código admite letras, números, punto, guion y guion bajo (máx. 30).")
    if version is not None and not _RE_VERSION.match(version):
        raise ErrorDocumento("La versión admite letras, números, punto y guion (máx. 10).")
    if tipo not in TIPOS:
        raise ErrorDocumento("Tipo de documento inválido.")
    if not (categoria or "").strip() or len(categoria.strip()) > 80 or categoria.strip() == "*":
        raise ErrorDocumento("La categoría es obligatoria (máx. 80 caracteres).")


def _meta_vector(doc: dict) -> dict:
    return {"id_documento": doc["id_documento"], "categoria": doc["categoria"]}


# ----------------------------------------------------------------------------
# Alta
# ----------------------------------------------------------------------------
def registrar(
    contenido: bytes,
    nombre_original: str,
    *,
    codigo: str,
    titulo: str | None,
    tipo: str,
    version: str,
    categoria: str,
    ctx: Contexto | None,
    proceso_replicado: str | None = None,
    capacidad_validada: str | None = None,
) -> dict:
    s = get_settings()
    codigo, version, categoria = (codigo or "").strip(), (version or "").strip(), (categoria or "").strip()
    _validar_meta(codigo, version, tipo, categoria)
    if not nombre_original.lower().endswith(".pdf") or not contenido.startswith(b"%PDF"):
        raise ErrorDocumento("El archivo no es un PDF válido.")
    if len(contenido) > s.max_upload_mb * 1024 * 1024:
        raise ErrorDocumento(f"El archivo supera el máximo de {s.max_upload_mb} MB.")

    existentes = repo.documentos_por_codigo(codigo)
    for e in existentes:
        if e["version"] == version:
            raise ErrorDocumento(f"Ya existe la versión {version} de {codigo}.")
        if clave_version(e["version"]) > clave_version(version):
            raise ErrorDocumento(
                f"{codigo} ya tiene una versión posterior ({e['version']}). Solo se indexa la última versión."
            )

    try:
        paginas, titulo_pdf = texto.extraer_paginas(contenido)
    except texto.ErrorExtraccion as e:
        raise ErrorDocumento(str(e)) from e

    titulo_final = (titulo or "").strip() or titulo_pdf or Path(nombre_original).stem
    archivo = f"{uuid.uuid4().hex}.pdf"
    s.docs_dir.mkdir(parents=True, exist_ok=True)
    ruta = s.docs_dir / archivo
    ruta.write_bytes(contenido)
    try:
        id_doc = repo.crear_documento(
            {
                "codigo": codigo, "titulo": titulo_final[:200], "tipo": tipo, "version": version,
                "categoria": categoria[:80], "archivo": archivo,
                "nombre_original": nombre_original[:260], "hash_archivo": hashlib.sha256(contenido).hexdigest(),
                "paginas": len(paginas), "id_usuario_alta": ctx.id_usuario if ctx else None,
                "proceso_replicado": (proceso_replicado or None) and proceso_replicado[:150],
                "capacidad_validada": (capacidad_validada or None) and capacidad_validada[:200],
            }
        )
    except Exception:
        ruta.unlink(missing_ok=True)
        raise

    retiradas = []
    for e in existentes:  # versiones anteriores: dejan de estar vigentes y de recuperarse
        if e["vigente"]:
            _retirar(e, ctx, motivo=f"reemplazada por la versión {version}")
            retiradas.append(e["version"])

    auditar("DOC_ALTA", "ok", ctx, detalle=f"{codigo} v{version} ({nombre_original})")
    resultado = {"id_documento": id_doc, "codigo": codigo, "version": version, "indexado": False,
                 "error": None, "retiradas": retiradas}
    try:
        indexar_documento(id_doc, ctx)
        resultado["indexado"] = True
    except ErrorDocumento as e:
        resultado["error"] = str(e)
    return resultado


# ----------------------------------------------------------------------------
# Indexacion
# ----------------------------------------------------------------------------
def indexar_documento(id_documento: int, ctx: Contexto | None = None) -> int:
    """(Re)genera fragmentos y vectores de un documento vigente. Devuelve la cantidad de fragmentos."""
    s = get_settings()
    doc = repo.documento_por_id(id_documento)
    if not doc:
        raise ErrorDocumento("El documento no existe.")
    if not doc["vigente"]:
        raise ErrorDocumento("Solo se indexan versiones vigentes.")
    try:
        ruta = s.docs_dir / doc["archivo"]
        if not ruta.exists():
            raise ErrorDocumento("No se encuentra el archivo PDF guardado.")
        paginas, _ = texto.extraer_paginas(ruta.read_bytes())
        frs = texto.fragmentar(paginas, s.chunk_chars, s.chunk_overlap)
        if not frs:
            raise ErrorDocumento("El documento no produjo fragmentos de texto.")
        # Se incluye titulo, codigo y seccion en el texto que se vectoriza: mejora la recuperacion
        entradas = [
            f"{doc['titulo']} ({doc['codigo']})" + (f" — {f['seccion']}" if f["seccion"] else "") + "\n" + f["texto"]
            for f in frs
        ]
        vectores = llm.embed_documentos(entradas)  # si falla, no se toca nada de lo existente

        indice = obtener_indice()
        indice.quitar(repo.ids_vectores_de_documento(id_documento))
        repo.borrar_fragmentos(id_documento)
        ids = repo.insertar_fragmentos(id_documento, frs)
        indice.agregar(ids, vectores, [_meta_vector(doc)] * len(ids))
        repo.marcar_indexado(id_documento, True)
        repo.guardar_resumen(id_documento, None)   # el resumen se recalcula la proxima vez que se pida
        lexico.invalidar()
    except (texto.ErrorExtraccion, llm.ErrorModelo, ErrorDocumento) as e:
        msg = "El servicio del modelo no está disponible." if isinstance(e, llm.ServicioLLMNoDisponible) else str(e)
        repo.marcar_indexado(id_documento, False, msg)
        raise ErrorDocumento(msg) from e
    auditar("REINDEXACION", "ok", ctx, detalle=f"{doc['codigo']} v{doc['version']}: {len(frs)} fragmentos")
    return len(frs)


def _retirar(doc: dict, ctx: Contexto | None, motivo: str) -> None:
    obtener_indice().quitar(repo.ids_vectores_de_documento(doc["id_documento"]))
    repo.borrar_fragmentos(doc["id_documento"])
    repo.marcar_no_vigente(doc["id_documento"])
    lexico.invalidar()
    auditar("DOC_BAJA", "ok", ctx, detalle=f"{doc['codigo']} v{doc['version']}: {motivo}")


def dar_de_baja(id_documento: int, ctx: Contexto | None) -> None:
    doc = repo.documento_por_id(id_documento)
    if not doc:
        raise ErrorDocumento("El documento no existe.")
    if not doc["vigente"]:
        raise ErrorDocumento("El documento ya no está vigente.")
    _retirar(doc, ctx, motivo="dado de baja por el administrador")


def actualizar_metadatos(
    id_documento: int, *, titulo: str, tipo: str, categoria: str,
    proceso_replicado: str | None, capacidad_validada: str | None, ctx: Contexto | None,
) -> None:
    doc = repo.documento_por_id(id_documento)
    if not doc:
        raise ErrorDocumento("El documento no existe.")
    _validar_meta(doc["codigo"], None, tipo, categoria)
    if not (titulo or "").strip():
        raise ErrorDocumento("El título es obligatorio.")
    repo.actualizar_documento(
        id_documento,
        {
            "titulo": titulo.strip()[:200], "tipo": tipo, "categoria": categoria.strip()[:80],
            "proceso_replicado": (proceso_replicado or "").strip()[:150] or None,
            "capacidad_validada": (capacidad_validada or "").strip()[:200] or None,
        },
    )
    if doc["indexado"]:
        # el control de acceso depende de la categoria: se replica en los vectores sin recalcular embeddings
        obtener_indice().actualizar_meta_documento(id_documento, categoria=categoria.strip()[:80])
        lexico.invalidar()
    if doc["categoria"] != categoria.strip()[:80]:
        auditar("DOC_ACCESO", "ok", ctx,
                detalle=f"{doc['codigo']} v{doc['version']}: categoría {doc['categoria']} -> {categoria.strip()}")


def reindexar_todo(ctx: Contexto | None = None) -> dict:
    """Reconstruye el indice completo desde los PDF guardados (por ejemplo, tras cambiar de modelo de embeddings)."""
    obtener_indice().vaciar()
    lexico.invalidar()
    ok, errores = 0, []
    for d in repo.listar_documentos():
        if not d["vigente"]:
            continue
        try:
            indexar_documento(d["id_documento"], ctx)
            ok += 1
        except ErrorDocumento as e:
            errores.append(f"{d['codigo']} v{d['version']}: {e}")
    return {"indexados": ok, "errores": errores}


# ----------------------------------------------------------------------------
# Busqueda
# ----------------------------------------------------------------------------
def advertencia_version(codigo: str, version: str) -> str | None:
    vigente = repo.documento_vigente_por_codigo(codigo)
    if vigente is None:
        return "Este documento fue dado de baja."
    if vigente["version"] != version:
        return f"Existe una versión vigente posterior ({vigente['version']})."
    return None


MAX_CHARS_CONTEXTO = 20000


def fusionar_rangos(*rankings: list[int], k: int = 60) -> list[int]:
    """Fusion por rangos reciprocos (RRF): un fragmento bien ubicado en varias listas sube. No requiere comparar puntajes."""
    puntaje: dict[int, float] = {}
    for ranking in rankings:
        for pos, i in enumerate(ranking):
            puntaje[i] = puntaje.get(i, 0.0) + 1.0 / (k + pos + 1)
    return [i for i, _ in sorted(puntaje.items(), key=lambda x: -x[1])]


def _cargar_lexico():
    for f in repo.fragmentos_para_lexico():
        cabecera = f"{f['codigo']} {f['titulo']} {f['seccion'] or ''}"
        yield f["id_fragmento"], f"{cabecera}\n{f['texto']}", {"categoria": f["categoria"], "id_documento": f["id_documento"]}


def _unir(anterior: str, siguiente: str) -> str:
    """Concatena dos fragmentos contiguos sin repetir el solapamiento entre ellos."""
    for n in range(min(len(anterior), len(siguiente), 500), 19, -1):
        if anterior.endswith(siguiente[:n]):
            return anterior + siguiente[n:]
    return anterior + "\n" + siguiente


def _expandir_con_vecinos(seleccion: list[dict], cuantos: int = 4) -> None:
    """Agrega a los primeros fragmentos el anterior y el siguiente del mismo documento: una frase suelta rara vez alcanza."""
    objetivo = seleccion[:cuantos]
    vecinos = repo.fragmentos_vecinos([(f["id_documento"], f["orden"]) for f in objetivo])
    por_posicion = {(v["id_documento"], v["orden"]): v["texto"] for v in vecinos}
    gastado = sum(len(f["texto"]) for f in seleccion)
    for f in objetivo:
        antes = por_posicion.get((f["id_documento"], f["orden"] - 1))
        despues = por_posicion.get((f["id_documento"], f["orden"] + 1))
        extra = len(antes or "") + len(despues or "")
        if gastado + extra > MAX_CHARS_CONTEXTO:
            break
        t = f["texto"]
        if antes:
            t = _unir(antes, t)
        if despues:
            t = _unir(t, despues)
        f["texto"], f["expandido"] = t, True
        gastado += extra


def buscar(pregunta: str, alcance: rbac.Alcance, k: int | None = None) -> list[dict]:
    """Fragmentos relevantes entre los que el alcance del usuario habilita.
    1) embeddings (significado) y BM25 (palabras exactas), cada uno con el filtro por permisos ya aplicado;
    2) fusion por rangos; 3) el modelo auxiliar reordena y descarta los que no sirven; 4) se amplian con los fragmentos vecinos."""
    s = get_settings()
    k = k or s.rag_top_k
    permitido = lambda m: rbac.puede_ver_documento(m.get("categoria"), alcance)  # noqa: E731

    vector = llm.embed_consulta(pregunta)
    densos = [(i, sc) for i, sc in obtener_indice().buscar(vector, s.rag_candidatos, permitido) if sc >= s.rag_score_minimo]
    puntaje_denso = dict(densos)
    lexicos = lexico.obtener(_cargar_lexico).buscar(pregunta, s.rag_candidatos, permitido, min_terminos=2)
    orden = fusionar_rangos([i for i, _ in densos], [i for i, _, _ in lexicos])[: max(2 * k, 12)]
    if not orden:
        return []

    por_id = {f["id_fragmento"]: f for f in repo.fragmentos_por_ids(orden)}
    candidatos = []
    for i in orden:
        f = por_id.get(i)
        if not f or not f["vigente"]:  # defensa extra: nunca devolver una version no vigente
            continue
        candidatos.append({
            "id_fragmento": i, "id_documento": f["id_documento"], "orden": f["orden"], "codigo": f["codigo"], "titulo": f["titulo"],
            "version": f["version"], "seccion": f["seccion"], "pagina": f["pagina"], "texto": f["texto"],
            "score": round(puntaje_denso.get(i, 0.0), 4),
        })
    if s.rag_rerank and len(candidatos) > 1:
        reordenados = refinar.reordenar(pregunta, candidatos, k)
        if reordenados is not None:      # None = el modelo fallo: se sigue con el orden por similitud
            candidatos = reordenados
    seleccion = candidatos[:k]
    if not seleccion:
        return []
    _expandir_con_vecinos(seleccion)
    for f in seleccion:
        f["advertencia"] = advertencia_version(f["codigo"], f["version"])
    return seleccion


# ----------------------------------------------------------------------------
# Resumenes
# ----------------------------------------------------------------------------
def _documentos_nombrados(pregunta: str, docs: list[dict]) -> list[dict]:
    """Documentos que la pregunta nombra por codigo (M1L2) o por varias palabras de su titulo."""
    plano = re.sub(r"[^a-z0-9]", "", "".join(lexico.tokenizar_plano(pregunta)))
    q = set(lexico.tokenizar(pregunta))
    elegidos = []
    for d in docs:
        codigo = re.sub(r"[^a-z0-9]", "", d["codigo"].lower())
        t = set(lexico.tokenizar(d["titulo"]))
        if (len(codigo) >= 3 and codigo in plano) or (len(t & q) >= 2 and len(t & q) >= math.ceil(len(t) / 2)):
            elegidos.append(d)
    return elegidos


def _muestra_de_texto(fragmentos: list[dict], maximo: int = 14000) -> str:
    textos = [f["texto"] for f in fragmentos]
    total = sum(len(t) for t in textos)
    if total <= maximo:
        return "\n".join(textos)
    # documento largo: principio, tramos repartidos y final
    n = len(textos)
    cuantos = max(3, maximo // 1300)
    pasos = sorted({0, 1, n - 1} | {round(i * (n - 1) / (cuantos - 1)) for i in range(cuantos)})
    return "\n[...]\n".join(textos[p] for p in pasos)[:maximo]


def _generar_resumen(doc: dict) -> str | None:
    try:
        frs = repo.texto_de_documento(doc["id_documento"])
        if not frs:
            return None
        secciones = list(dict.fromkeys(f["seccion"] for f in frs if f["seccion"]))
        resumen = refinar.resumir(doc["titulo"], secciones, _muestra_de_texto(frs))
        repo.guardar_resumen(doc["id_documento"], resumen)
        return resumen
    except llm.ErrorModelo as e:
        log.warning("No se pudo resumir %s: %s", doc["codigo"], e)
        return None


def resumenes(pregunta: str, alcance: rbac.Alcance, max_docs: int = 8) -> tuple[list[dict], int]:
    """Resumen de los documentos que el usuario puede ver: los que la pregunta nombra o, si no nombra ninguno, todos.
    El resumen se genera la primera vez que se pide (en paralelo) y se guarda. Devuelve (resumenes, total_de_documentos)."""
    docs = [d for d in repo.documentos_para_resumen() if rbac.puede_ver_documento(d["categoria"], alcance)]
    if not docs:
        return [], 0
    elegidos = _documentos_nombrados(pregunta, docs) or docs
    total = len(elegidos)
    elegidos = elegidos[:max_docs]
    faltan = [d for d in elegidos if not d["resumen"]]
    if faltan:
        with ThreadPoolExecutor(max_workers=min(4, len(faltan))) as pool:
            for d, r in zip(faltan, pool.map(_generar_resumen, faltan)):
                if r:
                    d["resumen"] = r
    salida = []
    for d in elegidos:
        if d["resumen"]:
            cuerpo, seccion = d["resumen"], "Resumen del documento"
        else:  # el modelo no pudo resumir: se ofrece el comienzo del documento, aclarando que es un extracto
            cuerpo = "\n".join(f["texto"] for f in repo.texto_de_documento(d["id_documento"])[:2])[:1500]
            seccion = "Extracto inicial (no se pudo generar el resumen)"
        salida.append({
            "id_fragmento": None, "id_documento": d["id_documento"], "codigo": d["codigo"], "titulo": d["titulo"],
            "version": d["version"], "seccion": seccion, "pagina": None, "texto": cuerpo, "score": None,
            "advertencia": None,
        })
    return salida, total
