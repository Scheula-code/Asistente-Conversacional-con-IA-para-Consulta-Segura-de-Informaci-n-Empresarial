"""Indice vectorial FAISS (corre dentro del mismo servidor, sin servicio adicional).

El filtro por rol se aplica ANTES de recuperar: la busqueda solo considera los vectores cuyos
metadatos (area propietaria y nivel de acceso, replicados desde el documento) habilitan al usuario,
de modo que un fragmento no autorizado nunca llega al contexto del modelo (HU-009).

El identificador del vector en FAISS es el id_fragmento de la base relacional.
Un solo proceso debe atender la aplicacion (uvicorn sin --workers): el indice vive en memoria.
"""
from __future__ import annotations

import json
import os
import threading
from pathlib import Path
from typing import Callable

import numpy as np

_ARCHIVO_INDICE = "faiss.index"
_ARCHIVO_META = "meta.json"


class IndiceVectorial:
    def __init__(self, directorio: Path, dimension: int):
        import faiss

        self._faiss = faiss
        self.dir = Path(directorio)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.dim = dimension
        self._lock = threading.RLock()
        self._meta: dict[str, dict] = {}
        self._index = self._cargar()

    # ------------------------------------------------------------------ persistencia
    def _cargar(self):
        faiss = self._faiss
        ruta_i, ruta_m = self.dir / _ARCHIVO_INDICE, self.dir / _ARCHIVO_META
        if ruta_i.exists() and ruta_m.exists():
            # se lee por bytes (y no por ruta) para evitar problemas con rutas no ASCII en Windows
            idx = faiss.deserialize_index(np.frombuffer(ruta_i.read_bytes(), dtype="uint8"))
            self._meta = json.loads(ruta_m.read_text(encoding="utf-8"))
            if idx.d != self.dim:
                raise RuntimeError(
                    f"El índice guardado tiene dimensión {idx.d} y se esperaba {self.dim}. "
                    "Cambió el modelo de embeddings: hay que reconstruirlo (scripts.reindexar --todo)."
                )
            return idx
        self._meta = {}
        return faiss.IndexIDMap2(faiss.IndexFlatIP(self.dim))  # producto interno sobre vectores normalizados = coseno

    def _guardar(self) -> None:
        faiss = self._faiss
        datos = faiss.serialize_index(self._index).tobytes()
        for ruta, contenido, modo in (
            (self.dir / _ARCHIVO_INDICE, datos, "wb"),
            (self.dir / _ARCHIVO_META, json.dumps(self._meta, ensure_ascii=False).encode("utf-8"), "wb"),
        ):
            tmp = ruta.with_suffix(ruta.suffix + ".tmp")
            with open(tmp, modo) as f:
                f.write(contenido)
            os.replace(tmp, ruta)  # reemplazo atomico

    # ------------------------------------------------------------------ operaciones
    @property
    def total(self) -> int:
        with self._lock:
            return int(self._index.ntotal)

    def agregar(self, ids: list[int], vectores: np.ndarray, metas: list[dict]) -> None:
        if len(ids) != len(vectores) or len(ids) != len(metas):
            raise ValueError("ids, vectores y metadatos deben tener la misma longitud")
        if len(ids) == 0:
            return
        if vectores.shape[1] != self.dim:
            raise ValueError(f"Dimensión de embedding {vectores.shape[1]} distinta de la del índice ({self.dim})")
        with self._lock:
            arr = np.array(ids, dtype="int64")
            self._index.remove_ids(arr)  # por si se reindexa el mismo fragmento
            self._index.add_with_ids(np.ascontiguousarray(vectores, dtype="float32"), arr)
            for i, m in zip(ids, metas):
                self._meta[str(i)] = m
            self._guardar()

    def quitar(self, ids: list[int]) -> int:
        if not ids:
            return 0
        with self._lock:
            n = int(self._index.remove_ids(np.array(ids, dtype="int64")))
            for i in ids:
                self._meta.pop(str(i), None)
            self._guardar()
            return n

    def actualizar_meta_documento(self, id_documento: int, **campos) -> int:
        """Cambia area/nivel de todos los vectores de un documento sin recalcular embeddings."""
        with self._lock:
            n = 0
            for m in self._meta.values():
                if m.get("id_documento") == id_documento:
                    m.update(campos)
                    n += 1
            if n:
                self._guardar()
            return n

    def buscar(
        self, vector: np.ndarray, k: int, permitido: Callable[[dict], bool]
    ) -> list[tuple[int, float]]:
        """Devuelve [(id_fragmento, similitud)] solo entre los vectores que `permitido(meta)` habilita."""
        with self._lock:
            if self._index.ntotal == 0:
                return []
            habilitados = [int(i) for i, m in self._meta.items() if permitido(m)]
            if not habilitados:
                return []
            faiss = self._faiss
            sel_ids = np.array(habilitados, dtype="int64")
            params = faiss.SearchParameters()
            params.sel = faiss.IDSelectorBatch(sel_ids)
            q = np.ascontiguousarray(vector.reshape(1, -1), dtype="float32")
            D, I = self._index.search(q, min(k, len(habilitados)), params=params)
            return [(int(i), float(d)) for i, d in zip(I[0], D[0]) if i != -1]

    def vaciar(self) -> None:
        with self._lock:
            self._index = self._faiss.IndexIDMap2(self._faiss.IndexFlatIP(self.dim))
            self._meta = {}
            self._guardar()


_indice: IndiceVectorial | None = None
_lock_global = threading.Lock()


def obtener_indice() -> IndiceVectorial:
    global _indice
    with _lock_global:
        if _indice is None:
            from ..config import get_settings

            s = get_settings()
            _indice = IndiceVectorial(s.indice_dir, s.embedding_dim)
        return _indice


def reiniciar_singleton() -> None:  # util para pruebas
    global _indice
    with _lock_global:
        _indice = None
