"""Politica de contrasenas y almacenamiento (seccion Seguridad > Acceso a la Aplicacion).

* Minimo de 12 caracteres con al menos una mayuscula, una minuscula y un digito.
* Se guarda solo el resumen producido por una funcion de derivacion (scrypt) con sal propia
  de cada usuario; la sal viaja dentro del mismo texto: scrypt$N$r$p$sal$hash.
* No se puede reutilizar ninguna de las ultimas cinco (el chequeo lo hace el servicio de auth).
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import re
import secrets

from ..config import get_settings

_N, _R, _P = 2**14, 8, 1
_DKLEN = 32


def validar_politica(clave: str) -> list[str]:
    """Devuelve la lista de incumplimientos (vacia si la clave es valida)."""
    s = get_settings()
    errores: list[str] = []
    if len(clave) < s.clave_min_largo:
        errores.append(f"Debe tener al menos {s.clave_min_largo} caracteres.")
    if not re.search(r"[A-ZÁÉÍÓÚÑ]", clave):
        errores.append("Debe incluir al menos una mayúscula.")
    if not re.search(r"[a-záéíóúñ]", clave):
        errores.append("Debe incluir al menos una minúscula.")
    if not re.search(r"\d", clave):
        errores.append("Debe incluir al menos un dígito.")
    return errores


def hashear(clave: str) -> str:
    sal = secrets.token_bytes(16)
    h = hashlib.scrypt(clave.encode("utf-8"), salt=sal, n=_N, r=_R, p=_P, dklen=_DKLEN)
    return "scrypt${}${}${}${}${}".format(
        _N, _R, _P, base64.b64encode(sal).decode(), base64.b64encode(h).decode()
    )


def verificar(clave: str, almacenado: str) -> bool:
    try:
        esquema, n, r, p, sal_b64, h_b64 = almacenado.split("$")
        if esquema != "scrypt":
            return False
        sal = base64.b64decode(sal_b64)
        esperado = base64.b64decode(h_b64)
        h = hashlib.scrypt(
            clave.encode("utf-8"), salt=sal, n=int(n), r=int(r), p=int(p), dklen=len(esperado)
        )
        return hmac.compare_digest(h, esperado)
    except Exception:
        return False


# Hash de relleno para igualar el tiempo de respuesta cuando el usuario no existe
HASH_FICTICIO = hashear("relleno-" + secrets.token_hex(8))


def generar_temporal() -> str:
    """Clave temporal que cumple la politica. El usuario debe cambiarla en el primer ingreso."""
    alfabeto = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    while True:
        c = "".join(secrets.choice(alfabeto) for _ in range(14))
        if not validar_politica(c):
            return c
