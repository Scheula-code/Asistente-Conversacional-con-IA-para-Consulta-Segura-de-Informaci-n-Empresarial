"""Autenticacion, sesiones y cambio de clave (HU-008, seccion Seguridad del TFG).

* Padron propio de usuarios (el directorio corporativo queda como paso siguiente).
* Cinco intentos fallidos consecutivos bloquean la cuenta; solo el administrador la habilita.
* Sesion: 30 minutos de inactividad y 8 horas como maximo; una sola sesion activa por usuario.
* El rol se lee de la base en cada pedido: un cambio de rol rige en la consulta siguiente.
"""
from __future__ import annotations

import hashlib
import secrets
from dataclasses import dataclass

from .. import repo
from ..config import get_settings
from . import passwords

MSG_GENERICO = "Usuario o contraseña incorrectos."
MSG_BLOQUEADA = "La cuenta está bloqueada. Solicite su habilitación al administrador."


class ErrorAuth(Exception):
    """Mensaje apto para mostrar al usuario."""


@dataclass(frozen=True)
class Contexto:
    id_sesion: int
    id_usuario: int
    nombre: str
    email: str
    area: str | None
    ids_roles: tuple[int, ...]
    codigos_roles: tuple[str, ...]
    requiere_cambio_clave: bool
    ip: str | None = None

    @property
    def rol_codigo(self) -> str:
        return ",".join(self.codigos_roles)[:200]

    @property
    def rol_nombre(self) -> str:
        return ", ".join(self.codigos_roles)

    @property
    def es_admin(self) -> bool:
        return any(c.lower() == "administracion" for c in self.codigos_roles)

    @property
    def consulta(self) -> bool:
        """Tiene al menos un rol de consulta (distinto de administracion)."""
        return any(c.lower() != "administracion" for c in self.codigos_roles)


# ----------------------------------------------------------------------------
def auditar(
    tipo: str, resultado: str, ctx: Contexto | None = None, *, usuario_ref: str | None = None, **kw
) -> None:
    """Un unico punto de entrada para escribir en AUDITORIA."""
    repo.insertar_auditoria(
        tipo,
        resultado,
        id_usuario=ctx.id_usuario if ctx else kw.pop("id_usuario", None),
        usuario_ref=usuario_ref or (ctx.email if ctx else None),
        rol=ctx.rol_codigo if ctx else kw.pop("rol", None),
        ip=kw.pop("ip", None) or (ctx.ip if ctx else None),
        **kw,
    )


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def _clave_vencida(u: dict) -> bool:
    return bool(u["debe_cambiar_clave"]) or (u["dias_clave"] or 0) >= get_settings().clave_vence_dias


def _contexto(u: dict, id_sesion: int, ip: str | None) -> Contexto:
    roles = repo.roles_de_usuario(u["id_usuario"])
    return Contexto(
        id_sesion=id_sesion,
        id_usuario=u["id_usuario"],
        nombre=u["nombre"],
        email=u["email"],
        area=u["area"],
        ids_roles=tuple(r["id_rol"] for r in roles),
        codigos_roles=tuple(r["codigo"] for r in roles),
        requiere_cambio_clave=_clave_vencida(u),
        ip=ip,
    )


# ----------------------------------------------------------------------------
def iniciar_sesion(email: str, clave: str, ip: str | None) -> tuple[str, Contexto]:
    s = get_settings()
    email = (email or "").strip().lower()
    u = repo.usuario_por_email(email) if email else None

    if u is None:
        passwords.verificar(clave, passwords.HASH_FICTICIO)  # iguala tiempos de respuesta
        auditar("LOGIN_FALLIDO", "error", usuario_ref=email or None, motivo="usuario inexistente", ip=ip)
        raise ErrorAuth(MSG_GENERICO)

    if not u["activo"]:
        passwords.verificar(clave, passwords.HASH_FICTICIO)
        auditar("LOGIN_FALLIDO", "error", usuario_ref=email, id_usuario=u["id_usuario"],
                motivo="usuario dado de baja", ip=ip)
        raise ErrorAuth(MSG_GENERICO)

    if u["bloqueado"]:
        auditar("LOGIN_FALLIDO", "error", usuario_ref=email, id_usuario=u["id_usuario"],
                motivo="cuenta bloqueada", ip=ip)
        raise ErrorAuth(MSG_BLOQUEADA)

    if not passwords.verificar(clave, u["clave_hash"]):
        n = repo.sumar_intento_fallido(u["id_usuario"])
        auditar("LOGIN_FALLIDO", "error", usuario_ref=email, id_usuario=u["id_usuario"],
                detalle=f"intento {n} de {s.max_intentos}", ip=ip)
        if n >= s.max_intentos:
            repo.bloquear_usuario(u["id_usuario"])
            auditar("CUENTA_BLOQUEADA", "ok", usuario_ref=email, id_usuario=u["id_usuario"],
                    detalle=f"{n} intentos fallidos consecutivos", ip=ip)
            raise ErrorAuth(MSG_BLOQUEADA)
        raise ErrorAuth(MSG_GENERICO)

    if not repo.roles_de_usuario(u["id_usuario"]):
        auditar("LOGIN_FALLIDO", "error", usuario_ref=email, id_usuario=u["id_usuario"], motivo="usuario sin roles", ip=ip)
        raise ErrorAuth("Su usuario no tiene roles asignados. Solicite la asignación al administrador.")
    repo.reiniciar_intentos(u["id_usuario"])
    token = secrets.token_urlsafe(32)
    repo.crear_sesion(_hash_token(token), u["id_usuario"], ip)
    sesion = repo.sesion_por_token(_hash_token(token))
    ctx = _contexto(u, sesion["id_sesion"], ip)
    auditar("LOGIN_OK", "ok", ctx)
    return token, ctx


def contexto_desde_token(token: str | None, ip: str | None = None) -> Contexto | None:
    if not token:
        return None
    s = get_settings()
    th = _hash_token(token)
    ses = repo.sesion_por_token(th)
    if ses is None:
        return None
    if ses["inactivo_s"] > s.sesion_inactividad_min * 60:
        repo.cerrar_sesion(ses["id_sesion"], "inactividad")
        auditar("SESION_EXPIRADA", "ok", id_usuario=ses["id_usuario"], detalle="inactividad", ip=ip)
        return None
    if ses["edad_s"] > s.sesion_max_horas * 3600:
        repo.cerrar_sesion(ses["id_sesion"], "limite_horas")
        auditar("SESION_EXPIRADA", "ok", id_usuario=ses["id_usuario"], detalle="limite de 8 horas", ip=ip)
        return None
    u = repo.usuario_por_id(ses["id_usuario"])
    if u is None or not u["activo"] or u["bloqueado"]:
        repo.cerrar_sesion(ses["id_sesion"], "usuario_no_habilitado")
        return None
    repo.tocar_sesion(ses["id_sesion"])
    return _contexto(u, ses["id_sesion"], ip)


def cerrar_sesion(ctx: Contexto) -> None:
    repo.cerrar_sesion(ctx.id_sesion, "logout")
    auditar("LOGOUT", "ok", ctx)


def cambiar_clave(ctx: Contexto, actual: str, nueva: str, confirmacion: str) -> list[str]:
    """Devuelve la lista de errores; vacia si la clave se cambio."""
    s = get_settings()
    u = repo.usuario_por_id(ctx.id_usuario)
    if u is None or not passwords.verificar(actual, u["clave_hash"]):
        return ["La contraseña actual no es correcta."]
    if nueva != confirmacion:
        return ["La confirmación no coincide con la nueva contraseña."]
    errores = passwords.validar_politica(nueva)
    if errores:
        return errores
    for previa in repo.ultimas_claves(ctx.id_usuario, s.clave_historial):
        if passwords.verificar(nueva, previa):
            return [f"No puede reutilizar ninguna de las últimas {s.clave_historial} contraseñas."]
    repo.guardar_clave(ctx.id_usuario, passwords.hashear(nueva), forzar_cambio=False)
    auditar("CAMBIO_CLAVE", "ok", ctx)
    return []
