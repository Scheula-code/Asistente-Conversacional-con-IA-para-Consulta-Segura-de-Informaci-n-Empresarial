"""Control de acceso basado en roles (Sandhu et al., 1996).

Cuatro dimensiones (seccion TIC del marco teorico): documentos, tablas, columnas y registros.
Logica pura: recibe las filas de PERMISO ya leidas (de TODOS los roles del usuario) y decide. La decision de
autorizacion nunca queda en manos del modelo de lenguaje.

Un usuario puede tener varios roles y lo que puede ver es la UNION de lo que concede cada uno:
  documentos : categorias de todos los roles ('*' = todas).
  tablas     : una tabla es visible si algun rol la concede. Si un rol la da completa y otro solo por area, gana la completa.
  columnas   : dentro de cada rol, 'lectura' es lista blanca y 'denegado' lista negra; una columna es visible
               si algun rol que concede esa tabla la deja ver. Una denegacion solo vale dentro de su rol.
Convenciones de PERMISO: documento 'categoria' o '*'; tabla 'esquema.tabla' (lectura | lectura_area);
columna 'esquema.tabla.col' (lectura | denegado).
"""
from __future__ import annotations

import unicodedata
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Iterable, Mapping


def normalizar(texto: str | None) -> str:
    """Minusculas, sin tildes y sin espacios sobrantes, para comparar categorias."""
    if not texto:
        return ""
    t = unicodedata.normalize("NFKD", texto)
    t = "".join(c for c in t if not unicodedata.combining(c))
    return " ".join(t.lower().split())


# ----------------------------------------------------------------------------
# Documentos
# ----------------------------------------------------------------------------
@dataclass(frozen=True)
class Alcance:
    habilitado: bool = False                                   # algun rol tiene permiso documental
    todas: bool = False                                        # ve todas las categorias
    categorias: frozenset[str] = field(default_factory=frozenset)  # categorias normalizadas


def alcance_documental(permisos: Iterable[Mapping]) -> Alcance:
    habilitado = False
    todas = False
    categorias: set[str] = set()
    for p in permisos:
        if p["tipo_recurso"] != "documento" or p["nivel_acceso"] == "denegado":
            continue
        habilitado = True
        r = (p["recurso"] or "").strip()
        if r == "*":
            todas = True
        elif r:
            categorias.add(normalizar(r))
    return Alcance(habilitado=habilitado, todas=todas, categorias=frozenset(categorias))


def puede_ver_documento(categoria: str | None, alcance: Alcance) -> bool:
    if not alcance.habilitado:
        return False
    return alcance.todas or normalizar(categoria) in alcance.categorias


# ----------------------------------------------------------------------------
# Datos
# ----------------------------------------------------------------------------
@dataclass(frozen=True)
class PermisoTabla:
    clave: str                                   # 'esquema.tabla' en minusculas
    por_area: bool                               # acotar registros por el area del usuario
    columnas_permitidas: frozenset[str] | None   # None = todas salvo las denegadas
    columnas_denegadas: frozenset[str]
    otras_reglas: tuple = ()                     # reglas de columnas de otros roles: ((permitidas|None, denegadas), ...)

    def columna_ok(self, columna: str) -> bool:
        c = columna.lower()
        reglas = ((self.columnas_permitidas, self.columnas_denegadas),) + tuple(self.otras_reglas)
        for permitidas, denegadas in reglas:
            if c in denegadas:
                continue
            if permitidas is None or c in permitidas:
                return True
        return False


def clave_tabla(esquema: str, tabla: str) -> str:
    return f"{esquema}.{tabla}".lower()


def _permisos_de_un_rol(filas: list[Mapping], activas: set[str]) -> dict[str, PermisoTabla]:
    resultado: dict[str, PermisoTabla] = {}
    for p in filas:
        if p["tipo_recurso"] != "tabla":
            continue
        clave = (p["recurso"] or "").lower().strip()
        if clave not in activas or p["nivel_acceso"] == "denegado":
            continue
        permitidas: set[str] = set()
        denegadas: set[str] = set()
        for c in filas:
            if c["tipo_recurso"] != "columna":
                continue
            rec = (c["recurso"] or "").lower().strip()
            if "." not in rec:
                continue
            tabla_c, col = rec.rsplit(".", 1)
            if tabla_c != clave:
                continue
            (denegadas if c["nivel_acceso"] == "denegado" else permitidas).add(col)
        resultado[clave] = PermisoTabla(
            clave=clave,
            por_area=(p["nivel_acceso"] == "lectura_area"),
            columnas_permitidas=frozenset(permitidas) if permitidas else None,
            columnas_denegadas=frozenset(denegadas),
        )
    return resultado


def permisos_datos(permisos: Iterable[Mapping], tablas_activas: Iterable[str]) -> dict[str, PermisoTabla]:
    """Une los permisos de todos los roles del usuario. Una tabla sin permiso explicito no aparece."""
    activas = {t.lower() for t in tablas_activas}
    por_rol: dict[int, list[Mapping]] = defaultdict(list)
    for p in permisos:
        por_rol[p.get("id_rol", 0)].append(p)
    parciales: dict[str, list[PermisoTabla]] = defaultdict(list)
    for filas in por_rol.values():
        for clave, pt in _permisos_de_un_rol(filas, activas).items():
            parciales[clave].append(pt)
    unidos: dict[str, PermisoTabla] = {}
    for clave, lista in parciales.items():
        base = lista[0]
        unidos[clave] = PermisoTabla(
            clave=clave,
            por_area=all(p.por_area for p in lista),
            columnas_permitidas=base.columnas_permitidas,
            columnas_denegadas=base.columnas_denegadas,
            otras_reglas=tuple((p.columnas_permitidas, p.columnas_denegadas) for p in lista[1:]),
        )
    return unidos
