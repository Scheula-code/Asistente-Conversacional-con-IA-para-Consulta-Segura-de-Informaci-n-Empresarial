"""Punto de entrada. Arranque:  uvicorn app.main:app --host 0.0.0.0 --port 8000   (UN solo proceso)."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from urllib.parse import urlparse

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.base import BaseHTTPMiddleware

from .config import get_settings
from .web import rutas_admin, rutas_auth, rutas_chat, rutas_docs
from .web.deps import BASE, Redireccion, plantillas

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("asistente")

_METODOS_QUE_ESCRIBEN = {"POST", "PUT", "PATCH", "DELETE"}
_CSP = (
    "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; "
    "frame-ancestors 'none'; form-action 'self'; base-uri 'self'"
)


def _origen_permitido(request: Request) -> bool:
    """Defensa contra CSRF, ademas de SameSite=Lax: un POST debe venir del mismo origen que la aplicacion."""
    origen = request.headers.get("origin")
    if not origen or origen == "null":
        ref = request.headers.get("referer")
        if not ref:
            return False
        p = urlparse(ref)
        origen = f"{p.scheme}://{p.netloc}"
    permitidos = {f"{request.url.scheme}://{request.headers.get('host', '')}".lower()}
    permitidos.update(o.lower() for o in get_settings().allowed_origins)
    return origen.rstrip("/").lower() in permitidos


class SeguridadMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.method in _METODOS_QUE_ESCRIBEN and not _origen_permitido(request):
            return JSONResponse({"detail": "Origen no permitido."}, status_code=403)
        resp = await call_next(request)
        resp.headers.setdefault("Content-Security-Policy", _CSP)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        if request.url.path.startswith("/static/"):
            # el navegador revalida (ETag) en cada carga: asi no queda con un chat.js o app.css viejo tras actualizar
            resp.headers["Cache-Control"] = "no-cache"
        else:
            resp.headers.setdefault("Cache-Control", "no-store")
        return resp


@asynccontextmanager
async def ciclo_de_vida(app: FastAPI):
    s = get_settings()
    s.docs_dir.mkdir(parents=True, exist_ok=True)
    s.indice_dir.mkdir(parents=True, exist_ok=True)
    if not s.openai_api_key:
        log.warning("OPENAI_API_KEY no está configurada: el asistente no podrá responder.")
    from .rag.indice import obtener_indice

    log.info("Índice vectorial cargado: %s vectores", obtener_indice().total)
    yield


app = FastAPI(title="Asistente conversacional (prototipo)", docs_url=None, redoc_url=None, openapi_url=None, lifespan=ciclo_de_vida)
app.add_middleware(SeguridadMiddleware)
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")
app.include_router(rutas_auth.router)
app.include_router(rutas_chat.router)
app.include_router(rutas_docs.router)
app.include_router(rutas_admin.router)


@app.exception_handler(Redireccion)
async def _redireccion(request: Request, exc: Redireccion):
    return RedirectResponse(exc.url, status_code=303)


@app.exception_handler(HTTPException)
async def _http_error(request: Request, exc: HTTPException):
    if request.url.path.startswith(("/api/", "/admin/api/")) or request.method != "GET":
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)
    return plantillas.TemplateResponse(
        request, "error.html", {"ctx": None, "codigo": exc.status_code, "detalle": exc.detail}, status_code=exc.status_code
    )


@app.exception_handler(Exception)
async def _error_interno(request: Request, exc: Exception):
    log.exception("Error no controlado en %s", request.url.path)  # el detalle va al log, no al usuario
    return JSONResponse({"detail": "Error interno. Intente nuevamente o avise a Sistemas."}, status_code=500)
