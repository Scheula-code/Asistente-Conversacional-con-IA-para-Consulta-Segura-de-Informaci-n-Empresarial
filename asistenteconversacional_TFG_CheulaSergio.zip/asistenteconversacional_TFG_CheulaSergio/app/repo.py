"""Consultas SQL sobre la base propia del prototipo.

Todas usan parametros (?): ningun valor del usuario se concatena en una sentencia.
Los unicos fragmentos dinamicos son los filtros opcionales de listar_auditoria(), que arman
la clausula WHERE solo con condiciones fijas y pasan los valores como parametros.
"""
from __future__ import annotations

from typing import Any, Iterable, Sequence

from . import db

# ----------------------------------------------------------------------------
# Usuarios
# ----------------------------------------------------------------------------
_SEL_USUARIO = """
SELECT u.id_usuario, u.nombre, u.email, u.area, u.activo, u.clave_hash, u.fecha_clave,
       u.intentos_fallidos, u.bloqueado, u.debe_cambiar_clave,
       DATEDIFF(DAY, u.fecha_clave, SYSUTCDATETIME()) AS dias_clave
FROM dbo.USUARIO u
"""


def usuario_por_email(email: str) -> dict | None:
    return db.consultar_uno(_SEL_USUARIO + " WHERE u.email = ?", (email.strip().lower(),))


def usuario_por_id(id_usuario: int) -> dict | None:
    return db.consultar_uno(_SEL_USUARIO + " WHERE u.id_usuario = ?", (id_usuario,))


def roles_de_usuario(id_usuario: int) -> list[dict]:
    return db.consultar(
        """SELECT r.id_rol, r.codigo, r.codigo AS nombre FROM dbo.USUARIO_ROL ur
           JOIN dbo.ROL r ON r.id_rol = ur.id_rol WHERE ur.id_usuario = ? ORDER BY r.codigo""",
        (id_usuario,),
    )


def listar_usuarios() -> list[dict]:
    usuarios = db.consultar(_SEL_USUARIO + " ORDER BY u.nombre")
    asignaciones = db.consultar(
        "SELECT ur.id_usuario, r.id_rol, r.codigo FROM dbo.USUARIO_ROL ur JOIN dbo.ROL r ON r.id_rol = ur.id_rol ORDER BY r.codigo"
    )
    for u in usuarios:
        propios = [a for a in asignaciones if a["id_usuario"] == u["id_usuario"]]
        u["roles"] = [a["codigo"] for a in propios]
        u["ids_roles"] = [a["id_rol"] for a in propios]
    return usuarios


def crear_usuario(nombre: str, email: str, area: str | None, ids_roles: list[int], clave_hash: str) -> int:
    with db.transaccion() as cur:
        cur.execute(
            """INSERT INTO dbo.USUARIO (nombre, email, area, clave_hash, debe_cambiar_clave)
               OUTPUT INSERTED.id_usuario VALUES (?, ?, ?, ?, 1)""",
            (nombre.strip(), email.strip().lower(), area, clave_hash),
        )
        nuevo = int(cur.fetchone()[0])
        for r in dict.fromkeys(ids_roles):
            cur.execute("INSERT INTO dbo.USUARIO_ROL (id_usuario, id_rol) VALUES (?, ?)", (nuevo, r))
        cur.execute("INSERT INTO dbo.HISTORIAL_CLAVE (id_usuario, clave_hash) VALUES (?, ?)", (nuevo, clave_hash))
        return nuevo


def actualizar_usuario(id_usuario: int, nombre: str, area: str | None, ids_roles: list[int], activo: bool) -> None:
    with db.transaccion() as cur:
        cur.execute(
            "UPDATE dbo.USUARIO SET nombre = ?, area = ?, activo = ? WHERE id_usuario = ?",
            (nombre.strip(), area, 1 if activo else 0, id_usuario),
        )
        cur.execute("DELETE FROM dbo.USUARIO_ROL WHERE id_usuario = ?", (id_usuario,))
        for r in dict.fromkeys(ids_roles):
            cur.execute("INSERT INTO dbo.USUARIO_ROL (id_usuario, id_rol) VALUES (?, ?)", (id_usuario, r))


def sumar_intento_fallido(id_usuario: int) -> int:
    with db.transaccion() as cur:
        cur.execute(
            "UPDATE dbo.USUARIO SET intentos_fallidos = intentos_fallidos + 1 "
            "OUTPUT INSERTED.intentos_fallidos WHERE id_usuario = ?",
            (id_usuario,),
        )
        return int(cur.fetchone()[0])


def bloquear_usuario(id_usuario: int) -> None:
    db.ejecutar("UPDATE dbo.USUARIO SET bloqueado = 1 WHERE id_usuario = ?", (id_usuario,))


def desbloquear_usuario(id_usuario: int) -> None:
    db.ejecutar(
        "UPDATE dbo.USUARIO SET bloqueado = 0, intentos_fallidos = 0 WHERE id_usuario = ?", (id_usuario,)
    )


def reiniciar_intentos(id_usuario: int) -> None:
    db.ejecutar("UPDATE dbo.USUARIO SET intentos_fallidos = 0 WHERE id_usuario = ?", (id_usuario,))


def ultimas_claves(id_usuario: int, n: int) -> list[str]:
    filas = db.consultar(
        "SELECT TOP (?) clave_hash FROM dbo.HISTORIAL_CLAVE WHERE id_usuario = ? ORDER BY id_historial DESC",
        (n, id_usuario),
    )
    return [f["clave_hash"] for f in filas]


def guardar_clave(id_usuario: int, clave_hash: str, forzar_cambio: bool) -> None:
    with db.transaccion() as cur:
        cur.execute(
            """UPDATE dbo.USUARIO SET clave_hash = ?, fecha_clave = SYSUTCDATETIME(),
                      debe_cambiar_clave = ?, intentos_fallidos = 0 WHERE id_usuario = ?""",
            (clave_hash, 1 if forzar_cambio else 0, id_usuario),
        )
        cur.execute("INSERT INTO dbo.HISTORIAL_CLAVE (id_usuario, clave_hash) VALUES (?, ?)", (id_usuario, clave_hash))


# ----------------------------------------------------------------------------
# Sesiones (una sola activa por usuario)
# ----------------------------------------------------------------------------
def crear_sesion(token_hash: str, id_usuario: int, ip: str | None) -> None:
    with db.transaccion() as cur:
        cur.execute(
            "UPDATE dbo.SESION SET activa = 0, motivo_cierre = 'nueva_sesion' WHERE id_usuario = ? AND activa = 1",
            (id_usuario,),
        )
        cur.execute(
            "INSERT INTO dbo.SESION (token_hash, id_usuario, ip) VALUES (?, ?, ?)", (token_hash, id_usuario, ip)
        )


def sesion_por_token(token_hash: str) -> dict | None:
    return db.consultar_uno(
        """SELECT id_sesion, id_usuario,
                  DATEDIFF(SECOND, ultima_actividad, SYSUTCDATETIME()) AS inactivo_s,
                  DATEDIFF(SECOND, inicio, SYSUTCDATETIME()) AS edad_s
           FROM dbo.SESION WHERE token_hash = ? AND activa = 1""",
        (token_hash,),
    )


def tocar_sesion(id_sesion: int) -> None:
    db.ejecutar("UPDATE dbo.SESION SET ultima_actividad = SYSUTCDATETIME() WHERE id_sesion = ?", (id_sesion,))


def cerrar_sesion(id_sesion: int, motivo: str) -> None:
    db.ejecutar("UPDATE dbo.SESION SET activa = 0, motivo_cierre = ? WHERE id_sesion = ?", (motivo, id_sesion))


def cerrar_sesiones_de_usuario(id_usuario: int, motivo: str) -> None:
    db.ejecutar(
        "UPDATE dbo.SESION SET activa = 0, motivo_cierre = ? WHERE id_usuario = ? AND activa = 1",
        (motivo, id_usuario),
    )


# ----------------------------------------------------------------------------
# Roles y permisos
# ----------------------------------------------------------------------------
_SEL_ROL = """
SELECT r.id_rol, r.codigo, r.codigo AS nombre, r.descripcion,
       (SELECT COUNT(*) FROM dbo.USUARIO_ROL ur WHERE ur.id_rol = r.id_rol) AS usuarios
FROM dbo.ROL r
"""


def listar_roles() -> list[dict]:
    return db.consultar(_SEL_ROL + " ORDER BY r.codigo")


def rol_por_id(id_rol: int) -> dict | None:
    return db.consultar_uno(_SEL_ROL + " WHERE r.id_rol = ?", (id_rol,))


def rol_por_codigo(codigo: str) -> dict | None:
    return db.consultar_uno(_SEL_ROL + " WHERE r.codigo = ?", (codigo,))


def crear_rol(codigo: str, descripcion: str | None) -> int:
    return db.insertar("INSERT INTO dbo.ROL (codigo, descripcion) OUTPUT INSERTED.id_rol VALUES (?, ?)", (codigo, descripcion))


def actualizar_rol(id_rol: int, descripcion: str | None) -> None:
    db.ejecutar("UPDATE dbo.ROL SET descripcion = ? WHERE id_rol = ?", (descripcion, id_rol))


def eliminar_rol(id_rol: int) -> None:
    with db.transaccion() as cur:
        cur.execute("DELETE FROM dbo.PERMISO WHERE id_rol = ?", (id_rol,))
        cur.execute("DELETE FROM dbo.ROL WHERE id_rol = ?", (id_rol,))


def permisos_de_rol(id_rol: int) -> list[dict]:
    return permisos_de_roles([id_rol])


def permisos_de_roles(ids_roles) -> list[dict]:
    ids = [int(i) for i in ids_roles]
    if not ids:
        return []
    marcas = ",".join("?" for _ in ids)  # solo signos de interrogacion: los valores van como parametros
    return db.consultar(
        f"""SELECT id_permiso, id_rol, tipo_recurso, recurso, nivel_acceso, origen
            FROM dbo.PERMISO WHERE id_rol IN ({marcas}) ORDER BY tipo_recurso, recurso""",
        ids,
    )


def permiso_por_id(id_permiso: int) -> dict | None:
    return db.consultar_uno(
        "SELECT id_permiso, id_rol, tipo_recurso, recurso, nivel_acceso, origen FROM dbo.PERMISO WHERE id_permiso = ?",
        (id_permiso,),
    )


def guardar_permiso(id_rol: int, tipo: str, recurso: str, nivel: str, origen: str) -> None:
    with db.transaccion() as cur:
        cur.execute(
            "UPDATE dbo.PERMISO SET nivel_acceso = ?, origen = ? WHERE id_rol = ? AND tipo_recurso = ? AND recurso = ?",
            (nivel, origen, id_rol, tipo, recurso),
        )
        if cur.rowcount == 0:
            cur.execute(
                "INSERT INTO dbo.PERMISO (id_rol, tipo_recurso, recurso, nivel_acceso, origen) VALUES (?, ?, ?, ?, ?)",
                (id_rol, tipo, recurso, nivel, origen),
            )


def quitar_permiso(id_permiso: int) -> None:
    db.ejecutar("DELETE FROM dbo.PERMISO WHERE id_permiso = ?", (id_permiso,))


def quitar_permisos_por_origen(id_rol: int, origen: str) -> int:
    return db.ejecutar("DELETE FROM dbo.PERMISO WHERE id_rol = ? AND origen = ?", (id_rol, origen))


# ----------------------------------------------------------------------------
# Tablas habilitadas (HU-005)
# ----------------------------------------------------------------------------
_SEL_TABLA = "SELECT id_tabla, esquema, nombre_tabla, objetivo, aclaraciones, filtro_registros, activa FROM dbo.TABLA_HABILITADA"


def listar_tablas(solo_activas: bool = False) -> list[dict]:
    where = " WHERE activa = 1" if solo_activas else ""
    return db.consultar(_SEL_TABLA + where + " ORDER BY esquema, nombre_tabla")


def tabla_por_id(id_tabla: int) -> dict | None:
    return db.consultar_uno(_SEL_TABLA + " WHERE id_tabla = ?", (id_tabla,))


def crear_tabla(esquema: str, nombre: str, objetivo: str, aclaraciones: str | None, filtro: str | None) -> int:
    return db.insertar(
        """INSERT INTO dbo.TABLA_HABILITADA (esquema, nombre_tabla, objetivo, aclaraciones, filtro_registros)
           OUTPUT INSERTED.id_tabla VALUES (?, ?, ?, ?, ?)""",
        (esquema, nombre, objetivo, aclaraciones, filtro),
    )


def actualizar_tabla(
    id_tabla: int, objetivo: str, aclaraciones: str | None, filtro: str | None, activa: bool
) -> None:
    db.ejecutar(
        """UPDATE dbo.TABLA_HABILITADA SET objetivo = ?, aclaraciones = ?, filtro_registros = ?, activa = ?
           WHERE id_tabla = ?""",
        (objetivo, aclaraciones, filtro, 1 if activa else 0, id_tabla),
    )


# ----------------------------------------------------------------------------
# Documentos y fragmentos
# ----------------------------------------------------------------------------
_SEL_DOC = """
SELECT d.id_documento, d.codigo, d.titulo, d.tipo, d.version, d.vigente, d.categoria,
       d.archivo, d.nombre_original, d.hash_archivo, d.paginas, d.indexado, d.fecha_alta, d.fecha_indexacion,
       d.error_indexacion, d.proceso_replicado, d.capacidad_validada,
       (SELECT COUNT(*) FROM dbo.FRAGMENTO f WHERE f.id_documento = d.id_documento) AS fragmentos
FROM dbo.DOCUMENTO d
"""


def listar_categorias() -> list[str]:
    return [f["categoria"] for f in db.consultar("SELECT DISTINCT categoria FROM dbo.DOCUMENTO ORDER BY categoria")]


def listar_documentos() -> list[dict]:
    return db.consultar(_SEL_DOC + " ORDER BY d.codigo, d.fecha_alta DESC")


def documento_por_id(id_documento: int) -> dict | None:
    return db.consultar_uno(_SEL_DOC + " WHERE d.id_documento = ?", (id_documento,))


def documentos_por_codigo(codigo: str) -> list[dict]:
    return db.consultar(_SEL_DOC + " WHERE d.codigo = ?", (codigo,))


def documento_vigente_por_codigo(codigo: str) -> dict | None:
    return db.consultar_uno(_SEL_DOC + " WHERE d.codigo = ? AND d.vigente = 1", (codigo,))


def crear_documento(d: dict) -> int:
    return db.insertar(
        """INSERT INTO dbo.DOCUMENTO (codigo, titulo, tipo, version, vigente, categoria,
                                      archivo, nombre_original, hash_archivo, paginas, id_usuario_alta,
                                      proceso_replicado, capacidad_validada)
           OUTPUT INSERTED.id_documento VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            d["codigo"], d["titulo"], d["tipo"], d["version"], d["categoria"],
            d["archivo"], d.get("nombre_original"), d["hash_archivo"], d.get("paginas"), d.get("id_usuario_alta"),
            d.get("proceso_replicado"), d.get("capacidad_validada"),
        ),
    )


def actualizar_documento(id_documento: int, d: dict) -> None:
    db.ejecutar(
        """UPDATE dbo.DOCUMENTO SET titulo = ?, tipo = ?, categoria = ?,
                  proceso_replicado = ?, capacidad_validada = ? WHERE id_documento = ?""",
        (
            d["titulo"], d["tipo"], d["categoria"],
            d.get("proceso_replicado"), d.get("capacidad_validada"), id_documento,
        ),
    )


def marcar_indexado(id_documento: int, indexado: bool, error: str | None = None) -> None:
    db.ejecutar(
        """UPDATE dbo.DOCUMENTO SET indexado = ?, error_indexacion = ?,
                  fecha_indexacion = CASE WHEN ? = 1 THEN SYSUTCDATETIME() ELSE fecha_indexacion END
           WHERE id_documento = ?""",
        (1 if indexado else 0, (error or None) and error[:500], 1 if indexado else 0, id_documento),
    )


def marcar_no_vigente(id_documento: int) -> None:
    db.ejecutar("UPDATE dbo.DOCUMENTO SET vigente = 0, indexado = 0 WHERE id_documento = ?", (id_documento,))


def ids_vectores_de_documento(id_documento: int) -> list[int]:
    filas = db.consultar(
        "SELECT id_fragmento FROM dbo.FRAGMENTO WHERE id_documento = ? AND id_vector IS NOT NULL", (id_documento,)
    )
    return [int(f["id_fragmento"]) for f in filas]


def borrar_fragmentos(id_documento: int) -> None:
    db.ejecutar("DELETE FROM dbo.FRAGMENTO WHERE id_documento = ?", (id_documento,))


def insertar_fragmentos(id_documento: int, fragmentos: Sequence[dict]) -> list[int]:
    """Inserta los fragmentos y deja id_vector = id_fragmento. Devuelve los ids en el mismo orden."""
    ids: list[int] = []
    with db.transaccion() as cur:
        for f in fragmentos:
            cur.execute(
                """INSERT INTO dbo.FRAGMENTO (id_documento, orden, pagina, seccion, texto)
                   OUTPUT INSERTED.id_fragmento VALUES (?, ?, ?, ?, ?)""",
                (id_documento, f["orden"], f.get("pagina"), f.get("seccion"), f["texto"]),
            )
            ids.append(int(cur.fetchone()[0]))
        cur.execute(
            "UPDATE dbo.FRAGMENTO SET id_vector = CAST(id_fragmento AS varchar(40)) WHERE id_documento = ?",
            (id_documento,),
        )
    return ids


def fragmentos_por_ids(ids: Iterable[int]) -> list[dict]:
    ids = [int(i) for i in ids]
    if not ids:
        return []
    marcas = ",".join("?" for _ in ids)  # solo signos de interrogacion: los valores van como parametros
    return db.consultar(
        f"""SELECT f.id_fragmento, f.orden, f.pagina, f.seccion, f.texto,
                   d.id_documento, d.codigo, d.titulo, d.version, d.vigente
            FROM dbo.FRAGMENTO f JOIN dbo.DOCUMENTO d ON d.id_documento = f.id_documento
            WHERE f.id_fragmento IN ({marcas})""",
        ids,
    )


def fragmentos_de_documento(id_documento: int) -> list[dict]:
    return db.consultar(
        "SELECT id_fragmento, orden, pagina, seccion FROM dbo.FRAGMENTO WHERE id_documento = ? ORDER BY orden",
        (id_documento,),
    )


def fragmentos_para_lexico() -> list[dict]:
    """Todos los fragmentos de documentos vigentes e indexados, para armar el indice de palabras."""
    return db.consultar(
        """SELECT f.id_fragmento, f.texto, f.seccion, f.id_documento, d.categoria, d.codigo, d.titulo
           FROM dbo.FRAGMENTO f JOIN dbo.DOCUMENTO d ON d.id_documento = f.id_documento
           WHERE d.vigente = 1 AND d.indexado = 1"""
    )


def fragmentos_vecinos(pares: list[tuple[int, int]]) -> list[dict]:
    """Fragmentos anterior y siguiente de cada (id_documento, orden), para dar contexto a un fragmento recuperado."""
    if not pares:
        return []
    condicion = " OR ".join("(f.id_documento = ? AND f.orden IN (?, ?))" for _ in pares)  # solo marcas de parametro
    params: list = []
    for doc, orden in pares:
        params += [doc, orden - 1, orden + 1]
    return db.consultar(
        f"SELECT f.id_fragmento, f.id_documento, f.orden, f.texto FROM dbo.FRAGMENTO f WHERE {condicion}", params
    )


def documentos_para_resumen() -> list[dict]:
    return db.consultar(
        """SELECT id_documento, codigo, titulo, version, categoria, resumen
           FROM dbo.DOCUMENTO WHERE vigente = 1 AND indexado = 1 ORDER BY codigo"""
    )


def guardar_resumen(id_documento: int, resumen: str | None) -> None:
    db.ejecutar("UPDATE dbo.DOCUMENTO SET resumen = ? WHERE id_documento = ?", (resumen, id_documento))


def texto_de_documento(id_documento: int) -> list[dict]:
    return db.consultar(
        "SELECT orden, pagina, seccion, texto FROM dbo.FRAGMENTO WHERE id_documento = ? ORDER BY orden", (id_documento,)
    )


def hay_version_posterior(codigo: str, version: str) -> str | None:
    """Devuelve la version vigente si es distinta de la citada (HU-003)."""
    v = db.consultar_uno("SELECT version FROM dbo.DOCUMENTO WHERE codigo = ? AND vigente = 1", (codigo,))
    if v and v["version"] != version:
        return v["version"]
    return None


# ----------------------------------------------------------------------------
# Conversaciones, mensajes y consultas
# ----------------------------------------------------------------------------
def crear_conversacion(id_usuario: int, titulo: str) -> int:
    return db.insertar(
        "INSERT INTO dbo.CONVERSACION (id_usuario, titulo) OUTPUT INSERTED.id_conversacion VALUES (?, ?)",
        (id_usuario, titulo[:150]),
    )


def conversacion_de_usuario(id_conversacion: int, id_usuario: int) -> dict | None:
    return db.consultar_uno(
        "SELECT id_conversacion, id_usuario, titulo, fecha_inicio FROM dbo.CONVERSACION "
        "WHERE id_conversacion = ? AND id_usuario = ?",
        (id_conversacion, id_usuario),
    )


def listar_conversaciones(id_usuario: int, limite: int = 50) -> list[dict]:
    return db.consultar(
        "SELECT TOP (?) id_conversacion, titulo, fecha_inicio FROM dbo.CONVERSACION "
        "WHERE id_usuario = ? ORDER BY id_conversacion DESC",
        (limite, id_usuario),
    )


def insertar_mensaje(id_conversacion: int, emisor: str, texto: str, detalle_json: str | None = None) -> int:
    return db.insertar(
        "INSERT INTO dbo.MENSAJE (id_conversacion, emisor, texto, detalle_json) "
        "OUTPUT INSERTED.id_mensaje VALUES (?, ?, ?, ?)",
        (id_conversacion, emisor, texto, detalle_json),
    )


def mensajes_de_conversacion(id_conversacion: int) -> list[dict]:
    return db.consultar(
        "SELECT id_mensaje, emisor, texto, fecha, detalle_json FROM dbo.MENSAJE "
        "WHERE id_conversacion = ? ORDER BY id_mensaje",
        (id_conversacion,),
    )


def ultimos_mensajes(id_conversacion: int, n: int) -> list[dict]:
    filas = db.consultar(
        "SELECT TOP (?) id_mensaje, emisor, texto FROM dbo.MENSAJE WHERE id_conversacion = ? ORDER BY id_mensaje DESC",
        (n, id_conversacion),
    )
    return list(reversed(filas))


def mensaje_de_usuario(id_mensaje: int, id_usuario: int) -> dict | None:
    """Mensaje del asistente de una conversacion del usuario (para descargar su resultado)."""
    return db.consultar_uno(
        """SELECT m.id_mensaje, m.id_conversacion, m.texto, m.fecha, m.detalle_json
           FROM dbo.MENSAJE m JOIN dbo.CONVERSACION c ON c.id_conversacion = m.id_conversacion
           WHERE m.id_mensaje = ? AND c.id_usuario = ? AND m.emisor = 'asistente'""",
        (id_mensaje, id_usuario),
    )


def pregunta_previa(id_conversacion: int, id_mensaje: int) -> str | None:
    fila = db.consultar_uno(
        "SELECT TOP 1 texto FROM dbo.MENSAJE WHERE id_conversacion = ? AND id_mensaje < ? AND emisor = 'usuario' ORDER BY id_mensaje DESC",
        (id_conversacion, id_mensaje),
    )
    return fila["texto"] if fila else None


def insertar_consulta(c: dict) -> int:
    return db.insertar(
        """INSERT INTO dbo.CONSULTA (id_mensaje, tipo, herramienta, sql_generado, sql_ejecutado, estado, duracion_ms, filas)
           OUTPUT INSERTED.id_consulta VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            c["id_mensaje"], c["tipo"], c.get("herramienta"), c.get("sql_generado"), c.get("sql_ejecutado"),
            c["estado"], c.get("duracion_ms"), c.get("filas"),
        ),
    )


def vincular_tablas(id_consulta: int, ids_tabla: Iterable[int]) -> None:
    with db.transaccion() as cur:
        for t in set(ids_tabla):
            cur.execute("INSERT INTO dbo.CONSULTA_TABLA (id_consulta, id_tabla) VALUES (?, ?)", (id_consulta, t))


# ----------------------------------------------------------------------------
# Auditoria (solo insercion y lectura)
# ----------------------------------------------------------------------------
def insertar_auditoria(
    tipo_evento: str,
    resultado: str,
    *,
    id_usuario: int | None = None,
    usuario_ref: str | None = None,
    rol: str | None = None,
    id_consulta: int | None = None,
    motivo: str | None = None,
    detalle: str | None = None,
    ip: str | None = None,
) -> None:
    db.ejecutar(
        """INSERT INTO dbo.AUDITORIA (id_consulta, id_usuario, usuario_ref, rol, tipo_evento, resultado,
                                      motivo_bloqueo, detalle, ip)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            id_consulta, id_usuario, usuario_ref, rol, tipo_evento, resultado,
            (motivo or None) and motivo[:200], (detalle or None) and detalle[:500], ip,
        ),
    )


def listar_auditoria(
    tipo_evento: str | None = None,
    resultado: str | None = None,
    usuario: str | None = None,
    limite: int = 200,
) -> list[dict]:
    condiciones: list[str] = []
    params: list[Any] = [limite]
    if tipo_evento:
        condiciones.append("a.tipo_evento = ?")
        params.append(tipo_evento)
    if resultado:
        condiciones.append("a.resultado = ?")
        params.append(resultado)
    if usuario:
        condiciones.append("(a.usuario_ref LIKE ? OR u.email LIKE ? OR u.nombre LIKE ?)")
        params.extend([f"%{usuario}%"] * 3)
    where = (" WHERE " + " AND ".join(condiciones)) if condiciones else ""
    return db.consultar(
        f"""SELECT TOP (?) a.id_auditoria, a.fecha, a.tipo_evento, a.resultado, a.motivo_bloqueo, a.detalle, a.ip,
                   a.rol, COALESCE(u.email, a.usuario_ref) AS usuario,
                   c.tipo AS tipo_consulta, c.herramienta, c.sql_generado, c.duracion_ms
            FROM dbo.AUDITORIA a
            LEFT JOIN dbo.USUARIO u ON u.id_usuario = a.id_usuario
            LEFT JOIN dbo.CONSULTA c ON c.id_consulta = a.id_consulta
            {where}
            ORDER BY a.id_auditoria DESC""",
        params,
    )


def metricas(dias: int = 7) -> dict:
    """Indicadores del monitoreo propio: tiempo medio, tasa de error y volumen."""
    fila = db.consultar_uno(
        """SELECT COUNT(*) AS total,
                  AVG(CAST(duracion_ms AS float)) AS duracion_media_ms,
                  SUM(CASE WHEN estado = 'con_error' THEN 1 ELSE 0 END) AS con_error,
                  SUM(CASE WHEN estado = 'error_modelo' THEN 1 ELSE 0 END) AS error_modelo,
                  SUM(CASE WHEN estado = 'rechazada' THEN 1 ELSE 0 END) AS rechazadas
           FROM dbo.CONSULTA c JOIN dbo.MENSAJE m ON m.id_mensaje = c.id_mensaje
           WHERE m.fecha >= DATEADD(DAY, ?, SYSUTCDATETIME())""",
        (-dias,),
    )
    return fila or {}
