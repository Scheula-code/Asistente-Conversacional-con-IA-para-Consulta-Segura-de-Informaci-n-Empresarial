"""Lectura del esquema del datawarehouse (HU-005).

Lo unico que se declara es la tabla y su objetivo (TABLA_HABILITADA). Las columnas, los tipos y las
relaciones se obtienen leyendo la propia base con el usuario de solo lectura. Las aclaraciones cargadas
en la configuracion de la tabla se agregan al contexto del modelo.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field

from .. import db
from ..config import get_settings
from ..security.rbac import PermisoTabla, clave_tabla

log = logging.getLogger("asistente.esquema")


@dataclass(frozen=True)
class Columna:
    nombre: str
    tipo: str
    descripcion: str | None = None


@dataclass
class Tabla:
    id_tabla: int
    esquema: str
    nombre: str
    objetivo: str
    aclaraciones: str | None
    filtro_registros: str | None
    columnas: list[Columna] = field(default_factory=list)

    @property
    def clave(self) -> str:
        return clave_tabla(self.esquema, self.nombre)


@dataclass
class EsquemaDWH:
    tablas: dict[str, Tabla] = field(default_factory=dict)
    relaciones: list[tuple[str, str, str, str]] = field(default_factory=list)  # (tabla.col -> tabla.col)
    no_encontradas: list[str] = field(default_factory=list)


_cache: tuple[float, EsquemaDWH] | None = None
_lock = threading.Lock()


def invalidar_cache() -> None:
    global _cache
    with _lock:
        _cache = None


def _tipo_legible(tipo: str, largo) -> str:
    if largo and largo > 0 and tipo in ("varchar", "nvarchar", "char", "nchar"):
        return f"{tipo}({largo})"
    if largo == -1:
        return f"{tipo}(max)"
    return tipo


def _leer(tablas_cfg: list[dict]) -> EsquemaDWH:
    esq = EsquemaDWH()
    conn = db.conectar_dwh()
    try:
        cur = conn.cursor()
        for t in tablas_cfg:
            cur.execute(
                """SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
                   FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
                   ORDER BY ORDINAL_POSITION""",
                (t["esquema"], t["nombre_tabla"]),
            )
            cols = cur.fetchall()
            if not cols:
                esq.no_encontradas.append(f"{t['esquema']}.{t['nombre_tabla']}")
                continue
            descripciones: dict[str, str] = {}
            try:  # descripciones (MS_Description) si el usuario tiene VIEW DEFINITION; opcional
                cur.execute(
                    """SELECT c.name, CAST(ep.value AS nvarchar(400))
                       FROM sys.columns c
                       JOIN sys.objects o ON o.object_id = c.object_id
                       JOIN sys.schemas s ON s.schema_id = o.schema_id
                       JOIN sys.extended_properties ep ON ep.major_id = c.object_id AND ep.minor_id = c.column_id
                            AND ep.class = 1 AND ep.name = 'MS_Description'
                       WHERE s.name = ? AND o.name = ?""",
                    (t["esquema"], t["nombre_tabla"]),
                )
                descripciones = {r[0].lower(): r[1] for r in cur.fetchall() if r[1]}
            except Exception as e:  # pragma: no cover
                log.info("Sin descripciones de columnas para %s.%s: %s", t["esquema"], t["nombre_tabla"], e)
            tabla = Tabla(
                t["id_tabla"], t["esquema"], t["nombre_tabla"], t["objetivo"], t["aclaraciones"],
                t["filtro_registros"],
                [Columna(c[0], _tipo_legible(c[1], c[2]), descripciones.get(c[0].lower())) for c in cols],
            )
            esq.tablas[tabla.clave] = tabla

        # Relaciones (claves foraneas) entre las tablas habilitadas
        cur.execute(
            """SELECT OBJECT_SCHEMA_NAME(fk.parent_object_id), OBJECT_NAME(fk.parent_object_id), pc.name,
                      OBJECT_SCHEMA_NAME(fk.referenced_object_id), OBJECT_NAME(fk.referenced_object_id), rc.name
               FROM sys.foreign_key_columns fkc
               JOIN sys.foreign_keys fk ON fk.object_id = fkc.constraint_object_id
               JOIN sys.columns pc ON pc.object_id = fkc.parent_object_id AND pc.column_id = fkc.parent_column_id
               JOIN sys.columns rc ON rc.object_id = fkc.referenced_object_id AND rc.column_id = fkc.referenced_column_id"""
        )
        for r in cur.fetchall():
            origen, destino = clave_tabla(r[0], r[1]), clave_tabla(r[3], r[4])
            if origen in esq.tablas and destino in esq.tablas:
                esq.relaciones.append((f"{r[0]}.{r[1]}.{r[2]}", f"{r[3]}.{r[4]}.{r[5]}", origen, destino))
    finally:
        conn.close()
    return esq


def leer_esquema(tablas_cfg: list[dict], forzar: bool = False) -> EsquemaDWH:
    """Esquema de las tablas habilitadas y activas, con cache de unos minutos."""
    global _cache
    ttl = get_settings().schema_cache_s
    with _lock:
        if not forzar and _cache and (time.time() - _cache[0]) < ttl:
            return _cache[1]
    esq = _leer(tablas_cfg)
    with _lock:
        _cache = (time.time(), esq)
    return esq


def filtrar_para_rol(esq: EsquemaDWH, permisos: dict[str, PermisoTabla]) -> EsquemaDWH:
    """Copia del esquema con solo las tablas y columnas que el rol puede alcanzar."""
    salida = EsquemaDWH()
    for clave, perm in permisos.items():
        t = esq.tablas.get(clave)
        if not t:
            continue
        salida.tablas[clave] = Tabla(
            t.id_tabla, t.esquema, t.nombre, t.objetivo, t.aclaraciones, t.filtro_registros,
            [c for c in t.columnas if perm.columna_ok(c.nombre)],
        )
    for rel in esq.relaciones:
        # una relacion solo se informa si el rol ve ambas columnas
        o_tabla, o_col = rel[0].rsplit(".", 1)
        d_tabla, d_col = rel[1].rsplit(".", 1)
        po, pd_ = permisos.get(o_tabla.lower()), permisos.get(d_tabla.lower())
        if po and pd_ and po.columna_ok(o_col) and pd_.columna_ok(d_col):
            salida.relaciones.append(rel)
    return salida


def a_schema_sqlglot(esq: EsquemaDWH) -> dict:
    """Formato {esquema: {tabla: {columna: tipo}}} que usa sqlglot, todo en minusculas."""
    out: dict = {}
    for t in esq.tablas.values():
        out.setdefault(t.esquema.lower(), {})[t.nombre.lower()] = {c.nombre.lower(): c.tipo.split("(")[0] for c in t.columnas}
    return out


def a_texto_prompt(esq: EsquemaDWH) -> str:
    """Descripcion del esquema para el modelo: tabla, objetivo, aclaraciones, columnas y relaciones."""
    bloques = []
    for t in esq.tablas.values():
        lineas = [f"TABLA {t.esquema}.{t.nombre}", f"  Objetivo: {t.objetivo}"]
        if t.aclaraciones:
            lineas.append(f"  Aclaraciones: {t.aclaraciones}")
        lineas.append("  Columnas:")
        for c in t.columnas:
            extra = f" -- {c.descripcion}" if c.descripcion else ""
            lineas.append(f"    - {c.nombre} ({c.tipo}){extra}")
        bloques.append("\n".join(lineas))
    if esq.relaciones:
        bloques.append("RELACIONES:\n" + "\n".join(f"  {a} -> {b}" for a, b, *_ in esq.relaciones))
    return "\n\n".join(bloques)
