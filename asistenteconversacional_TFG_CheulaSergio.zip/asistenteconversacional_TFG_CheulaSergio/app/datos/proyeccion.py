"""Proyeccion y lectura de la serie (HU-006 y HU-013). Todo lo numerico lo calcula el codigo, no el modelo.

Regla declarada en el objetivo especifico 2: tendencia lineal sobre los ultimos doce meses CERRADOS
(el mes en curso queda afuera por estar incompleto) y horizonte de un trimestre.
"""
from __future__ import annotations

import re
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Sequence

import numpy as np

Periodo = tuple[int, int]  # (anio, mes)


def parsear_periodo(valor: Any) -> Periodo | None:
    if isinstance(valor, (datetime, date)):
        return (valor.year, valor.month)
    if isinstance(valor, str):
        s = valor.strip()
        m = re.match(r"^(\d{4})[-/](\d{1,2})(?:[-/]\d{1,2})?", s)
        if m and 1 <= int(m.group(2)) <= 12:
            return (int(m.group(1)), int(m.group(2)))
        m = re.match(r"^(\d{4})(\d{2})$", s)
        if m and 1 <= int(m.group(2)) <= 12:
            return (int(m.group(1)), int(m.group(2)))
    if isinstance(valor, int) and 190001 <= valor <= 299912 and 1 <= valor % 100 <= 12:
        return (valor // 100, valor % 100)
    return None


def _ordinal(p: Periodo) -> int:
    return p[0] * 12 + (p[1] - 1)


def _desde_ordinal(o: int) -> Periodo:
    return (o // 12, o % 12 + 1)


def etiqueta(p: Periodo) -> str:
    return f"{p[0]}-{p[1]:02d}"


def a_numero(v: Any) -> float | None:
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float, Decimal)):
        return float(v)
    return None


def serie_mensual(
    filas: Sequence[Sequence[Any]], idx_periodo: int, idx_medida: int
) -> list[tuple[Periodo, float]]:
    """Serie por mes, sumando si el mes aparece repetido, ordenada cronologicamente."""
    acumulado: dict[Periodo, float] = {}
    for f in filas:
        p, v = parsear_periodo(f[idx_periodo]), a_numero(f[idx_medida])
        if p is None or v is None:
            continue
        acumulado[p] = acumulado.get(p, 0.0) + v
    return sorted(acumulado.items())


def proyectar(
    serie: list[tuple[Periodo, float]], hoy: date, meses_base: int = 12, horizonte: int = 3
) -> dict:
    actual = (hoy.year, hoy.month)
    cerrados = [(p, v) for p, v in serie if p < actual]
    if len(cerrados) < meses_base:
        return {
            "proyectable": False,
            "motivo": f"La regla requiere {meses_base} meses cerrados y la serie tiene {len(cerrados)}.",
        }
    base = cerrados[-meses_base:]
    ords = [_ordinal(p) for p, _ in base]
    if ords != list(range(ords[0], ords[0] + meses_base)):
        return {"proyectable": False, "motivo": "La serie tiene meses faltantes dentro de la base de cálculo."}
    y = np.array([v for _, v in base], dtype=float)
    x = np.arange(meses_base, dtype=float)
    pendiente, ordenada = np.polyfit(x, y, 1)
    futuros = []
    for h in range(1, horizonte + 1):
        valor = float(pendiente * (meses_base - 1 + h) + ordenada)
        futuros.append({"periodo": etiqueta(_desde_ordinal(ords[-1] + h)), "valor": round(valor, 2)})
    return {
        "proyectable": True,
        "regla": f"tendencia lineal sobre los últimos {meses_base} meses cerrados, horizonte de {horizonte} meses",
        "periodo_base": f"{etiqueta(base[0][0])} a {etiqueta(base[-1][0])}",
        "proyeccion": futuros,
        "total_horizonte": round(sum(f["valor"] for f in futuros), 2),
        "pendiente_mensual": round(float(pendiente), 2),
    }


def resumen_variacion(serie: list[tuple[Periodo, float]], hoy: date) -> dict | None:
    """Hechos calculados sobre la serie devuelta, para que la lectura del modelo no los invente."""
    if len(serie) < 2:
        return None
    primero, ultimo = serie[0], serie[-1]
    abierto = ultimo[0] >= (hoy.year, hoy.month)
    # si el ultimo mes esta en curso, la variacion se mide contra el ultimo cerrado para no comparar contra un mes parcial
    descartar_ultimo = abierto and len(serie) >= 3
    ref = serie[-2] if descartar_ultimo else ultimo
    maximo = max(serie, key=lambda t: t[1])
    minimo = min(serie, key=lambda t: t[1])
    var_abs = ref[1] - primero[1]
    var_pct = (var_abs / primero[1] * 100.0) if primero[1] else None
    return {
        "primer_periodo": {"periodo": etiqueta(primero[0]), "valor": round(primero[1], 2)},
        "ultimo_periodo_considerado": {"periodo": etiqueta(ref[0]), "valor": round(ref[1], 2)},
        "variacion_absoluta": round(var_abs, 2),
        "variacion_porcentual": None if var_pct is None else round(var_pct, 1),
        "maximo": {"periodo": etiqueta(maximo[0]), "valor": round(maximo[1], 2)},
        "minimo": {"periodo": etiqueta(minimo[0]), "valor": round(minimo[1], 2)},
        "ultimo_periodo_abierto": abierto,
        "nota": "El último período de la serie es el mes en curso (incompleto) y no se usó para comparar."
        if descartar_ultimo
        else None,
    }
