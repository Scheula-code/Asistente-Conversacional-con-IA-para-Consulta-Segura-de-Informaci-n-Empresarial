"""Validacion de la consulta generada, ANTES de enviarla al motor (HU-004, 009, 010, 011).

La autorizacion no la decide el modelo de lenguaje: lo que se ejecuta es exactamente lo que este
modulo valido. Se analiza la sentencia como arbol sintactico (no con expresiones regulares) y se exige:

  1. una sola sentencia, y que sea una consulta SELECT (con CTE o UNION permitidos);
  2. ninguna operacion de escritura, DDL, EXEC, SELECT INTO ni funciones de acceso externo;
  3. solo tablas habilitadas y que el rol tenga concedidas, sin nombres de varias partes (otros servidores/bases);
  4. solo columnas que el rol pueda ver, incluso dentro de subconsultas y de SELECT *, que se expande;
  5. para las tablas con alcance por area, que cada lectura quede acotada a los registros del area del usuario.
"""
from __future__ import annotations

from dataclasses import dataclass

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError
from sqlglot.optimizer.qualify import qualify
from sqlglot.optimizer.scope import traverse_scope

from ..security.rbac import PermisoTabla

MSG_FUERA_DE_ALCANCE = (
    "La consulta excede los permisos de su rol: requiere información que no tiene habilitada. "
    "Si la necesita, solicite el acceso al responsable de su área o a Sistemas."
)


class ConsultaBloqueada(Exception):
    """Excede los permisos del rol o intenta algo no permitido. No se reintenta ni se devuelve dato alguno."""

    def __init__(self, motivo_usuario: str, motivo_auditoria: str):
        super().__init__(motivo_auditoria)
        self.motivo_usuario = motivo_usuario
        self.motivo_auditoria = motivo_auditoria


class ConsultaInvalida(Exception):
    """Sintaxis o columnas inexistentes: el modelo puede intentar corregirla."""


_NOMBRES_PROHIBIDOS = (
    "Insert", "Update", "Delete", "Drop", "Create", "Alter", "Merge", "Command", "Execute", "TruncateTable",
    "Grant", "Revoke", "Into", "Use", "Set", "Declare", "Transaction", "Commit", "Rollback", "Kill", "Pragma",
)
_PROHIBIDOS = tuple(getattr(exp, n) for n in _NOMBRES_PROHIBIDOS if hasattr(exp, n))

_FUNCIONES_PROHIBIDAS = {
    "openrowset", "openquery", "opendatasource", "openxml", "xp_cmdshell", "sp_executesql", "sp_oacreate",
    "sp_oamethod", "fn_get_audit_file", "fn_trace_gettable", "bulk",
}
_PREFIJOS_PROHIBIDOS = ("xp_", "sp_", "fn_", "dm_", "sys.")


@dataclass(frozen=True)
class ConsultaValidada:
    sql: str                       # sentencia lista para ejecutar (calificada y con los filtros por rol)
    tablas: frozenset[str]         # claves 'esquema.tabla' que toca


def _bloq(auditoria: str) -> ConsultaBloqueada:
    return ConsultaBloqueada(MSG_FUERA_DE_ALCANCE, auditoria)


def _parsear(sql: str) -> exp.Expression:
    sql = (sql or "").strip().rstrip(";").strip()
    if not sql:
        raise ConsultaInvalida("La consulta está vacía.")
    try:
        arboles = [a for a in sqlglot.parse(sql, read="tsql") if a is not None]
    except SqlglotError as e:
        raise ConsultaInvalida(f"Error de sintaxis: {str(e)[:200]}") from e
    if len(arboles) != 1:
        raise ConsultaBloqueada(
            "Solo se admite una consulta por vez.", "se intentó ejecutar más de una sentencia"
        )
    return arboles[0]


def _control_estructural(raiz: exp.Expression) -> None:
    if not isinstance(raiz, exp.Query):
        raise ConsultaBloqueada(
            "Solo se admiten consultas de lectura (SELECT).",
            f"sentencia no permitida: {type(raiz).__name__}",
        )
    for nodo in raiz.walk():
        if isinstance(nodo, _PROHIBIDOS):
            raise ConsultaBloqueada(
                "Solo se admiten consultas de lectura (SELECT).",
                f"operación no permitida dentro de la consulta: {type(nodo).__name__}",
            )
        if isinstance(nodo, exp.Anonymous):
            nombre = (nodo.name or "").lower()
            if nombre in _FUNCIONES_PROHIBIDAS or nombre.startswith(_PREFIJOS_PROHIBIDOS):
                raise ConsultaBloqueada(
                    "La consulta usa una función no permitida.", f"función no permitida: {nombre}"
                )


def _tablas_referenciadas(raiz: exp.Expression) -> list[exp.Table]:
    ctes = {c.alias_or_name.lower() for c in raiz.find_all(exp.CTE)}
    tablas = []
    for t in raiz.find_all(exp.Table):
        if not isinstance(t.this, exp.Identifier):  # funciones de tabla, nombres de cuatro partes, etc.
            raise _bloq("referencia a un objeto no permitido (función de tabla o nombre de varias partes)")
        if t.catalog:
            raise _bloq(f"referencia a otra base o servidor: {t.catalog}")
        if not t.db and t.name.lower() in ctes:
            continue  # referencia a una CTE de la propia consulta
        tablas.append(t)
    return tablas


def _control_tablas(
    tablas: list[exp.Table], permisos: dict[str, PermisoTabla]
) -> frozenset[str]:
    usadas: set[str] = set()
    for t in tablas:
        esquema, nombre = (t.db or "").lower(), t.name.lower()
        if not esquema:
            candidatas = [k for k in permisos if k.split(".", 1)[1] == nombre]
            if len(candidatas) != 1:
                raise ConsultaInvalida(f"La tabla '{t.name}' debe indicarse con su esquema (esquema.tabla).")
            esquema = candidatas[0].split(".", 1)[0]
            t.set("db", exp.to_identifier(esquema))
        clave = f"{esquema}.{nombre}"
        if clave not in permisos:
            raise _bloq(f"tabla fuera del alcance del rol: {clave}")
        usadas.add(clave)
    return frozenset(usadas)


def _schema_sqlglot(permisos: dict[str, PermisoTabla], columnas_por_tabla: dict[str, dict[str, str]], solo_visibles: bool) -> dict:
    schema: dict = {}
    for clave, perm in permisos.items():
        esq, tab = clave.split(".", 1)
        cols = columnas_por_tabla.get(clave, {})
        if solo_visibles:
            cols = {c: tipo for c, tipo in cols.items() if perm.columna_ok(c)}
        schema.setdefault(esq, {})[tab] = cols
    return schema


def _calificar(raiz: exp.Expression, schema: dict) -> exp.Expression:
    try:
        return qualify(
            raiz.copy(), schema=schema, dialect="tsql", validate_qualify_columns=True, expand_stars=True
        )
    except SqlglotError as e:
        msg = str(e)[:300]
        if "could not be resolved" in msg or "Ambiguous" in msg:
            msg += (" (la columna no existe en esas tablas o es ambigua: calificá cada columna con el alias de su tabla, "
                    "por ejemplo c.nombre, y usá solo las columnas del esquema)")
        raise ConsultaInvalida(msg) from e


def _control_columnas(
    calificada: exp.Expression, permisos: dict[str, PermisoTabla]
) -> None:
    """Toda columna base debe resolverse a una tabla habilitada y ser visible para el rol."""
    resueltas: set[int] = set()
    for scope in traverse_scope(calificada):
        for col in list(scope.columns) + list(scope.external_columns):
            origen = scope.sources.get(col.table)
            if isinstance(origen, exp.Table):
                clave = f"{origen.db}.{origen.name}".lower()
                perm = permisos.get(clave)
                if perm is None or not perm.columna_ok(col.name):
                    raise _bloq(f"columna fuera del alcance del rol: {clave}.{col.name}".lower())
                resueltas.add(id(col))
            elif origen is not None:  # columna de una CTE o subconsulta: la base se controla en su propio scope
                resueltas.add(id(col))
    for col in calificada.find_all(exp.Column):
        if id(col) in resueltas or isinstance(col.this, exp.Star) or _es_alias_de_salida(col):
            continue
        raise ConsultaInvalida(
            f"No se pudo determinar a qué tabla pertenece la columna '{col.name}'. "
            "Calificá cada columna con el alias de su tabla (alias.columna) y usá solo columnas del esquema."
        )


def _es_alias_de_salida(col: exp.Column) -> bool:
    """T-SQL admite alias del SELECT (y posiciones) SOLO en el ORDER BY de la consulta que los define.
    No es una columna base: las columnas base de esa expresion ya se controlan en la propia proyeccion.
    Fuera del ORDER BY (WHERE, HAVING, GROUP BY) un nombre sin tabla es una columna real, asi que no se exime:
    de lo contrario un alias podria usarse para filtrar por una columna denegada."""
    if col.table:
        return False
    orden = col.find_ancestor(exp.Order)
    if orden is None:
        return False
    consulta = orden.parent
    return isinstance(consulta, exp.Query) and col.name.lower() in {n.lower() for n in consulta.named_selects}


def _acotar_por_area(
    calificada: exp.Expression, permisos: dict[str, PermisoTabla], filtros: dict[str, str], area: str | None
) -> None:
    """Reemplaza cada lectura de una tabla 'lectura_area' por una subconsulta filtrada por el area del usuario."""
    for t in list(calificada.find_all(exp.Table)):
        clave = f"{t.db}.{t.name}".lower()
        perm = permisos.get(clave)
        if not perm or not perm.por_area:
            continue
        col_area = filtros.get(clave)
        if not col_area:
            raise _bloq(f"la tabla {clave} no tiene definida la columna de área para acotar registros")
        if not (area or "").strip():
            raise ConsultaBloqueada(
                "Su usuario no tiene un área asignada, por lo que no puede consultar datos acotados por área. "
                "Solicite la asignación al administrador.",
                f"usuario sin área para tabla acotada por área: {clave}",
            )
        interna = (
            exp.select("*")
            .from_(exp.Table(this=exp.to_identifier(t.name), db=exp.to_identifier(t.db)))
            .where(exp.EQ(this=exp.column(col_area), expression=exp.Literal.string(area.strip())))
        )
        alias = t.alias or t.name
        t.replace(exp.Subquery(this=interna, alias=exp.TableAlias(this=exp.to_identifier(alias))))


def validar(
    sql_generado: str,
    permisos: dict[str, PermisoTabla],
    columnas_por_tabla: dict[str, dict[str, str]],
    filtros_area: dict[str, str] | None = None,
    area_usuario: str | None = None,
) -> ConsultaValidada:
    """columnas_por_tabla: {'esquema.tabla': {'columna': 'tipo'}} con TODAS las columnas reales de cada tabla."""
    raiz = _parsear(sql_generado)
    _control_estructural(raiz)
    tablas = _control_tablas(_tablas_referenciadas(raiz), permisos)

    # 1.o con las columnas visibles para el rol (asi SELECT * se expande solo a lo permitido);
    # si falla, se reintenta con el esquema completo para distinguir "sin permiso" de "columna inexistente".
    try:
        calificada = _calificar(raiz, _schema_sqlglot(permisos, columnas_por_tabla, solo_visibles=True))
    except ConsultaInvalida as error_visible:
        try:
            _calificar(raiz, _schema_sqlglot(permisos, columnas_por_tabla, solo_visibles=False))
        except ConsultaInvalida:
            raise error_visible  # tampoco existe con el esquema completo: es un error de la consulta
        raise _bloq("la consulta referencia una columna fuera del alcance del rol") from error_visible

    _control_columnas(calificada, permisos)
    _acotar_por_area(calificada, permisos, filtros_area or {}, area_usuario)
    return ConsultaValidada(sql=calificada.sql(dialect="tsql"), tablas=tablas)
