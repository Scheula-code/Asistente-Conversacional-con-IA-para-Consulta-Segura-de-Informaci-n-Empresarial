"""Flujo completo de una pregunta de negocio sobre el datawarehouse.

  permisos del rol -> esquema leido de la base (solo lo visible) -> SQL generado por el modelo
  -> validacion (SELECT, tablas, columnas, registros) -> ejecucion de solo lectura
  -> resumen y proyeccion calculados por codigo.

Un bloqueo corta el flujo: no se reintenta y no se devuelve ningun dato parcial (HU-010).
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import date
from typing import Any

from .. import repo
from ..config import get_settings
from ..security import rbac
from ..security.auth import Contexto
from . import ejecutor, esquema, generador, proyeccion, validador

log = logging.getLogger("asistente.datos")

MSG_SIN_TABLAS = (
    "Su rol no tiene tablas del datawarehouse habilitadas, por lo que no puede consultar datos de negocio. "
    "Si lo necesita, solicite el acceso al responsable de su área o a Sistemas."
)
MSG_ERROR_GENERICO = (
    "No pude resolver esa consulta. Reformule la pregunta con más detalle (por ejemplo, el período o el producto) "
    "o consulte a Sistemas si el problema persiste."
)
MSG_DWH_NO_DISPONIBLE = "No se pudo acceder al datawarehouse en este momento. Intente nuevamente más tarde."


@dataclass
class ResultadoDatos:
    estado: str                          # ok | bloqueado | sin_respuesta | error
    mensaje: str | None = None           # texto para el usuario cuando no es ok
    motivo_auditoria: str | None = None
    columnas: list[str] = field(default_factory=list)
    filas: list[list[Any]] = field(default_factory=list)
    truncado: bool = False
    sql_generado: str | None = None
    sql_ejecutado: str | None = None
    ids_tablas: list[int] = field(default_factory=list)
    resumen: dict | None = None
    proyeccion: dict | None = None
    grafico: str = "auto"                # auto | torta | barras | linea | ninguno (lo dibuja la interfaz)


def _indice(columnas: list[str], nombre: str | None) -> int | None:
    if not nombre:
        return None
    for i, c in enumerate(columnas):
        if c.lower() == nombre.lower():
            return i
    return None


def _detectar_columnas(res: ejecutor.Resultado, g_periodo: str | None, g_medida: str | None) -> tuple[int | None, int | None]:
    ip, im = _indice(res.columnas, g_periodo), _indice(res.columnas, g_medida)
    if ip is None:
        for i in range(len(res.columnas)):
            muestra = [f[i] for f in res.filas[:5] if f[i] is not None]
            if muestra and all(proyeccion.parsear_periodo(v) for v in muestra):
                ip = i
                break
    if im is None:
        for i in range(len(res.columnas)):
            if i == ip:
                continue
            muestra = [f[i] for f in res.filas[:5] if f[i] is not None]
            if muestra and all(proyeccion.a_numero(v) is not None for v in muestra):
                im = i
                break
    return ip, im


def consultar_datos(
    ctx: Contexto, pregunta: str, pide_proyeccion: bool = False, hoy: date | None = None, grafico: str = "auto",
    mensaje_usuario: str | None = None,
) -> ResultadoDatos:
    s = get_settings()
    hoy = hoy or date.today()

    cfg = repo.listar_tablas(solo_activas=True)
    claves_activas = [rbac.clave_tabla(t["esquema"], t["nombre_tabla"]) for t in cfg]
    permisos = rbac.permisos_datos(repo.permisos_de_roles(ctx.ids_roles), claves_activas)
    if not permisos:
        return ResultadoDatos("bloqueado", MSG_SIN_TABLAS, "el rol no tiene tablas del datawarehouse habilitadas")

    try:
        esq_completo = esquema.leer_esquema(cfg)
    except Exception as e:
        log.error("No se pudo leer el esquema del datawarehouse: %s", e)
        return ResultadoDatos("error", MSG_DWH_NO_DISPONIBLE, f"lectura del esquema: {e}")
    esq_rol = esquema.filtrar_para_rol(esq_completo, permisos)
    if not esq_rol.tablas:
        return ResultadoDatos("error", MSG_ERROR_GENERICO, "ninguna tabla habilitada existe en el datawarehouse")

    columnas_por_tabla = {k: {c.nombre.lower(): c.tipo for c in t.columnas} for k, t in esq_completo.tablas.items()}
    filtros_area = {k: t.filtro_registros for k, t in esq_completo.tablas.items() if t.filtro_registros}
    ids_por_clave = {k: t.id_tabla for k, t in esq_completo.tablas.items()}

    sql_previo = error_previo = None
    ultimo_sql = None
    for intento in range(1 + max(0, s.sql_reintentos_reparacion)):
        gen = generador.generar(pregunta, esq_rol, hoy, pide_proyeccion=pide_proyeccion, grafico=grafico, mensaje_usuario=mensaje_usuario,
                                sql_previo=sql_previo, error_previo=error_previo)
        if not gen["sql"]:
            msg = gen.get("motivo") or "No hay información habilitada que permita responder esa pregunta."
            return ResultadoDatos("sin_respuesta", f"No puedo responder esa pregunta con los datos habilitados: {msg}",
                                  "pregunta sin tabla habilitada que la resuelva")
        ultimo_sql = gen["sql"]
        try:
            v = validador.validar(gen["sql"], permisos, columnas_por_tabla, filtros_area, ctx.area)
        except validador.ConsultaBloqueada as b:
            # el SQL se muestra solo en la consola del servidor (depuracion), nunca al usuario
            log.warning("Consulta BLOQUEADA [%s | roles: %s] motivo: %s | SQL generado: %s", ctx.email, ctx.rol_codigo, b.motivo_auditoria, gen["sql"])
            return ResultadoDatos("bloqueado", b.motivo_usuario, b.motivo_auditoria, sql_generado=gen["sql"])
        except validador.ConsultaInvalida as e:
            sql_previo, error_previo = gen["sql"], str(e)
            log.info("Consulta invalida (intento %s) [%s]: %s | SQL generado: %s", intento + 1, ctx.email, e, gen["sql"])
            continue
        log.info("SQL generado por el modelo [%s | roles: %s | intento %s]: %s", ctx.email, ctx.rol_codigo, intento + 1, gen["sql"])
        log.info("SQL a ejecutar (validado, con las restricciones del rol): %s", v.sql)
        t0 = time.perf_counter()
        try:
            res = ejecutor.ejecutar(v.sql)
        except ejecutor.ErrorEjecucion as e:
            sql_previo, error_previo = gen["sql"], str(e)
            log.warning("Error al ejecutar (intento %s) [%s]: %s", intento + 1, ctx.email, e)
            continue
        log.info("Consulta ejecutada: %s filas en %.0f ms%s", len(res.filas), (time.perf_counter() - t0) * 1000, " (truncado)" if res.truncado else "")

        r = ResultadoDatos(
            "ok", columnas=res.columnas, filas=res.filas, truncado=res.truncado, sql_generado=gen["sql"],
            sql_ejecutado=v.sql, ids_tablas=[ids_por_clave[k] for k in v.tablas if k in ids_por_clave],
        )
        ip, im = _detectar_columnas(res, gen["columna_periodo"], gen["columna_medida"])
        if ip is not None and im is not None and res.filas:
            serie = proyeccion.serie_mensual(res.filas, ip, im)
            r.resumen = proyeccion.resumen_variacion(serie, hoy)
            if pide_proyeccion:
                r.proyeccion = proyeccion.proyectar(serie, hoy, s.proy_meses_base, s.proy_horizonte)
        elif pide_proyeccion:
            r.proyeccion = {"proyectable": False, "motivo": "El resultado no es una serie mensual sobre la que proyectar."}
        return r

    return ResultadoDatos("error", MSG_ERROR_GENERICO, f"consulta no resuelta tras reintentos: {error_previo}",
                          sql_generado=ultimo_sql)
