"""Ejecucion de la consulta ya validada, con el usuario de SOLO LECTURA del datawarehouse (HU-011)."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date, datetime, time
from decimal import Decimal
from typing import Any

from .. import db
from ..config import get_settings

log = logging.getLogger("asistente.ejecutor")


class ErrorEjecucion(Exception):
    """Error del motor. El detalle es interno: el usuario nunca ve nombres del esquema (HU-004)."""


@dataclass
class Resultado:
    columnas: list[str]
    filas: list[list[Any]]
    truncado: bool


def a_json_seguro(v: Any) -> Any:
    if isinstance(v, Decimal):
        return float(v)
    if isinstance(v, (datetime, date, time)):
        return v.isoformat()
    if isinstance(v, (bytes, bytearray)):
        return "<binario>"
    return v


def ejecutar(sql: str) -> Resultado:
    s = get_settings()
    try:
        conn = db.conectar_dwh()
    except Exception as e:
        log.error("No se pudo conectar al datawarehouse: %s", e)
        raise ErrorEjecucion(f"conexión: {e}") from e
    try:
        cur = conn.cursor()
        cur.execute(sql)
        if cur.description is None:
            raise ErrorEjecucion("la sentencia no devolvió un conjunto de resultados")
        columnas = [c[0] for c in cur.description]
        filas = cur.fetchmany(s.sql_max_filas + 1)
        truncado = len(filas) > s.sql_max_filas
        filas = [[a_json_seguro(v) for v in f] for f in filas[: s.sql_max_filas]]
        return Resultado(columnas, filas, truncado)
    except ErrorEjecucion:
        raise
    except Exception as e:  # pyodbc.Error y similares
        log.warning("Error al ejecutar la consulta: %s", e)
        raise ErrorEjecucion(str(e)[:400]) from e
    finally:
        conn.close()
