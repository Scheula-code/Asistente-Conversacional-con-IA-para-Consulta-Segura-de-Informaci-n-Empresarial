import os
import tempfile

_tmp = tempfile.mkdtemp(prefix="asistente_test_")
os.environ.update({"OPENAI_API_KEY": "sk-test", "DATA_DIR": _tmp, "DB_TRUSTED": "yes"})
