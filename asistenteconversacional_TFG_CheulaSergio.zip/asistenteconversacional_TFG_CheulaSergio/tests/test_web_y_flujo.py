from datetime import datetime
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient
from langchain_core.messages import AIMessage

from app import orquestador as orq
from app.datos import servicio as sd
from app.datos.ejecutor import Resultado
from app.datos.esquema import Columna, EsquemaDWH, Tabla
from app.main import app
from app.security.auth import Contexto
from app.web.deps import plantillas

CTX = Contexto(1, 7, "Ana Prueba", "ana@x.com", "Comercial Norte", (3,), ("comercial_todo",), False, "127.0.0.1")
ADMIN = Contexto(2, 1, "Admin", "adm@x.com", None, (4,), ("administracion",), False, "127.0.0.1")
cliente = TestClient(app)


# ---------------------------------------------------------------- web sin base de datos
def test_login_y_redirecciones_sin_sesion():
    assert cliente.get("/login").status_code == 200
    r = cliente.get("/", follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"] == "/login"
    assert cliente.get("/admin/documentos", follow_redirects=False).headers["location"] == "/login"
    assert cliente.get("/api/conversaciones").status_code == 401
    assert cliente.get("/api/health").json() == {"estado": "ok"}


def test_csrf_origen_y_cabeceras():
    r = cliente.post("/login", data={"email": "a@b.com", "clave": "x"})
    assert r.status_code == 403  # sin Origin/Referer
    r = cliente.post("/login", data={}, headers={"Origin": "http://evil.example"})
    assert r.status_code == 403
    g = cliente.get("/login")
    assert "frame-ancestors 'none'" in g.headers["content-security-policy"] and g.headers["x-frame-options"] == "DENY"
    assert cliente.get("/openapi.json").status_code == 404


def test_se_renderizan_todas_las_plantillas():
    ahora = datetime(2026, 10, 27, 12, 0)
    base = {"ctx": CTX, "ok": "listo", "error": "algo", "inactividad_min": 30}
    doc = {"id_documento": 1, "codigo": "SOP-1", "version": "1", "titulo": "T", "tipo": "SOP", "vigente": True, "indexado": True,
           "error_indexacion": None, "categoria": "Calidad", "fragmentos": 4,
           "proceso_replicado": None, "capacidad_validada": None}
    tipos, categorias = {"SOP": "SOP"}, ["Calidad"]
    casos = {
        "login.html": {"ctx": None, "mensaje": "x", "email": "a@b"},
        "cambiar_clave.html": {"errores": ["e"], "min_largo": 12, "historial": 5},
        "error.html": {"ctx": None, "codigo": 403, "detalle": "no"},
        "chat.html": {},
        "admin/documentos.html": {"seccion": "documentos", "documentos": [doc], "resultados": [{"archivo": "a.pdf", "ok": False, "mensaje": "m"}],
                                  "tipos": tipos, "categorias": categorias, "vectores": 4},
        "admin/documento_editar.html": {"seccion": "documentos", "d": doc, "tipos": tipos, "categorias": categorias},
        "admin/usuarios.html": {"seccion": "usuarios", "clave_temporal": "Abc", "usuario_temporal": "u@x",
                                "usuarios": [{"id_usuario": 1, "email": "u@x", "nombre": "U", "area": None, "ids_roles": [3], "roles": ["comercial_todo"], "activo": True,
                                              "bloqueado": True, "debe_cambiar_clave": True}],
                                "roles": [{"id_rol": 3, "nombre": "comercial_todo"}]},
        "admin/roles.html": {"seccion": "roles", "roles": [{"id_rol": 3, "nombre": "comercial_todo"}], "categorias": ["Calidad"],
                             "rol": {"id_rol": 3, "nombre": "comercial_todo", "descripcion": "d", "usuarios": 2},
                             "resumen": {"documentos": [{"id_permiso": 1, "recurso": "*", "origen": "m"}],
                                         "tablas": [{"id_permiso": 2, "recurso": "a.b", "nivel_acceso": "lectura", "origen": "m", "habilitada": False}],
                                         "columnas": [{"id_permiso": 3, "recurso": "a.b.c", "nivel_acceso": "denegado", "origen": "m"}]},
                             "tablas": []},
        "admin/tablas.html": {"seccion": "tablas", "tablas": [{"id_tabla": 1, "esquema": "a", "nombre_tabla": "b", "objetivo": "o", "filtro_registros": None, "activa": True}]},
        "admin/tabla_detalle.html": {"seccion": "tablas", "t": {"id_tabla": 1, "esquema": "a", "nombre_tabla": "b", "objetivo": "o",
                                                                 "aclaraciones": None, "filtro_registros": None, "activa": True},
                                     "leida": SimpleNamespace(columnas=[Columna("c", "int")]), "error_lectura": None},
        "admin/auditoria.html": {"seccion": "auditoria", "f_tipo": "", "f_resultado": "", "f_usuario": "",
                                 "filas": [{"fecha": ahora, "tipo_evento": "BLOQUEO", "resultado": "bloqueada", "usuario": "u", "rol": "r",
                                            "herramienta": "h", "motivo_bloqueo": "m", "detalle": None, "sql_generado": "SELECT 1", "duracion_ms": 5}]},
    }
    for nombre, extra in casos.items():
        ctx = {**base, **extra}
        if nombre.startswith("admin/"):
            ctx["ctx"] = ADMIN
        html = plantillas.env.get_template(nombre).render(**ctx)
        assert "<html" in html, nombre
    assert "&lt;" not in plantillas.env.get_template("login.html").render(ctx=None, mensaje="a", email="x")
    xss = plantillas.env.get_template("login.html").render(ctx=None, mensaje="<script>1</script>", email="")
    assert "<script>1</script>" not in xss


# ---------------------------------------------------------------- servicio de datos (con dobles)
@pytest.fixture
def datos(monkeypatch):
    cfg = [{"id_tabla": 5, "esquema": "dwh", "nombre_tabla": "ventas", "objetivo": "o", "aclaraciones": None, "filtro_registros": "area", "activa": True}]
    perm = [{"tipo_recurso": "tabla", "recurso": "dwh.ventas", "nivel_acceso": "lectura", "origen": "m"},
            {"tipo_recurso": "columna", "recurso": "dwh.ventas.costo", "nivel_acceso": "denegado", "origen": "m"}]
    esq = EsquemaDWH(tablas={"dwh.ventas": Tabla(5, "dwh", "ventas", "o", None, "area", [
        Columna(c, t) for c, t in [("periodo", "date"), ("monto", "decimal"), ("costo", "decimal"), ("area", "varchar")]])})
    monkeypatch.setattr(sd.repo, "listar_tablas", lambda solo_activas=False: cfg)
    monkeypatch.setattr(sd.repo, "permisos_de_roles", lambda ids: perm)
    monkeypatch.setattr(sd.esquema, "leer_esquema", lambda c, forzar=False: esq)
    return SimpleNamespace(monkeypatch=monkeypatch)


def test_datos_ok_con_proyeccion(datos, monkeypatch):
    filas = [[f"{2025 + (i // 12)}-{i % 12 + 1:02d}-01", 100.0 + 5 * i] for i in range(14)]
    monkeypatch.setattr(sd.generador, "generar", lambda *a, **k: {"sql": "SELECT periodo, SUM(monto) m FROM dwh.ventas GROUP BY periodo",
                                                                   "columna_periodo": "periodo", "columna_medida": "m", "motivo": None})
    ejecutadas = []
    monkeypatch.setattr(sd.ejecutor, "ejecutar", lambda sql: ejecutadas.append(sql) or Resultado(["periodo", "m"], filas, False))
    from datetime import date
    r = sd.consultar_datos(CTX, "venta", True, hoy=date(2026, 3, 10))
    assert r.estado == "ok" and r.ids_tablas == [5] and r.proyeccion["proyectable"]
    assert r.resumen["variacion_absoluta"] > 0 and "costo" not in ejecutadas[0].lower()
    assert "'Comercial Norte'" not in ejecutadas[0]  # el rol no es de area: sin filtro


def test_datos_bloqueos_y_reintento(datos, monkeypatch):
    monkeypatch.setattr(sd.generador, "generar", lambda *a, **k: {"sql": "SELECT costo FROM dwh.ventas", "columna_periodo": None, "columna_medida": None, "motivo": None})
    monkeypatch.setattr(sd.ejecutor, "ejecutar", lambda sql: pytest.fail("no debe ejecutarse"))
    r = sd.consultar_datos(CTX, "costo")
    assert r.estado == "bloqueado" and r.filas == [] and "costo" not in (r.mensaje or "").lower()
    monkeypatch.setattr(sd.generador, "generar", lambda *a, **k: {"sql": "DROP TABLE dwh.ventas", "columna_periodo": None, "columna_medida": None, "motivo": None})
    assert sd.consultar_datos(CTX, "x").estado == "bloqueado"
    llamadas = []

    def mala_y_buena(*a, **k):
        llamadas.append(k.get("error_previo"))
        return {"sql": "SELECT inventada FROM dwh.ventas" if len(llamadas) == 1 else "SELECT monto FROM dwh.ventas",
                "columna_periodo": None, "columna_medida": None, "motivo": None}

    monkeypatch.setattr(sd.generador, "generar", mala_y_buena)
    monkeypatch.setattr(sd.ejecutor, "ejecutar", lambda sql: Resultado(["monto"], [[1.0]], False))
    assert sd.consultar_datos(CTX, "x").estado == "ok" and llamadas[1]  # el 2.o intento recibio el error


def test_datos_sin_tablas_para_el_rol(datos, monkeypatch):
    monkeypatch.setattr(sd.repo, "permisos_de_roles", lambda ids: [])
    r = sd.consultar_datos(CTX, "x")
    assert r.estado == "bloqueado" and "no tiene tablas" in r.mensaje


# ---------------------------------------------------------------- orquestador (modelo de mentira)
class ModeloFalso:
    def __init__(self, respuestas):
        self.respuestas = list(respuestas)

    def invoke(self, mensajes):
        return self.respuestas.pop(0)


@pytest.fixture
def orquesta(monkeypatch):
    reg = SimpleNamespace(consultas=[], auditoria=[], mensajes=[])
    monkeypatch.setattr(orq.repo, "crear_conversacion", lambda u, t: 11)
    monkeypatch.setattr(orq.repo, "ultimos_mensajes", lambda c, n: [])
    monkeypatch.setattr(orq.repo, "insertar_mensaje", lambda c, e, t, d=None: reg.mensajes.append((e, t, d)) or len(reg.mensajes))
    monkeypatch.setattr(orq.repo, "insertar_consulta", lambda c: reg.consultas.append(c) or len(reg.consultas))
    monkeypatch.setattr(orq.repo, "vincular_tablas", lambda *a: None)
    monkeypatch.setattr(orq, "auditar", lambda tipo, res, ctx=None, **k: reg.auditoria.append((tipo, res, k)))
    monkeypatch.setattr(orq.repo, "permisos_de_roles", lambda i: [{"tipo_recurso": "documento", "recurso": "*", "nivel_acceso": "lectura"}])
    return reg


def llamada(nombre, **args):
    return AIMessage(content="", tool_calls=[{"name": nombre, "args": args, "id": "t1"}])


def test_orquestador_documental_con_citas(orquesta, monkeypatch):
    frs = [{"id_fragmento": 1, "codigo": "SOP-1", "titulo": "Liberación", "version": "2", "seccion": "5.2", "pagina": 3, "texto": "txt", "score": .8, "advertencia": None}]
    monkeypatch.setattr(orq.servicio_rag, "buscar", lambda p, a: frs)
    monkeypatch.setattr(orq, "_modelo_con_herramientas", lambda: ModeloFalso([llamada("consultar_documentos", pregunta="¿cómo?"), AIMessage(content="Se aprueba así [F1].")]))
    r = orq.responder(CTX, "¿cómo se libera?")
    assert r.fuente == "documental" and r.texto == "Se aprueba así [1]." and r.citas[0]["codigo"] == "SOP-1" and r.citas[0]["version"] == "2"
    assert orquesta.consultas[0]["tipo"] == "documental" and orquesta.consultas[0]["estado"] == "ejecutada"
    assert orquesta.auditoria[0][:2] == ("CONSULTA", "respondida")


def test_orquestador_sin_evidencia_es_deterministico(orquesta, monkeypatch):
    monkeypatch.setattr(orq.servicio_rag, "buscar", lambda p, a: [])
    monkeypatch.setattr(orq, "_modelo_con_herramientas", lambda: ModeloFalso([llamada("consultar_documentos", pregunta="x")]))
    r = orq.responder(CTX, "algo que no está")
    assert r.texto == orq.MSG_SIN_EVIDENCIA and r.citas == [] and r.estado == "ok"


def test_orquestador_bloqueo_no_devuelve_datos(orquesta, monkeypatch):
    bloq = sd.ResultadoDatos("bloqueado", "Excede su rol.", "tabla fuera del alcance", sql_generado="SELECT 1")
    monkeypatch.setattr(orq.servicio_datos, "consultar_datos", lambda *a, **k: bloq)
    monkeypatch.setattr(orq, "_modelo_con_herramientas", lambda: ModeloFalso([llamada("consultar_datos", pregunta="x")]))
    r = orq.responder(CTX, "dame los sueldos")
    assert r.estado == "bloqueado" and r.texto == "Excede su rol." and r.datos is None and r.fuente == "bloqueada"
    assert orquesta.consultas[0]["estado"] == "rechazada" and orquesta.auditoria[0][:2] == ("BLOQUEO", "bloqueada")


def test_orquestador_datos_mixta_y_modelo_caido(orquesta, monkeypatch):
    ok = sd.ResultadoDatos("ok", columnas=["m"], filas=[[1.0]], sql_generado="g", sql_ejecutado="e", ids_tablas=[5])
    monkeypatch.setattr(orq.servicio_datos, "consultar_datos", lambda *a, **k: ok)
    monkeypatch.setattr(orq, "_modelo_con_herramientas", lambda: ModeloFalso([llamada("consultar_datos", pregunta="x", pide_proyeccion=False), AIMessage(content="Vale 1.")]))
    r = orq.responder(CTX, "cuánto")
    assert r.fuente == "datos" and r.datos["filas"] == [[1.0]] and orquesta.consultas[-1]["sql_ejecutado"] == "e"

    class Caido:
        def invoke(self, m):
            raise orq.llm.ServicioLLMNoDisponible("sin red")

    monkeypatch.setattr(orq, "_modelo_con_herramientas", lambda: Caido())
    monkeypatch.setattr(orq.llm, "con_reintentos", lambda fn: fn())
    r = orq.responder(CTX, "hola")
    assert r.estado == "error" and r.texto == orq.MSG_MODELO_CAIDO and orquesta.consultas[-1]["estado"] == "error_modelo"


def test_conversacion_ajena(orquesta, monkeypatch):
    monkeypatch.setattr(orq.repo, "conversacion_de_usuario", lambda c, u: None)
    with pytest.raises(orq.ConversacionInexistente):
        orq.responder(CTX, "hola", 99)
    with pytest.raises(ValueError):
        orq.responder(CTX, "   ")


def test_chat_model_envia_reasoning_effort_y_puede_omitir_temperatura(monkeypatch):
    from langchain_core.messages import HumanMessage

    from app import llm
    from app.config import get_settings

    def payload(**env):
        for k, v in env.items():
            monkeypatch.setenv(k, v)
        get_settings.cache_clear(); llm.chat_model.cache_clear()
        try:
            return llm.chat_model()._get_request_payload([HumanMessage(content="hola")])
        finally:
            get_settings.cache_clear(); llm.chat_model.cache_clear()

    base = payload()
    assert base["temperature"] == 0 and "extra_body" not in base
    r = payload(OPENAI_REASONING_EFFORT="none", OPENAI_TEMPERATURE="omitir")
    assert r["extra_body"] == {"reasoning_effort": "none"} and "temperature" not in r


def test_el_tipo_de_grafico_pedido_llega_a_la_interfaz(orquesta, monkeypatch):
    ok = sd.ResultadoDatos("ok", columnas=["cliente", "u"], filas=[["a", 1.0], ["b", 2.0]], sql_generado="g", sql_ejecutado="e", ids_tablas=[5])
    monkeypatch.setattr(orq.servicio_datos, "consultar_datos", lambda *a, **k: ok)
    for pedido, esperado in [("torta", "torta"), ("Barras", "barras"), ("cualquier cosa", "auto"), (None, "auto")]:
        ok.grafico = "auto"
        args = {"pregunta": "x"} if pedido is None else {"pregunta": "x", "grafico": pedido}
        monkeypatch.setattr(orq, "_modelo_con_herramientas", lambda a=args: ModeloFalso([llamada("consultar_datos", **a), AIMessage(content="Listo.")]))
        r = orq.responder(CTX, "mostralo")
        assert r.datos["grafico"] == esperado
    assert "grafico" in orq.consultar_datos.args and "nunca digas que no podés graficar" in orq.SISTEMA.lower()


def test_los_archivos_estaticos_se_revalidan_y_el_prompt_no_se_contradice():
    r = cliente.get("/static/chat.js")
    assert r.status_code == 200 and r.headers["cache-control"] == "no-cache" and "tiposDisponibles" in r.text
    assert cliente.get("/login").headers["cache-control"] == "no-store"
    from app.datos import generador
    assert "usá el período que mejor responda" not in generador._SISTEMA
    assert "NO filtres por mes" in generador._SISTEMA


def test_el_tipo_de_grafico_guia_la_consulta_sql(datos, monkeypatch):
    from app.datos import generador

    capturado = []

    class Modelo:
        def bind(self, **k):
            return self

        def invoke(self, mensajes):
            capturado.append(mensajes[-1].content)
            return AIMessage(content='{"sql": null, "motivo": "x"}')

    monkeypatch.setattr(generador.llm, "chat_model", lambda: Modelo())
    esq = EsquemaDWH(tablas={})
    from datetime import date
    for tipo, marca in [("linea", "LÍNEAS"), ("torta", "TORTA"), ("barras", "BARRAS")]:
        generador.generar("p", esq, date(2026, 10, 28), grafico=tipo)
        assert marca in capturado[-1]
    generador.generar("p", esq, date(2026, 10, 28), grafico="auto")
    assert "gráfico de" not in capturado[-1]

    pedidos = []
    monkeypatch.setattr(sd.generador, "generar", lambda *a, **k: pedidos.append(k.get("grafico")) or
                        {"sql": None, "columna_periodo": None, "columna_medida": None, "motivo": "m"})
    sd.consultar_datos(CTX, "evolución por cliente", grafico="linea")
    assert pedidos == ["linea"]


@pytest.mark.parametrize("texto,esperado", [
    ("me lo mostras con un grafico de torta", "torta"), ("mostralo en torta", "torta"), ("Gráfico de PASTEL por favor", "torta"),
    ("pasalo a barras", "barras"), ("mostrame en grafico de lineas", "linea"), ("graficá la venta en línea", "linea"),
    ("sin grafico, solo la tabla", "ninguno"),
    ("ventas por línea terapéutica", None), ("mostrame la linea terapeutica con mas ventas", None),
    ("decime las unidades vendidas por cliente", None), ("armá una circular sobre el procedimiento", None),
    ("contribución por producto", None),
])
def test_el_texto_del_pedido_decide_el_grafico(texto, esperado):
    assert orq.grafico_pedido(texto) == esperado


def test_lo_que_escribe_el_usuario_manda_sobre_el_modelo(orquesta, monkeypatch):
    ok = sd.ResultadoDatos("ok", columnas=["cliente", "u"], filas=[["a", 1.0], ["b", 2.0]], sql_generado="g", sql_ejecutado="e", ids_tablas=[5])
    pedidos = []
    monkeypatch.setattr(orq.servicio_datos, "consultar_datos", lambda *a, **k: pedidos.append(k.get("grafico")) or ok)
    # el modelo "olvida" pasar el tipo de grafico (o pasa auto): igual se dibuja lo que el usuario pidio
    monkeypatch.setattr(orq, "_modelo_con_herramientas", lambda: ModeloFalso([llamada("consultar_datos", pregunta="x"), AIMessage(content="Listo.")]))
    r = orq.responder(CTX, "me lo mostras con un grafico de torta")
    assert r.datos["grafico"] == "torta" and pedidos == ["torta"]
    monkeypatch.setattr(orq, "_modelo_con_herramientas", lambda: ModeloFalso([llamada("consultar_datos", pregunta="x", grafico="barras"), AIMessage(content="Listo.")]))
    assert orq.responder(CTX, "mostrame en grafico de lineas").datos["grafico"] == "linea"


def test_el_generador_recibe_la_granularidad_y_el_mensaje_literal(monkeypatch):
    from datetime import date

    from app.datos import generador

    vistos = []

    class Modelo:
        def bind(self, **k):
            return self

        def invoke(self, mensajes):
            vistos.append(mensajes)
            return AIMessage(content='{"sql": null, "motivo": "x"}')

    monkeypatch.setattr(generador.llm, "chat_model", lambda: Modelo())
    esq = EsquemaDWH(tablas={})
    generador.generar("unidades por producto por año", esq, date(2026, 10, 28), grafico="linea", mensaje_usuario="pero la tabla tiene el período, lo quiero por año")
    sistema, humano = vistos[-1][0].content, vistos[-1][1].content
    assert "GRANULARIDAD" in sistema and "NUNCA devuelvas el detalle mensual" in sistema
    assert "MENSAJE LITERAL DEL USUARIO" in humano and "lo quiero por año" in humano
    assert "que manda sobre esto" in humano and "una fila por mes (" not in humano      # la guia de lineas ya no fuerza lo mensual
    generador.generar("misma pregunta", esq, date(2026, 10, 28), mensaje_usuario="misma pregunta")
    assert "MENSAJE LITERAL" not in vistos[-1][1].content                                 # no se repite si es igual


def test_el_mensaje_del_usuario_llega_hasta_el_generador(orquesta, monkeypatch):
    recibido = {}
    ok = sd.ResultadoDatos("ok", columnas=["anio", "u"], filas=[[2025, 1.0], [2026, 2.0]], sql_generado="g", sql_ejecutado="e", ids_tablas=[5])
    monkeypatch.setattr(orq.servicio_datos, "consultar_datos", lambda *a, **k: recibido.update(k) or ok)
    monkeypatch.setattr(orq, "_modelo_con_herramientas", lambda: ModeloFalso([llamada("consultar_datos", pregunta="unidades por año"), AIMessage(content="ok")]))
    orq.responder(CTX, "pero la tabla tiene el período, lo quiero por año")
    assert recibido["mensaje_usuario"] == "pero la tabla tiene el período, lo quiero por año"


# ---------------------------------------------------------------- el SQL no se muestra al usuario, pero queda en la consola
def test_por_defecto_el_sql_no_se_muestra():
    from app.config import get_settings
    assert get_settings().mostrar_sql is False


def test_la_respuesta_no_lleva_el_sql_pero_la_auditoria_si(orquesta, monkeypatch):
    ok = sd.ResultadoDatos("ok", columnas=["c", "u"], filas=[["a", 1.0]], sql_generado="SELECT GENERADO", sql_ejecutado="SELECT EJECUTADO", ids_tablas=[5])
    monkeypatch.setattr(orq.servicio_datos, "consultar_datos", lambda *a, **k: ok)
    monkeypatch.setattr(orq, "_modelo_con_herramientas", lambda: ModeloFalso([llamada("consultar_datos", pregunta="x"), AIMessage(content="Listo.")]))
    r = orq.responder(CTX, "cuanto")
    assert r.datos["sql"] is None
    assert "SELECT" not in orquesta.mensajes[-1][2]                      # tampoco queda en el detalle guardado del mensaje
    assert orquesta.consultas[0]["sql_ejecutado"] == "SELECT EJECUTADO"   # la auditoria (solo administracion) conserva el SQL


def test_el_historial_viejo_tampoco_muestra_el_sql(monkeypatch):
    import json
    from app.web import rutas_chat
    from app.web.deps import exigir_consultante
    guardado = json.dumps({"fuente": "datos", "datos": {"columnas": ["a"], "filas": [[1]], "sql": "SELECT VIEJO"}, "citas": []})
    monkeypatch.setattr(rutas_chat.repo, "conversacion_de_usuario", lambda c, u: {"id_conversacion": c})
    monkeypatch.setattr(rutas_chat.repo, "mensajes_de_conversacion", lambda c: [
        {"id_mensaje": 5, "emisor": "asistente", "texto": "t", "fecha": datetime(2026, 10, 1), "detalle_json": guardado}])
    app.dependency_overrides[exigir_consultante] = lambda: CTX
    try:
        r = cliente.get("/api/conversaciones/3")
    finally:
        app.dependency_overrides.clear()
    assert r.status_code == 200 and "sql" not in r.json()[0]["detalle"]["datos"] and "SELECT" not in r.text


def test_el_sql_queda_en_la_consola_del_servidor(datos, monkeypatch, caplog):
    import logging
    monkeypatch.setattr(sd.generador, "generar", lambda *a, **k: {"sql": "SELECT monto FROM dwh.ventas", "columna_periodo": None, "columna_medida": None, "motivo": None})
    monkeypatch.setattr(sd.ejecutor, "ejecutar", lambda sql: Resultado(["monto"], [[1.0], [2.0]], False))
    with caplog.at_level(logging.INFO, logger="asistente.datos"):
        r = sd.consultar_datos(CTX, "x")
    assert r.estado == "ok"
    texto = "\n".join(m.getMessage() for m in caplog.records)
    assert "SQL generado por el modelo [ana@x.com" in texto and "SELECT monto FROM dwh.ventas" in texto
    assert "SQL a ejecutar (validado" in texto and "[dwh].[ventas]" in texto and "Consulta ejecutada: 2 filas" in texto
    # un bloqueo tambien se explica en la consola (con el SQL y el motivo), aunque al usuario solo le llegue un mensaje general
    caplog.clear()
    monkeypatch.setattr(sd.generador, "generar", lambda *a, **k: {"sql": "SELECT costo FROM dwh.ventas", "columna_periodo": None, "columna_medida": None, "motivo": None})
    with caplog.at_level(logging.INFO, logger="asistente.datos"):
        b = sd.consultar_datos(CTX, "x")
    texto = "\n".join(m.getMessage() for m in caplog.records)
    assert b.estado == "bloqueado" and "Consulta BLOQUEADA" in texto and "SELECT costo FROM dwh.ventas" in texto
    assert "costo" not in (b.mensaje or "").lower()
