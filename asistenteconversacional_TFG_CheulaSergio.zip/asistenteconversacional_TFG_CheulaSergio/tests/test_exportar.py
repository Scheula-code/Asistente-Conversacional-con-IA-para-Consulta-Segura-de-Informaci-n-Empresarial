import io
from datetime import datetime

import pytest
from fastapi.testclient import TestClient
from openpyxl import load_workbook

from app import exportar
from app.main import app
from app.security.auth import Contexto
from app.web import rutas_chat
from app.web.deps import exigir_consultante

CTX = Contexto(1, 7, "Ana Prueba", "ana@x.com", "Comercial Norte", (3,), ("comercial_todo",), False, "127.0.0.1")
CLIENTES = ["Obra Social Demo C", "Distribuidora Demo NOA", "Farmacias Demo Barrio", "Obra Social Demo A"]


def libro(datos, **kw):
    contenido = exportar.a_excel(datos, pregunta="¿cuánto?", usuario="ana@x.com", roles="comercial_todo",
                                 fecha=datetime(2026, 10, 28, 12, 30), **kw)
    return load_workbook(io.BytesIO(contenido))


def tipos_de_grafico(wb):
    return [type(c).__name__ for ws in wb for c in ws._charts]


def test_hojas_formatos_y_filtros():
    wb = libro({"columnas": ["cliente", "periodo", "unidades", "venta"], "grafico": "ninguno",
                "filas": [["A", "2026-10-01", 5, 10.5], ["B", "2026-10-01", 7, None]], "sql": "SELECT 1"}, mostrar_sql=True)
    assert wb.sheetnames == ["Resultado", "Consulta"]
    ws = wb["Resultado"]
    assert [c.value for c in ws[1]] == ["cliente", "periodo", "unidades", "venta"]
    assert ws["B2"].value == datetime(2026, 10, 1) and ws["B2"].number_format == "yyyy-mm-dd"
    assert ws["C2"].number_format == "#,##0" and ws["D2"].number_format == "#,##0.00" and ws["D3"].value is None
    assert ws.freeze_panes == "A2" and ws.auto_filter.ref == "A1:D3" and ws["A1"].font.name == "Arial"
    consulta = {r[0].value: r[1].value for r in wb["Consulta"].iter_rows()}
    assert consulta["Pregunta"] == "¿cuánto?" and consulta["Usuario"] == "ana@x.com" and consulta["Filas"] == 2
    assert consulta["SQL ejecutado (solo lectura)"] == "SELECT 1" and consulta["Generado"] == "28/10/2026 12:30"


def test_el_sql_no_se_incluye_si_no_se_muestra():
    wb = libro({"columnas": ["a", "b"], "filas": [["x", 1]], "grafico": "ninguno", "sql": "SELECT secreto"}, mostrar_sql=False)
    assert "SELECT secreto" not in [r[1].value for r in wb["Consulta"].iter_rows()]


@pytest.mark.parametrize("valor", ["=1+1", "+cmd|' /C calc'!A0", "-2+3", "@SUM(A1)", "=HYPERLINK(\"http://x\",\"y\")"])
def test_un_texto_que_parece_formula_queda_como_texto(valor):
    wb = libro({"columnas": ["nombre", "monto"], "filas": [[valor, 1.0], ["otro", 2.0]], "grafico": "ninguno"})
    celda = wb["Resultado"]["A2"]
    assert celda.value == valor and celda.data_type == "s"
    # y no hay ninguna formula en ninguna hoja
    assert all(c.data_type != "f" for ws in wb for fila in ws.iter_rows() for c in fila)


def test_tipo_de_grafico_segun_lo_pedido():
    cat = {"columnas": ["cliente", "unidades"], "filas": [[c, 100 - i * 10] for i, c in enumerate(CLIENTES)]}
    for pedido, esperado in [("barras", "BarChart"), ("torta", "PieChart"), ("linea", "LineChart"), ("auto", "BarChart")]:
        assert tipos_de_grafico(libro({**cat, "grafico": pedido})) == [esperado], pedido
    assert tipos_de_grafico(libro({**cat, "grafico": "ninguno"})) == []
    serie = {"columnas": ["periodo", "venta"], "filas": [[f"2026-{m:02d}-01", 100.0 + m] for m in range(1, 7)], "grafico": "auto"}
    assert tipos_de_grafico(libro(serie)) == ["LineChart"]                  # tres o mas periodos: linea
    multi = {"columnas": ["periodo", "cliente", "u"], "grafico": "linea",
             "filas": [[f"2026-{m:02d}-01", c, 10.0 * (k + 1) + m] for k, c in enumerate(CLIENTES[:3]) for m in range(1, 5)]}
    wb = libro(multi)
    assert tipos_de_grafico(wb) == ["LineChart"] and len(wb["Gráfico"]._charts[0].series) == 3


def test_proyeccion_y_avisos():
    serie = {"columnas": ["periodo", "venta"], "filas": [[f"2025-{m:02d}-01", 100.0 + m] for m in range(1, 13)], "grafico": "auto",
             "proyeccion": {"proyectable": True, "regla": "tendencia lineal", "periodo_base": "2025-01 a 2025-12", "total_horizonte": 400.0,
                            "proyeccion": [{"periodo": "2026-01", "valor": 120.0}, {"periodo": "2026-02", "valor": 121.0}]}}
    wb = libro(serie)
    assert len(wb["Gráfico"]._charts[0].series) == 2 and wb["Gráfico"]["C14"].value == 120.0
    assert any("Proyección" in str(r[0].value) for r in wb["Consulta"].iter_rows())
    neg = libro({"columnas": ["producto", "resultado"], "filas": [["a", -5.0], ["b", -2.0]], "grafico": "torta"})
    assert "Gráfico" not in neg.sheetnames
    assert any("torta" in str(r[1].value) for r in neg["Consulta"].iter_rows())
    sin_valor = libro({"columnas": ["a", "b"], "filas": [["x", "y"], ["z", "w"]], "grafico": "auto"})
    assert sin_valor.sheetnames == ["Resultado", "Consulta"]
    trunc = libro({"columnas": ["a", "b"], "filas": [["x", 1]], "truncado": True, "grafico": "ninguno"})
    assert any("límite" in str(r[1].value) for r in trunc["Consulta"].iter_rows())


def test_torta_agrupa_en_otros():
    wb = libro({"columnas": ["producto", "venta"], "filas": [[f"P{i}", 100.0 - i] for i in range(20)], "grafico": "torta"})
    ws = wb["Gráfico"]
    assert ws.max_row == 13 and ws["A13"].value == "Otros"          # 11 porciones + Otros + encabezado


# ---------------------------------------------------------------- endpoint
@pytest.fixture
def descarga(monkeypatch):
    import json
    registro = {"auditoria": []}
    detalle = json.dumps({"fuente": "datos", "datos": {"columnas": ["cliente", "unidades"], "filas": [["a", 3.0], ["b", 2.0]], "grafico": "barras", "sql": "SELECT 1"}})
    monkeypatch.setattr(rutas_chat.repo, "mensaje_de_usuario",
                        lambda i, u: {"id_mensaje": i, "id_conversacion": 9, "texto": "t", "fecha": None, "detalle_json": detalle} if (i, u) == (50, 7) else
                        ({"id_mensaje": i, "id_conversacion": 9, "texto": "t", "fecha": None, "detalle_json": json.dumps({"citas": []})} if (i, u) == (51, 7) else None))
    monkeypatch.setattr(rutas_chat.repo, "pregunta_previa", lambda c, i: "decime las unidades por cliente")
    monkeypatch.setattr(rutas_chat, "auditar", lambda tipo, res, ctx=None, **k: registro["auditoria"].append((tipo, res, k.get("detalle"))))
    app.dependency_overrides[exigir_consultante] = lambda: CTX
    yield TestClient(app), registro
    app.dependency_overrides.clear()


def test_descarga_de_un_resultado_propio(descarga):
    cliente, registro = descarga
    r = cliente.get("/api/mensajes/50/excel")
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    assert r.headers["content-disposition"].startswith('attachment; filename="consulta_50_') and r.headers["content-disposition"].endswith('.xlsx"')
    wb = load_workbook(io.BytesIO(r.content))
    assert wb.sheetnames == ["Resultado", "Gráfico", "Consulta"] and wb["Resultado"]["A2"].value == "a"
    assert any(r_[1].value == "decime las unidades por cliente" for r_ in wb["Consulta"].iter_rows())
    assert registro["auditoria"] == [("DESCARGA", "ok", "mensaje 50: 2 filas a Excel")]
    assert "SELECT 1" not in [c.value for fila in wb["Consulta"].iter_rows() for c in fila]    # el SQL no sale del servidor


def test_no_se_puede_bajar_lo_ajeno_ni_lo_que_no_tiene_tabla(descarga):
    cliente, registro = descarga
    assert cliente.get("/api/mensajes/99/excel").status_code == 404      # mensaje de otro usuario o inexistente
    assert cliente.get("/api/mensajes/51/excel").status_code == 404      # respuesta sin tabla
    assert registro["auditoria"] == []


def test_resultado_anual_se_reconoce_como_periodo_y_no_como_cifra():
    anual = {"columnas": ["anio", "producto", "unidades"], "grafico": "linea",
             "filas": [[a, p, 100 + a % 100 + k] for a in (2024, 2025, 2026) for k, p in enumerate(["A", "B", "C"])]}
    info = exportar.analizar(anual["columnas"], anual["filas"])
    assert info["col_periodo"] == 0 and info["col_valor"] == 2 and info["periodos"] == 3
    wb = libro(anual)
    assert tipos_de_grafico(wb) == ["LineChart"] and len(wb["Gráfico"]._charts[0].series) == 3
    assert wb["Resultado"]["A2"].value == 2024 and wb["Resultado"]["A2"].number_format == "0"      # no "2,024"
    assert wb["Resultado"]["C2"].number_format == "#,##0"
    # trimestre / mes numericos no se toman como la medida
    t = exportar.analizar(["anio", "trimestre", "unidades"], [[2025, 1, 50], [2025, 2, 60], [2026, 1, 70]])
    assert t["col_valor"] == 2
    # una cifra que casualmente parece un ano NO es un periodo si la columna no lo dice
    c = exportar.analizar(["producto", "unidades"], [["a", 2025], ["b", 2026]])
    assert c["col_periodo"] is None and c["col_valor"] == 1


def test_trimestre_es_la_categoria_cuando_acompana_al_anio():
    info = exportar.analizar(["anio", "trimestre", "unidades"], [[2025, 1, 50], [2025, 2, 60], [2025, 3, 55]])
    assert (info["col_periodo"], info["col_etiqueta"], info["col_valor"]) == (0, 1, 2)
