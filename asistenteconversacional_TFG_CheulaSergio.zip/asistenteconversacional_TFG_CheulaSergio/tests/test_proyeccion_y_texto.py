import io
from datetime import date

from app.datos import proyeccion as pr
from app.rag import texto
from app.rag.indice import IndiceVectorial
import numpy as np


def serie_creciente(n, desde=(2025, 1)):
    out, (a, m) = [], desde
    for i in range(n):
        out.append(((a, m), 100.0 + 10 * i))
        m += 1
        if m == 13:
            a, m = a + 1, 1
    return out


def test_proyeccion_lineal_excluye_mes_en_curso():
    serie = serie_creciente(14)  # 2025-01 .. 2026-02; hoy = marzo 2026 -> 14 cerrados, el ultimo base es 2026-02
    r = pr.proyectar(serie, date(2026, 3, 15), 12, 3)
    assert r["proyectable"] and r["periodo_base"] == "2025-03 a 2026-02"
    assert [p["periodo"] for p in r["proyeccion"]] == ["2026-03", "2026-04", "2026-05"]
    assert r["proyeccion"][0]["valor"] == 240.0 and r["pendiente_mensual"] == 10.0
    con_abierto = serie + [((2026, 3), 5.0)]  # mes en curso incompleto: no debe alterar la base
    assert pr.proyectar(con_abierto, date(2026, 3, 15))["proyeccion"] == r["proyeccion"]


def test_proyeccion_rechaza_series_cortas_o_con_huecos():
    assert not pr.proyectar(serie_creciente(8), date(2026, 3, 1))["proyectable"]
    s = serie_creciente(14)
    del s[5]
    assert not pr.proyectar(s, date(2026, 4, 1))["proyectable"]


def test_periodos_y_resumen():
    assert pr.parsear_periodo("2026-03-01") == (2026, 3) and pr.parsear_periodo("202603") == (2026, 3)
    assert pr.parsear_periodo("hola") is None
    r = pr.resumen_variacion(serie_creciente(5), date(2026, 6, 1))
    assert r["variacion_absoluta"] == 40.0 and r["variacion_porcentual"] == 40.0 and not r["ultimo_periodo_abierto"]
    abierta = pr.resumen_variacion(serie_creciente(4, (2026, 1)), date(2026, 4, 10))
    assert abierta["ultimo_periodo_abierto"] and abierta["ultimo_periodo_considerado"]["periodo"] == "2026-03"


def pdf(lineas_por_pagina):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    for lineas in lineas_por_pagina:
        y = 800
        for ln in lineas:
            c.drawString(50, y, ln)
            y -= 14
        c.showPage()
    c.save()
    return buf.getvalue()


def test_extraccion_y_fragmentos_con_pagina_y_seccion():
    lineas1 = ["1. OBJETIVO", "Describir como se libera un lote de producto terminado en planta."] + ["Texto de relleno del procedimiento numero %d con varias palabras." % i for i in range(30)]
    lineas2 = ["2. RESPONSABILIDADES", "El jefe de calidad aprueba la liberacion del lote."] + ["Otra linea de contenido %d para ocupar espacio en la pagina." % i for i in range(30)]
    paginas, _ = texto.extraer_paginas(pdf([lineas1, lineas2]))
    assert len(paginas) == 2
    frs = texto.fragmentar(paginas, 500, 100)
    assert len(frs) > 3 and all(len(f["texto"]) <= 4000 for f in frs)
    assert frs[0]["pagina"] == 1 and frs[0]["seccion"].startswith("1.")
    assert any(f["pagina"] == 2 and (f["seccion"] or "").startswith("2.") for f in frs)
    assert [f["orden"] for f in frs] == list(range(1, len(frs) + 1))


def test_pdf_sin_texto_o_invalido():
    import pytest
    with pytest.raises(texto.ErrorExtraccion):
        texto.extraer_paginas(pdf([[]]))
    with pytest.raises(texto.ErrorExtraccion):
        texto.extraer_paginas(b"%PDF-esto no es un pdf")


def test_indice_filtra_antes_de_recuperar(tmp_path):
    rng = np.random.default_rng(1)
    v = rng.random((6, 16)).astype("float32")
    v /= np.linalg.norm(v, axis=1, keepdims=True)
    idx = IndiceVectorial(tmp_path, 16)
    metas = [{"id_documento": i % 2, "area": "A" if i % 2 else "B", "nivel": "area"} for i in range(6)]
    idx.agregar(list(range(100, 106)), v, metas)
    todos = idx.buscar(v[0], 6, lambda m: True)
    solo_a = idx.buscar(v[0], 6, lambda m: m["area"] == "A")
    assert {i for i, _ in solo_a} == {101, 103, 105} and len(todos) == 6
    assert idx.buscar(v[0], 6, lambda m: False) == []
    idx.actualizar_meta_documento(1, area="C")
    assert idx.buscar(v[0], 6, lambda m: m["area"] == "A") == []
    idx.quitar([101])
    assert IndiceVectorial(tmp_path, 16).total == 5  # persistencia
