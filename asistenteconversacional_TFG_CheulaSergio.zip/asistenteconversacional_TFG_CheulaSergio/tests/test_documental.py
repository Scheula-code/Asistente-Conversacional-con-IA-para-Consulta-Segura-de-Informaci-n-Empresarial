import json
from types import SimpleNamespace

import pytest
from langchain_core.messages import AIMessage

from app import llm
from app import orquestador as orq
from app.rag import lexico, refinar, servicio, texto
from app.security import rbac


# ---------------------------------------------------------------- titulos de seccion (caso real de la captura)
def test_un_parrafo_pegado_al_titulo_no_se_cita_como_seccion():
    linea = "1. Comportamiento realista de los agentes virtuales. Los agentes virtuales, como"
    assert texto._es_titulo(linea)
    assert texto.limpiar_titulo(linea) == "1. Comportamiento realista de los agentes virtuales"
    assert texto.limpiar_titulo("1.3.4 Semántica y agentes inteligentes en entornos virtuales") == "1.3.4 Semántica y agentes inteligentes en entornos virtuales"
    assert texto.limpiar_titulo("OBJETIVO") == "OBJETIVO"
    assert not texto._es_titulo("1. Esta es una frase larga de la lista que continúa describiendo el procedimiento con muchos detalles y termina.")
    corta = texto.Pagina(1, linea + "\nrealista mediante tecnicas de IA y aprendizaje automatico.\n" + "texto de relleno del procedimiento. " * 5)
    assert texto.fragmentar([corta], 500, 50)[0]["seccion"] == "1. Comportamiento realista de los agentes virtuales"
    larga = texto.Pagina(1, linea + " realista mediante tecnicas de IA y aprendizaje automatico, con ejemplos.\n" + "texto de relleno del procedimiento. " * 5)
    assert texto.fragmentar([larga], 500, 50)[0]["seccion"] == "1. Comportamiento realista de los agentes virtuales"   # titulo y parrafo en una sola linea larga


# ---------------------------------------------------------------- BM25
DOCS = [
    (1, "M1L2 Agentes virtuales comportamiento realista aprendizaje automatico redes neuronales", {"categoria": "Cursos"}),
    (2, "M1L3 Usos de los entornos virtuales en educacion y entretenimiento", {"categoria": "Cursos"}),
    (3, "SOP-0007 Liberacion de lote de producto terminado control de calidad", {"categoria": "Calidad"}),
    (4, "Procedimiento de limpieza de equipos en planta", {"categoria": "Calidad"}),
]


def test_tokenizar_normaliza_y_descarta_ruido():
    assert lexico.tokenizar("¿Cómo se LIBERAN los lotes de producción?") == ["liberan", "lote", "produccion"]
    assert lexico.tokenizar("lote") == lexico.tokenizar("lotes")
    assert "el" not in lexico.tokenizar("el lote") and lexico.tokenizar("agentes") == lexico.tokenizar("agente")
    assert lexico.tokenizar_plano("M1L2 v1") == ["m1l2", "v1"]


def test_bm25_acierta_terminos_exactos_y_respeta_permisos():
    bm = lexico.BM25(DOCS)
    todo = lambda m: True  # noqa: E731
    assert bm.buscar("liberacion de lote", 3, todo)[0][0] == 3
    assert bm.buscar("M1L3", 3, todo)[0][0] == 2                       # un codigo: lo que los embeddings fallan
    solo_cursos = lambda m: m["categoria"] == "Cursos"  # noqa: E731
    assert [i for i, _, _ in bm.buscar("liberacion de lote calidad", 5, solo_cursos)] == []
    assert bm.buscar("agentes virtuales", 5, solo_cursos)[0][0] == 1
    # exigir 2 terminos descarta coincidencias de una sola palabra suelta
    assert bm.buscar("agentes planta", 5, todo, min_terminos=2) == []
    assert bm.buscar("palabrainexistente", 5, todo) == [] and bm.buscar("", 5, todo) == []


def test_fusion_por_rangos():
    assert servicio.fusionar_rangos([1, 2, 3], [3, 4, 1])[:2] == [1, 3]   # los que aparecen en las dos listas suben
    assert servicio.fusionar_rangos([], []) == [] and servicio.fusionar_rangos([5], []) == [5]


def test_union_de_fragmentos_sin_repetir_el_solapamiento():
    a = "Linea uno del procedimiento de limpieza.\nLinea dos con el detalle de los pasos."
    b = "Linea dos con el detalle de los pasos.\nLinea tres con los registros."
    assert servicio._unir(a, b) == "Linea uno del procedimiento de limpieza.\nLinea dos con el detalle de los pasos.\nLinea tres con los registros."
    assert servicio._unir("abc", "xyz") == "abc\nxyz"


# ---------------------------------------------------------------- reordenar con el modelo auxiliar
class ModeloJson:
    def __init__(self, contenido=None, falla=None):
        self.contenido, self.falla, self.visto = contenido, falla, None

    def bind(self, **k):
        return self

    def invoke(self, mensajes):
        self.visto = mensajes
        if self.falla:
            raise self.falla
        return AIMessage(content=self.contenido)


CANDIDATOS = [{"codigo": f"D{i}", "seccion": f"S{i}", "texto": f"texto {i}"} for i in range(5)]


def test_reordenar_deja_los_relevantes_en_orden(monkeypatch):
    m = ModeloJson(json.dumps({"relevantes": [{"i": 3, "puntaje": 9}, {"i": 1, "puntaje": 6}, {"i": 4, "puntaje": 2}, {"i": 99, "puntaje": 9}, {"i": 3, "puntaje": 5}]}))
    monkeypatch.setattr(refinar.llm, "chat_model_aux", lambda: m)
    monkeypatch.setattr(refinar.llm, "con_reintentos", lambda fn: fn())
    r = refinar.reordenar("pregunta", CANDIDATOS, k=5)
    assert "PREGUNTA: pregunta" in m.visto[1].content and "[3] D3 — S3" in m.visto[1].content
    assert [c["codigo"] for c in r] == ["D3", "D1"] and r[0]["puntaje_relevancia"] == 9      # descarta puntaje < 4, indices invalidos y repetidos
    assert refinar.reordenar("p", CANDIDATOS, k=1)[0]["codigo"] == "D3" and len(refinar.reordenar("p", CANDIDATOS, k=1)) == 1


@pytest.mark.parametrize("contenido,falla,esperado", [
    (json.dumps({"relevantes": []}), None, []),                        # ninguno sirve -> sin respaldo
    ("no es json", None, None), (json.dumps({"otra": 1}), None, None), (json.dumps({"relevantes": "x"}), None, None),
    (None, llm.ServicioLLMNoDisponible("caido"), None),                # el modelo falla -> se mantiene el orden original
])
def test_reordenar_ante_fallas_no_rompe(monkeypatch, contenido, falla, esperado):
    monkeypatch.setattr(refinar.llm, "chat_model_aux", lambda: ModeloJson(contenido, falla))
    monkeypatch.setattr(refinar.llm, "con_reintentos", lambda fn: fn())
    assert refinar.reordenar("p", CANDIDATOS, k=3) == esperado


# ---------------------------------------------------------------- buscar (pipeline completo con dobles)
class IndiceFalso:
    def __init__(self, hallazgos):
        self.hallazgos, self.permiso = hallazgos, None

    def buscar(self, vector, k, permitido):
        self.permiso = permitido
        return [(i, s) for i, s in self.hallazgos if permitido({"categoria": "Cursos"}) or True]


@pytest.fixture
def pipeline(monkeypatch):
    frags = {
        10: {"id_fragmento": 10, "id_documento": 1, "orden": 2, "codigo": "M1L2", "titulo": "Agentes", "version": "1", "seccion": "1. Comportamiento", "pagina": 4,
             "texto": "Linea B del fragmento diez.\nLinea C del fragmento diez.", "vigente": True},
        11: {"id_fragmento": 11, "id_documento": 1, "orden": 5, "codigo": "M1L2", "titulo": "Agentes", "version": "1", "seccion": "2. Otro", "pagina": 6,
             "texto": "Contenido del fragmento once.", "vigente": True},
        12: {"id_fragmento": 12, "id_documento": 2, "orden": 1, "codigo": "M1L3", "titulo": "Usos", "version": "1", "seccion": "1. Usos", "pagina": 5,
             "texto": "Solo aparece por palabras exactas usos entornos.", "vigente": True},
        13: {"id_fragmento": 13, "id_documento": 3, "orden": 1, "codigo": "OLD", "titulo": "Vieja", "version": "1", "seccion": None, "pagina": 1,
             "texto": "no vigente", "vigente": False},
    }
    ctx = SimpleNamespace(indice=IndiceFalso([(10, 0.8), (11, 0.4), (13, 0.7)]), reorden=None, pedidos=[])
    monkeypatch.setattr(servicio.llm, "embed_consulta", lambda q: [0.0])
    monkeypatch.setattr(servicio, "obtener_indice", lambda: ctx.indice)
    bm = lexico.BM25([(12, "M1L3 Usos entornos Solo aparece por palabras exactas usos entornos", {"categoria": "Cursos"})])
    monkeypatch.setattr(servicio.lexico, "obtener", lambda cargar: bm)
    monkeypatch.setattr(servicio.repo, "fragmentos_por_ids", lambda ids: [frags[i] for i in ids if i in frags])
    monkeypatch.setattr(servicio.repo, "fragmentos_vecinos", lambda pares: ctx.pedidos.append(pares) or [
        {"id_fragmento": 9, "id_documento": 1, "orden": 1, "texto": "Linea A del fragmento previo.\nLinea B del fragmento diez."},
        {"id_fragmento": 14, "id_documento": 1, "orden": 3, "texto": "Linea C del fragmento diez.\nLinea D del siguiente."}])
    monkeypatch.setattr(servicio, "advertencia_version", lambda c, v: None)
    return ctx


ALCANCE = rbac.Alcance(habilitado=True, todas=True)


def test_buscar_combina_embeddings_y_palabras_y_amplia_con_vecinos(pipeline, monkeypatch):
    monkeypatch.setattr(servicio.refinar, "reordenar", lambda p, c, k: None)          # sin reordenar: orden fusionado
    r = servicio.buscar("usos entornos", ALCANCE, k=5)
    ids = [f["id_fragmento"] for f in r]
    assert 12 in ids and 10 in ids and 11 in ids          # el hallazgo solo-por-palabras entra junto a los de embeddings
    assert 13 not in ids                                  # un fragmento de version no vigente nunca se devuelve
    f10 = next(f for f in r if f["id_fragmento"] == 10)
    assert f10["expandido"] and f10["texto"].count("Linea B del fragmento diez") == 1       # sin repetir el solapamiento
    assert f10["texto"].startswith("Linea A") and f10["texto"].endswith("Linea D del siguiente.")


def test_el_reordenamiento_manda_y_si_ninguno_sirve_no_hay_respaldo(pipeline, monkeypatch):
    monkeypatch.setattr(servicio.refinar, "reordenar", lambda p, c, k: [dict(c[1], puntaje_relevancia=9)])
    r = servicio.buscar("lo que sea", ALCANCE, k=3)
    assert [f["id_fragmento"] for f in r] == [c for c in [r[0]["id_fragmento"]]] and len(r) == 1
    monkeypatch.setattr(servicio.refinar, "reordenar", lambda p, c, k: [])
    assert servicio.buscar("lo que sea", ALCANCE, k=3) == []


def test_sin_candidatos_no_se_llama_al_modelo(pipeline, monkeypatch):
    pipeline.indice.hallazgos = [(10, 0.05)]                    # bajo el umbral de similitud
    monkeypatch.setattr(servicio.lexico, "obtener", lambda cargar: lexico.BM25([]))
    monkeypatch.setattr(servicio.refinar, "reordenar", lambda *a: pytest.fail("no debe llamarse"))
    assert servicio.buscar("algo", ALCANCE) == []


# ---------------------------------------------------------------- resumenes
@pytest.fixture
def resumenes(monkeypatch):
    docs = [
        {"id_documento": 1, "codigo": "M1L2", "titulo": "Comportamiento realista de los agentes virtuales", "version": "1", "categoria": "Cursos", "resumen": None},
        {"id_documento": 2, "codigo": "M1L3", "titulo": "Usos de los entornos virtuales", "version": "1", "categoria": "Cursos", "resumen": "Resumen guardado de M1L3."},
        {"id_documento": 3, "codigo": "SOP-0007", "titulo": "Liberacion de lote", "version": "2", "categoria": "Calidad", "resumen": None},
    ]
    est = SimpleNamespace(guardados={}, llamadas=[])
    monkeypatch.setattr(servicio.repo, "documentos_para_resumen", lambda: [dict(d) for d in docs])
    monkeypatch.setattr(servicio.repo, "texto_de_documento", lambda i: [{"orden": 1, "pagina": 1, "seccion": "1. Intro", "texto": f"Texto del documento {i}."}])
    monkeypatch.setattr(servicio.repo, "guardar_resumen", lambda i, r: est.guardados.update({i: r}))
    monkeypatch.setattr(servicio.refinar, "resumir", lambda t, s, x: est.llamadas.append(t) or f"Resumen nuevo de {t}.")
    return est


def test_resumen_de_los_documentos_nombrados_por_codigo(resumenes):
    cursos = rbac.alcance_documental([{"tipo_recurso": "documento", "recurso": "Cursos", "nivel_acceso": "lectura"}])
    pregunta = "dame un resumen de esto [1] M1L2 v1 — M1L2 — 1. Comportamiento realista (pág. 4)\n[2] M1L3 v1 — M1L3 — 1. Usos de los entornos virtuales (pág. 5)"
    r, total = servicio.resumenes(pregunta, cursos)
    assert [f["codigo"] for f in r] == ["M1L2", "M1L3"] and total == 2
    assert r[0]["texto"].startswith("Resumen nuevo") and r[1]["texto"] == "Resumen guardado de M1L3."      # el que ya estaba no se vuelve a pedir
    assert resumenes.llamadas == ["Comportamiento realista de los agentes virtuales"] and 1 in resumenes.guardados


def test_resumen_general_respeta_el_alcance_y_el_tope(resumenes):
    cursos = rbac.alcance_documental([{"tipo_recurso": "documento", "recurso": "Cursos", "nivel_acceso": "lectura"}])
    r, total = servicio.resumenes("dame un resumen general", cursos)
    assert {f["codigo"] for f in r} == {"M1L2", "M1L3"} and total == 2          # SOP-0007 es de Calidad: no se ve
    todos = rbac.Alcance(habilitado=True, todas=True)
    r, total = servicio.resumenes("dame un resumen general", todos, max_docs=2)
    assert len(r) == 2 and total == 3
    assert servicio.resumenes("x", rbac.Alcance(habilitado=True, categorias=frozenset({"otra"}))) == ([], 0)


def test_si_el_modelo_no_puede_resumir_se_ofrece_el_extracto(resumenes, monkeypatch):
    def falla(*a):
        raise llm.ErrorModelo("sin servicio")
    monkeypatch.setattr(servicio.refinar, "resumir", falla)
    r, _ = servicio.resumenes("resumen de M1L2", rbac.Alcance(habilitado=True, todas=True))
    assert r[0]["seccion"].startswith("Extracto inicial") and "Texto del documento 1." in r[0]["texto"] and resumenes.guardados == {}


# ---------------------------------------------------------------- orquestador: modo resumen
@pytest.mark.parametrize("t,esperado", [
    ("dame un resumen general", True), ("resumime el módulo M1L2", True), ("de qué trata la guía", True), ("qué documentos hay", True),
    ("hacé una síntesis de los SOP", True), ("listame los documentos", True),
    ("cómo se libera un lote", False), ("ventas por cliente", False), ("resultado del procedimiento de limpieza", False),
])
def test_el_texto_del_pedido_decide_el_modo_resumen(t, esperado):
    assert orq.modo_resumen_pedido(t) is esperado


def test_la_herramienta_resume_aunque_el_modelo_pida_buscar(monkeypatch):
    from tests.test_web_y_flujo import CTX, ModeloFalso, llamada
    registro = []
    monkeypatch.setattr(orq.repo, "crear_conversacion", lambda u, t: 11)
    monkeypatch.setattr(orq.repo, "ultimos_mensajes", lambda c, n: [])
    monkeypatch.setattr(orq.repo, "insertar_mensaje", lambda c, e, t, d=None: 1)
    monkeypatch.setattr(orq.repo, "insertar_consulta", lambda c: 1)
    monkeypatch.setattr(orq.repo, "vincular_tablas", lambda *a: None)
    monkeypatch.setattr(orq, "auditar", lambda *a, **k: None)
    monkeypatch.setattr(orq.repo, "permisos_de_roles", lambda i: [{"tipo_recurso": "documento", "recurso": "*", "nivel_acceso": "lectura"}])
    res = [{"id_fragmento": None, "id_documento": 1, "codigo": "M1L2", "titulo": "Agentes", "version": "1", "seccion": "Resumen del documento", "pagina": None,
            "texto": "Resumen de agentes.", "score": None, "advertencia": None}]
    monkeypatch.setattr(orq.servicio_rag, "resumenes", lambda p, a: registro.append("resumen") or (res, 5))
    monkeypatch.setattr(orq.servicio_rag, "buscar", lambda p, a, k=None: registro.append(f"buscar{k}") or [])
    contenidos = []
    class Modelo(ModeloFalso):
        def invoke(self, mensajes):
            contenidos.append(mensajes[-1].content)
            return super().invoke(mensajes)
    monkeypatch.setattr(orq, "_modelo_con_herramientas", lambda: Modelo([llamada("consultar_documentos", pregunta="resumen", modo="buscar"), AIMessage(content="Es sobre agentes [F1].")]))
    r = orq.responder(CTX, "dame un resumen general")
    assert registro == ["resumen", "buscar3"] and r.fuente == "documental" and r.citas[0]["codigo"] == "M1L2"
    assert "RESÚMENES DE DOCUMENTOS" in contenidos[-1] and "se resumen 1" in contenidos[-1]      # avisa que hay mas documentos
    # sin documentos accesibles: mensaje deterministico, no inventa
    monkeypatch.setattr(orq.servicio_rag, "resumenes", lambda p, a: ([], 0))
    monkeypatch.setattr(orq, "_modelo_con_herramientas", lambda: ModeloFalso([llamada("consultar_documentos", pregunta="resumen"), AIMessage(content="x")]))
    assert orq.responder(CTX, "dame un resumen general").texto == orq.MSG_SIN_DOCUMENTOS_PARA_RESUMIR


def test_las_instrucciones_exigen_llamar_a_la_herramienta():
    assert 'modo="resumen"' in orq.SISTEMA and "Nunca digas que no tenés fragmentos" in orq.SISTEMA
    assert "modo" in orq.consultar_documentos.args


# ---------------------------------------------------------------- visor de documentos
@pytest.fixture
def visor(monkeypatch):
    from fastapi.testclient import TestClient

    from app.config import get_settings
    from app.main import app
    from app.web import rutas_docs
    from app.web.deps import exigir_sesion
    from tests.test_web_y_flujo import ADMIN, CTX

    docs_dir = get_settings().docs_dir
    docs_dir.mkdir(parents=True, exist_ok=True)
    (docs_dir / "abc.pdf").write_bytes(b"%PDF-1.4 contenido de prueba")
    docs = {
        ("M1L2", "1"): {"codigo": "M1L2", "version": "1", "categoria": "Cursos", "vigente": True, "archivo": "abc.pdf"},
        ("SOP-9", "1"): {"codigo": "SOP-9", "version": "1", "categoria": "Calidad", "vigente": True, "archivo": "abc.pdf"},
        ("M1L2", "0"): {"codigo": "M1L2", "version": "0", "categoria": "Cursos", "vigente": False, "archivo": "abc.pdf"},
        ("SIN", "1"): {"codigo": "SIN", "version": "1", "categoria": "Cursos", "vigente": True, "archivo": "no_existe.pdf"},
    }
    est = SimpleNamespace(auditoria=[], usuario=CTX)
    monkeypatch.setattr(rutas_docs.repo, "documentos_por_codigo", lambda c: [d for (cc, _), d in docs.items() if cc == c])
    monkeypatch.setattr(rutas_docs.repo, "documento_vigente_por_codigo", lambda c: docs.get((c, "1")))
    monkeypatch.setattr(rutas_docs.repo, "permisos_de_roles", lambda ids: [{"tipo_recurso": "documento", "recurso": "Cursos", "nivel_acceso": "lectura"}])
    monkeypatch.setattr(rutas_docs, "auditar", lambda tipo, res, ctx=None, **k: est.auditoria.append((tipo, res, k.get("detalle"))))
    app.dependency_overrides[exigir_sesion] = lambda: est.usuario
    est.cliente, est.admin = TestClient(app), ADMIN
    yield est
    app.dependency_overrides.clear()


def test_la_cita_abre_el_pdf_en_el_navegador(visor):
    r = visor.cliente.get("/documentos/M1L2/1")
    assert r.status_code == 200 and r.content.startswith(b"%PDF") and r.headers["content-type"] == "application/pdf"
    assert r.headers["content-disposition"] == 'inline; filename="M1L2_v1.pdf"'
    assert r.headers["content-security-policy"] == "frame-ancestors 'none'"          # sin la politica restrictiva que rompe el visor de PDF
    assert visor.auditoria == [("DOC_VISTA", "ok", "M1L2 v1")]


def test_solo_se_abre_lo_que_el_rol_puede_ver(visor):
    r = visor.cliente.get("/documentos/SOP-9/1")                                       # categoria Calidad: fuera de su alcance
    assert r.status_code == 404 and "no tiene acceso" in r.text
    assert visor.cliente.get("/documentos/INEXISTENTE/1").status_code == 404           # misma respuesta que lo prohibido: no se puede sondear
    assert visor.auditoria == []


def test_una_version_no_vigente_no_se_abre_salvo_para_el_administrador(visor):
    r = visor.cliente.get("/documentos/M1L2/0")
    assert r.status_code == 404 and "ya no está vigente" in r.text and "versión vigente es la 1" in r.text
    visor.usuario = visor.admin
    assert visor.cliente.get("/documentos/M1L2/0").status_code == 200
    assert visor.cliente.get("/documentos/SOP-9/1").status_code == 200                # el administrador ve todas las categorias


def test_archivo_faltante_y_sesion_vencida(visor):
    assert "no está disponible" in visor.cliente.get("/documentos/SIN/1").text
    from app.main import app
    from app.web.deps import exigir_sesion
    app.dependency_overrides.pop(exigir_sesion)
    r = visor.cliente.get("/documentos/M1L2/1", follow_redirects=False)                # sin sesion: va al login, no al PDF
    assert r.status_code == 303 and r.headers["location"] == "/login"
