import pytest

from app import admin_servicio as adm
from app import orquestador as orq
from app.security import auth, passwords
from app.security.auth import Contexto

ADMIN = Contexto(2, 1, "Admin", "adm@x.com", None, (4,), ("administracion",), False)


def test_herramientas_del_modelo_tienen_esquema():
    modelo = orq._modelo_con_herramientas()
    nombres = {t["function"]["name"] for t in modelo.kwargs["tools"]}
    assert nombres == {"consultar_documentos", "consultar_datos"}


class FakeRepo:
    def __init__(self):
        self.u = {"id_usuario": 1, "email": "u@x.com", "nombre": "U", "area": "A",
                  "activo": True, "bloqueado": False, "intentos_fallidos": 0, "debe_cambiar_clave": False, "dias_clave": 10,
                  "clave_hash": passwords.hashear("ClaveValida123xy")}
        self.eventos, self.sesiones = [], {}
        self.con_roles = True

    def install(self, mp):
        mp.setattr(auth.repo, "usuario_por_email", lambda e: self.u if e == self.u["email"] else None)
        mp.setattr(auth.repo, "usuario_por_id", lambda i: self.u)
        mp.setattr(auth.repo, "roles_de_usuario", lambda i: [{"id_rol": 3, "codigo": "comercial_todo"}] if self.con_roles else [])
        mp.setattr(auth.repo, "sumar_intento_fallido", self._fallo)
        mp.setattr(auth.repo, "bloquear_usuario", lambda i: self.u.update(bloqueado=True))
        mp.setattr(auth.repo, "reiniciar_intentos", lambda i: self.u.update(intentos_fallidos=0))
        mp.setattr(auth.repo, "crear_sesion", lambda th, i, ip: self.sesiones.update({th: {"id_sesion": 9, "id_usuario": i, "inactivo_s": 0, "edad_s": 0}}))
        mp.setattr(auth.repo, "sesion_por_token", lambda th: self.sesiones.get(th))
        mp.setattr(auth.repo, "tocar_sesion", lambda i: None)
        mp.setattr(auth.repo, "cerrar_sesion", lambda i, m: self.eventos.append(("cierre", m)))
        mp.setattr(auth.repo, "insertar_auditoria", lambda tipo, res, **k: self.eventos.append((tipo, res)))

    def _fallo(self, i):
        self.u["intentos_fallidos"] += 1
        return self.u["intentos_fallidos"]


def test_login_bloqueo_a_los_cinco_intentos(monkeypatch):
    f = FakeRepo(); f.install(monkeypatch)
    for _ in range(4):
        with pytest.raises(auth.ErrorAuth) as e:
            auth.iniciar_sesion("u@x.com", "mala", "1.1.1.1")
        assert str(e.value) == auth.MSG_GENERICO
    with pytest.raises(auth.ErrorAuth) as e:
        auth.iniciar_sesion("u@x.com", "mala", None)
    assert str(e.value) == auth.MSG_BLOQUEADA and f.u["bloqueado"]
    with pytest.raises(auth.ErrorAuth):  # bloqueada: ni con la clave correcta
        auth.iniciar_sesion("u@x.com", "ClaveValida123xy", None)
    assert ("CUENTA_BLOQUEADA", "ok") in f.eventos
    with pytest.raises(auth.ErrorAuth) as e:
        auth.iniciar_sesion("nadie@x.com", "x", None)
    assert str(e.value) == auth.MSG_GENERICO  # no revela si el usuario existe


def test_login_ok_sesion_y_expiracion(monkeypatch):
    f = FakeRepo(); f.install(monkeypatch)
    token, ctx = auth.iniciar_sesion("u@x.com", "ClaveValida123xy", "1.1.1.1")
    assert ctx.rol_codigo == "comercial_todo" and ctx.consulta and not ctx.es_admin and not ctx.requiere_cambio_clave and ("LOGIN_OK", "ok") in f.eventos
    assert auth.contexto_desde_token(token).id_usuario == 1
    th = next(iter(f.sesiones))
    f.sesiones[th]["inactivo_s"] = 31 * 60
    assert auth.contexto_desde_token(token) is None and ("cierre", "inactividad") in f.eventos
    f.sesiones[th].update(inactivo_s=0, edad_s=8 * 3600 + 1)
    assert auth.contexto_desde_token(token) is None and ("cierre", "limite_horas") in f.eventos
    f.sesiones[th].update(edad_s=0)
    f.u["activo"] = False
    assert auth.contexto_desde_token(token) is None
    assert auth.contexto_desde_token(None) is None
    f.u.update(activo=True, dias_clave=91)
    assert auth._clave_vencida(f.u)


def test_cambio_de_clave_no_reutiliza(monkeypatch):
    f = FakeRepo(); f.install(monkeypatch)
    guardadas = []
    monkeypatch.setattr(auth.repo, "ultimas_claves", lambda i, n: [f.u["clave_hash"]])
    monkeypatch.setattr(auth.repo, "guardar_clave", lambda i, h, forzar_cambio: guardadas.append(h))
    _, ctx = auth.iniciar_sesion("u@x.com", "ClaveValida123xy", None)
    assert auth.cambiar_clave(ctx, "mala", "NuevaClave123xyz", "NuevaClave123xyz")
    assert auth.cambiar_clave(ctx, "ClaveValida123xy", "NuevaClave123xyz", "otra")
    assert auth.cambiar_clave(ctx, "ClaveValida123xy", "corta", "corta")
    assert "reutilizar" in auth.cambiar_clave(ctx, "ClaveValida123xy", "ClaveValida123xy", "ClaveValida123xy")[0]
    assert auth.cambiar_clave(ctx, "ClaveValida123xy", "NuevaClave123xyz", "NuevaClave123xyz") == [] and guardadas


def test_importacion_csv_todo_o_nada(monkeypatch):
    guardados = []
    monkeypatch.setattr(adm.repo, "listar_roles", lambda: [{"id_rol": 3, "codigo": "Comercial_Todo"}, {"id_rol": 4, "codigo": "administracion"}])
    monkeypatch.setattr(adm.repo, "guardar_permiso", lambda *a: guardados.append(a))
    monkeypatch.setattr(adm.repo, "quitar_permisos_por_origen", lambda r, o: 2)
    monkeypatch.setattr(adm, "auditar", lambda *a, **k: None)
    bueno = "rol;tipo_recurso;recurso;nivel_acceso;origen\ncomercial_todo;tabla;DWH.Ventas;lectura;power_bi\ncomercial_todo;documento;Comercial;lectura;intranet\n".encode()
    r = adm.importar_permisos_csv(ADMIN, bueno, True)
    assert r == {"importados": 2, "reemplazados": 4} and guardados[0][2] == "dwh.ventas"
    guardados.clear()
    malo = bueno + b"comercial_todo;tabla;sin_punto;lectura;x\nadministracion;tabla;a.b;lectura;x\n"
    with pytest.raises(adm.ErrorAdmin):
        adm.importar_permisos_csv(ADMIN, malo, False)
    assert guardados == []
    with pytest.raises(adm.ErrorAdmin):
        adm.importar_permisos_csv(ADMIN, b"a,b\n1,2\n", False)


def test_validacion_de_permisos():
    assert adm._validar_permiso("documento", "Calidad", "lectura") == "Calidad"
    assert adm._validar_permiso("documento", "*", "lectura") == "*"
    for args in [("documento", "x" * 81, "lectura"), ("documento", "Calidad", "denegado"), ("tabla", "una", "lectura"), ("columna", "a.b", "denegado"), ("tabla", "a.b", "denegado"), ("x", "a.b", "lectura")]:
        with pytest.raises(adm.ErrorAdmin):
            adm._validar_permiso(*args)


def test_roles_libres_y_usuarios_con_varios_roles(monkeypatch):
    creados, eventos = [], []
    monkeypatch.setattr(adm, "auditar", lambda *a, **k: eventos.append(a[0]))
    monkeypatch.setattr(adm.repo, "rol_por_codigo", lambda c: None)
    monkeypatch.setattr(adm.repo, "crear_rol", lambda c, d: creados.append(c) or 9)
    assert adm.crear_rol(ADMIN, "Comercial_ventas_Comercial_contribucion", "x") == 9
    for malo in ["", "con espacio", "a", "administracion", "Administracion", "ñandú"]:
        with pytest.raises(adm.ErrorAdmin):
            adm.crear_rol(ADMIN, malo, None)
    roles = {1: {"id_rol": 1, "codigo": "a", "usuarios": 0}, 2: {"id_rol": 2, "codigo": "b", "usuarios": 3}, 4: {"id_rol": 4, "codigo": "administracion", "usuarios": 1}}
    monkeypatch.setattr(adm.repo, "rol_por_id", lambda i: roles.get(i))
    monkeypatch.setattr(adm.repo, "eliminar_rol", lambda i: eventos.append("borrado"))
    with pytest.raises(adm.ErrorAdmin):
        adm.eliminar_rol(ADMIN, 2)  # tiene usuarios
    with pytest.raises(adm.ErrorAdmin):
        adm.eliminar_rol(ADMIN, 4)  # rol del sistema
    adm.eliminar_rol(ADMIN, 1)
    assert "borrado" in eventos
    monkeypatch.setattr(adm.repo, "usuario_por_email", lambda e: None)
    guardado = {}
    monkeypatch.setattr(adm.repo, "crear_usuario", lambda n, e, a, ids, h: guardado.update(ids=ids) or 5)
    adm.crear_usuario(ADMIN, "Ana", "ana@x.com", "Norte", [1, 2, 1])
    assert guardado["ids"] == [1, 2]
    with pytest.raises(adm.ErrorAdmin):
        adm.crear_usuario(ADMIN, "Ana", "ana@x.com", None, [])
    with pytest.raises(adm.ErrorAdmin):
        adm.crear_usuario(ADMIN, "Ana", "ana@x.com", None, [77])
