from app.security import passwords, rbac


def test_politica_de_claves():
    assert passwords.validar_politica("Corta1a")
    assert passwords.validar_politica("sinmayuscula123456")
    assert passwords.validar_politica("SINMINUSCULA123456")
    assert passwords.validar_politica("SinDigitosAquiAbc")
    assert passwords.validar_politica("ClaveValida123xy") == []


def test_hash_con_sal_y_verificacion():
    a, b = passwords.hashear("ClaveValida123xy"), passwords.hashear("ClaveValida123xy")
    assert a != b and a.startswith("scrypt$")
    assert passwords.verificar("ClaveValida123xy", a)
    assert not passwords.verificar("otra", a)
    assert not passwords.verificar("x", "basura")


def test_temporal_cumple_politica():
    for _ in range(20):
        assert passwords.validar_politica(passwords.generar_temporal()) == []


def P(tipo, recurso, nivel="lectura"):
    return {"tipo_recurso": tipo, "recurso": recurso, "nivel_acceso": nivel}


def test_alcance_documental_por_categorias():
    a = rbac.alcance_documental([P("documento", "Calidad"), P("documento", "Comercial")])
    assert rbac.puede_ver_documento("calidad ", a) and rbac.puede_ver_documento("COMERCIAL", a)
    assert not rbac.puede_ver_documento("Producción", a)
    todas = rbac.alcance_documental([P("documento", "*")])
    assert rbac.puede_ver_documento("Cualquiera", todas)
    assert not rbac.puede_ver_documento("Calidad", rbac.alcance_documental([]))
    assert not rbac.puede_ver_documento("Calidad", rbac.alcance_documental([P("documento", "Calidad", "denegado")]))
    assert rbac.normalizar("  Producción  Planta ") == "produccion planta"


def test_varios_roles_se_suman():
    def R(rol, *a):
        return {**P(*a), "id_rol": rol}
    permisos = [
        R(1, "documento", "Calidad"), R(2, "documento", "Comercial"),
        R(1, "tabla", "dwh.ventas", "lectura_area"), R(1, "columna", "dwh.ventas", "x"),
        R(2, "tabla", "dwh.ventas", "lectura"), R(2, "columna", "dwh.ventas.costo", "denegado"),
        R(1, "columna", "dwh.ventas.monto", "lectura"),
        R(2, "tabla", "dwh.otra", "lectura"),
    ]
    permisos = [p for p in permisos if p["recurso"] != "dwh.ventas" or p["tipo_recurso"] == "tabla"]
    assert rbac.puede_ver_documento("Comercial", rbac.alcance_documental(permisos))
    d = rbac.permisos_datos(permisos, ["dwh.ventas", "dwh.otra"])
    v = d["dwh.ventas"]
    assert not v.por_area  # un rol la da completa y otro por area: gana la completa
    assert v.columna_ok("monto") and v.columna_ok("id")  # el rol 2 deja ver todo salvo costo; el rol 1 solo monto
    assert not v.columna_ok("costo")  # la denegacion del rol 2 no la levanta el rol 1 (que solo lista monto)
    solo_uno = rbac.permisos_datos([R(1, "tabla", "dwh.ventas", "lectura_area")], ["dwh.ventas"])
    assert solo_uno["dwh.ventas"].por_area
    assert "dwh.otra" in d


def test_permisos_datos():
    permisos = [P("tabla", "dwh.ventas", "lectura_area"), P("tabla", "dwh.otra"), P("columna", "dwh.ventas.costo", "denegado")]
    d = rbac.permisos_datos(permisos, ["dwh.ventas"])
    assert list(d) == ["dwh.ventas"] and d["dwh.ventas"].por_area
    assert not d["dwh.ventas"].columna_ok("COSTO") and d["dwh.ventas"].columna_ok("monto")
    lista_blanca = rbac.permisos_datos([P("tabla", "dwh.ventas"), P("columna", "dwh.ventas.monto")], ["dwh.ventas"])
    assert lista_blanca["dwh.ventas"].columna_ok("monto") and not lista_blanca["dwh.ventas"].columna_ok("id")
    assert rbac.permisos_datos([P("tabla", "dwh.ventas", "denegado")], ["dwh.ventas"]) == {}
