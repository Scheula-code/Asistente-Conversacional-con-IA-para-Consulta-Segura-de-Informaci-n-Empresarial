import pytest

from app.datos import validador as v
from app.security.rbac import PermisoTabla

COLS = {
    "dwh.ventas": {"id": "int", "producto": "varchar", "monto": "decimal", "costo": "decimal", "area": "varchar"},
    "dwh.productos": {"id": "int", "nombre": "varchar"},
    "dwh.sueldos": {"id": "int", "sueldo": "decimal"},
}


def perm(**kw):
    base = {
        "dwh.ventas": PermisoTabla("dwh.ventas", False, None, frozenset({"costo"})),
        "dwh.productos": PermisoTabla("dwh.productos", False, None, frozenset()),
    }
    base.update(kw)
    return base


def ok(sql, permisos=None, **kw):
    return v.validar(sql, permisos or perm(), COLS, **kw)


def bloqueada(sql, permisos=None):
    with pytest.raises(v.ConsultaBloqueada):
        v.validar(sql, permisos or perm(), COLS)


def test_select_valido_y_star_expandido_sin_columna_denegada():
    r = ok("SELECT * FROM dwh.ventas")
    assert "costo" not in r.sql.lower() and "monto" in r.sql.lower()
    assert r.tablas == frozenset({"dwh.ventas"})


def test_mayusculas_y_alias_y_cte():
    ok("SELECT V.Producto, SUM(V.Monto) m FROM DWH.VENTAS V JOIN dwh.productos p ON p.id = v.id GROUP BY V.Producto")
    ok("WITH x AS (SELECT producto, monto FROM dwh.ventas) SELECT producto FROM x")
    ok("SELECT producto FROM dwh.ventas UNION ALL SELECT nombre FROM dwh.productos")


def test_tabla_sin_esquema_se_resuelve_si_es_unica():
    assert "dwh" in ok("SELECT nombre FROM productos").sql.lower()


@pytest.mark.parametrize("sql", [
    "DELETE FROM dwh.ventas", "UPDATE dwh.ventas SET monto = 0", "DROP TABLE dwh.ventas", "EXEC sp_who",
    "SELECT 1; DROP TABLE dwh.ventas", "SELECT monto INTO nueva FROM dwh.ventas", "INSERT INTO dwh.ventas (id) VALUES (1)",
    "TRUNCATE TABLE dwh.ventas", "SELECT * FROM OPENQUERY(srv, 'select 1')", "SELECT * FROM srv.bd.dwh.ventas",
    "SELECT * FROM sys.objects", "SELECT * FROM dwh.sueldos",
    "SELECT costo FROM dwh.ventas",
    "SELECT producto FROM dwh.ventas WHERE costo > 10",
    "SELECT producto FROM dwh.ventas v WHERE EXISTS (SELECT 1 FROM dwh.productos p WHERE p.id = v.costo)",
    "SELECT d.costo FROM (SELECT costo FROM dwh.ventas) d",
    "WITH x AS (SELECT costo FROM dwh.ventas) SELECT * FROM x",
    "SELECT monto - costo FROM dwh.ventas",
])
def test_se_bloquea(sql):
    bloqueada(sql)


def test_columna_inexistente_es_invalida_no_bloqueo():
    with pytest.raises(v.ConsultaInvalida):
        ok("SELECT inventada FROM dwh.ventas")
    with pytest.raises(v.ConsultaInvalida):
        ok("SELECT FROM WHERE")
    with pytest.raises(v.ConsultaInvalida):
        ok("")


def test_filtro_por_area_en_todas_las_lecturas():
    permisos = perm(**{"dwh.ventas": PermisoTabla("dwh.ventas", True, None, frozenset({"costo"}))})
    r = v.validar("SELECT producto FROM dwh.ventas WHERE monto > (SELECT AVG(monto) FROM dwh.ventas)", permisos, COLS,
                  {"dwh.ventas": "area"}, "Comercial Norte")
    assert r.sql.lower().count("where [area] = 'comercial norte'") == 2 or r.sql.count("'Comercial Norte'") == 2
    # comilla en el area: no puede romper el literal
    r2 = v.validar("SELECT producto FROM dwh.ventas", permisos, COLS, {"dwh.ventas": "area"}, "X' OR '1'='1")
    assert "X'' OR ''1''=''1" in r2.sql
    with pytest.raises(v.ConsultaBloqueada):
        v.validar("SELECT producto FROM dwh.ventas", permisos, COLS, {"dwh.ventas": "area"}, None)
    with pytest.raises(v.ConsultaBloqueada):
        v.validar("SELECT producto FROM dwh.ventas", permisos, COLS, {}, "Norte")


# ---------------------------------------------------------------- joins y alias (regresion: el modelo ordena por alias)
COLS2 = {
    "demo.fact_ventas": {"id_venta": "int", "periodo": "date", "id_producto": "int", "id_cliente": "int", "unidades": "int", "descuentos": "decimal", "venta_neta": "decimal"},
    "demo.dim_cliente": {"id_cliente": "int", "nombre": "varchar", "tipo_cliente": "varchar"},
    "demo.dim_producto": {"id_producto": "int", "nombre": "varchar"},
}
PERM2 = {k: PermisoTabla(k, False, None, frozenset({"descuentos"} if k == "demo.fact_ventas" else ())) for k in COLS2}
J = "FROM demo.fact_ventas f JOIN demo.dim_cliente c ON c.id_cliente = f.id_cliente"


@pytest.mark.parametrize("sql", [
    f"SELECT c.nombre, SUM(f.unidades) AS total {J} GROUP BY c.nombre ORDER BY total DESC",
    f"SELECT TOP 200 c.nombre, SUM(f.unidades) AS total_unidades {J} GROUP BY c.nombre ORDER BY total_unidades DESC",
    f"SELECT c.nombre, SUM(f.unidades) {J} GROUP BY c.nombre ORDER BY 2 DESC",
    f"SELECT c.nombre, SUM(f.unidades) AS t {J} GROUP BY c.nombre HAVING SUM(f.unidades) > 100 ORDER BY t",
    "SELECT FORMAT(f.periodo, 'yyyy-MM') AS mes, SUM(f.unidades) u FROM demo.fact_ventas f GROUP BY FORMAT(f.periodo, 'yyyy-MM') ORDER BY mes",
    "SELECT c.nombre AS x FROM demo.dim_cliente c UNION ALL SELECT p.nombre FROM demo.dim_producto p ORDER BY x",
    f"SELECT p.nombre, c.tipo_cliente, SUM(f.venta_neta) AS vn {J} JOIN demo.dim_producto p ON p.id_producto = f.id_producto GROUP BY p.nombre, c.tipo_cliente ORDER BY vn DESC",
    "WITH t AS (SELECT id_cliente, SUM(unidades) AS u FROM demo.fact_ventas GROUP BY id_cliente) SELECT c.nombre, t.u FROM t JOIN demo.dim_cliente c ON c.id_cliente = t.id_cliente ORDER BY t.u DESC",
    "SELECT c.nombre, ISNULL(SUM(f.unidades), 0) AS u FROM demo.dim_cliente c LEFT JOIN demo.fact_ventas f ON f.id_cliente = c.id_cliente GROUP BY c.nombre",
])
def test_joins_con_alias_en_order_by_son_validos(sql):
    v.validar(sql, PERM2, COLS2)


@pytest.mark.parametrize("sql", [
    f"SELECT SUM(f.descuentos) AS descuentos {J} ORDER BY descuentos",       # el alias no esconde la columna denegada
    f"SELECT c.nombre {J} ORDER BY f.descuentos",
    f"SELECT c.nombre, f.descuentos {J}",
])
def test_un_alias_no_sirve_para_esquivar_columnas_denegadas(sql):
    with pytest.raises((v.ConsultaBloqueada, v.ConsultaInvalida)):
        v.validar(sql, PERM2, COLS2)


def test_ambiguedad_da_una_pista_util_al_modelo():
    with pytest.raises(v.ConsultaInvalida) as e:
        v.validar(f"SELECT id_cliente {J}", PERM2, COLS2)
    assert "alias" in str(e.value)


@pytest.mark.parametrize("sql", [
    f"SELECT c.nombre AS descuentos {J} WHERE descuentos > 1",
    f"SELECT c.nombre AS descuentos {J} GROUP BY c.nombre HAVING descuentos > 1",
])
def test_alias_igual_a_columna_denegada_no_llega_a_la_columna_real(sql):
    """El validador ejecuta la sentencia reescrita (alias expandido), no la original: la columna denegada no aparece."""
    r = v.validar(sql, PERM2, COLS2)
    assert "[f].[descuentos]" not in r.sql and "[c].[nombre] > 1" in r.sql
