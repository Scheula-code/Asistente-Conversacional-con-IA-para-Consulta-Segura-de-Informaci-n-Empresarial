# Asistente conversacional para consulta segura de información empresarial (prototipo)

Python 3.12 · FastAPI + plantillas Jinja · SQL Server · FAISS · LangChain + API de OpenAI.
Base propia: `TFG_ASISTENTE` en `(localdb)\MSSQLLocalDB`.

## Requisitos
- Windows con **ODBC Driver 18 (o 17) for SQL Server** y SQL Server LocalDB.
- Python 3.12 (con otra versión hay que volver a verificar `requirements.txt`).
- Una API key de OpenAI y salida a internet hacia `api.openai.com`.

## Puesta en marcha (PowerShell, dentro de la carpeta del proyecto)
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env          # editar: OPENAI_API_KEY (el resto ya apunta a LocalDB)

python -m scripts.instalar_base --dwh-demo   # crea TFG_ASISTENTE y, opcional, DWH_DEMO con datos FICTICIOS
# (alternativa sin Python: ejecutar en sqlcmd/SSMS recrear_todo_TFG_ASISTENTE_y_DWH_DEMO.sql)
python -m scripts.crear_admin                # primer usuario con rol de administración

uvicorn app.main:app --host 127.0.0.1 --port 8000     # UN solo proceso: no usar --workers
```
Abrir http://127.0.0.1:8000 e ingresar con el administrador (pide cambiar la clave en el primer ingreso).

## DWH de demostración (datos ficticios)
Esquema `demo`: 30 productos farmacéuticos, 24 clientes (droguerías, cadenas, hospitales, obras sociales, distribuidores), 7 almacenes (3 propios y 4 en consignación en droguerías) y 25 periodos
mensuales (el mes en curso, incompleto a propósito, más 24 cerrados). Tablas de hechos: ventas con descuentos y contribución marginal (1500 filas),
estado de resultados por producto real y presupuesto (1500), stock por almacén (2520) y cuenta corriente (~1260), todas con su periodo.
El P&L real se arma sumando las ventas, así que las cifras coinciden entre tablas. En `datos_prueba/`: `tablas_demo.md` (objetivo y aclaraciones
para cargar cada tabla), `permisos_demo.csv` (dos roles de ejemplo) y `preguntas_demo.jsonl` (para `scripts.evaluar`).

## Flujo de demostración
1. **Administración > Documentos**: subir los PDF de prueba (el código sale del nombre: `SOP-PRUEBA-0001.pdf`), con tipo y **categoría** (por ejemplo `Calidad` o `Comercial`).
   En *Editar* se completan "proceso que replica" y "capacidad que permite validar"; **Exportar registro (CSV)** da la tabla documento por documento.
2. **Administración > Tablas habilitadas**: declarar `demo.FACT_VENTAS`, etc. con su *objetivo* y, si el rol va acotado por área, la columna `area`.
   Ejemplo de aclaración: "contribución marginal = columna contribucion_marginal; venta neta = venta_neta".
3. **Administración > Roles y permisos**: crear roles con el nombre que quieras (`comercial_todo`, `comercial_ventas`, ...) y asignarle a cada uno
   categorías de documentos (o `*` para todas) y tablas (nivel `lectura`, o `lectura_area` para acotar por el área del usuario).
   Para mostrar el bloqueo de columnas: `columna` / `demo.fact_ventas.contribucion_marginal` / `denegado`. También se puede importar un CSV (ver abajo).
4. **Usuarios**: crear usuarios con **uno o varios roles** (la clave temporal se muestra una sola vez). Ve la suma de lo que concede cada rol.
5. Ingresar como cada usuario y preguntar. Los bloqueos y todas las consultas quedan en **Auditoría**.

CSV de permisos (`;` o `,`): `rol,tipo_recurso,recurso,nivel_acceso,origen`, por ejemplo
`comercial_todo,tabla,demo.fact_ventas,lectura,power_bi`. Si una fila es inválida no se importa ninguna.

## Búsqueda documental
Cada pregunta documental sigue este camino: embeddings (significado) y BM25 (palabras exactas, p. ej. códigos como M1L2), cada uno ya filtrado por
los permisos del rol; fusión por rangos; el **modelo auxiliar** reordena y descarta los fragmentos que no sirven (si ninguno sirve, responde que no hay
respaldo); y los mejores se amplían con el fragmento anterior y el siguiente. Los pedidos de resumen, síntesis o "qué documentos hay" usan el modo
resumen: resumen guardado de cada documento (se genera la primera vez que se pide y se recalcula al reindexar).
- `OPENAI_AUX_MODEL` (vacío = usa `OPENAI_MODEL`): conviene un modelo chico (p. ej. `gpt-4o-mini`) para reordenar y resumir.
- `RAG_RERANK=false` desactiva el reordenamiento (una llamada menos por consulta); `RAG_TOP_K` (6) y `RAG_CANDIDATOS` (24) ajustan cuántos fragmentos se usan.
- El índice de palabras vive en memoria y se arma desde los fragmentos vigentes: alcanza para este prototipo; con decenas de miles de documentos
  convendría la búsqueda de texto completo de SQL Server.
- Base ya creada: ejecutar `scripts/sql/06_migracion_resumen.sql` (agrega `DOCUMENTO.resumen`).

## SQL: solo en la consola
El SQL que genera y ejecuta el asistente **no se muestra al usuario**: ni en la pantalla, ni en el historial, ni en el Excel. Se escribe en la consola de
`uvicorn` (SQL generado, SQL validado que se ejecuta con las restricciones del rol, filas y tiempo; y el motivo cuando una consulta se bloquea) y queda en la
Auditoría, que solo ve el rol de administración. `MOSTRAR_SQL=true` en el `.env` lo vuelve a mostrar (útil solo para desarrollo).

## Ver el documento citado
Cada cita de la respuesta es un vínculo que abre el PDF original en una pestaña nueva, en la página citada (el visor del navegador usa `#page=N`).
Se aplica el mismo alcance por categorías que a la búsqueda; el administrador ve todos; un usuario común no puede abrir una versión que ya no está vigente.
Cada apertura queda en la auditoría (evento `DOC_VISTA`). En Administración > Documentos el código también abre el PDF.

## Descarga a Excel
Cada resultado de datos tiene un vínculo «Descargar Excel»: hoja Resultado (tabla con filtros), hoja Gráfico (el que se pidió, como gráfico nativo de Excel) y hoja Consulta
(pregunta, usuario, SQL ejecutado, resumen y proyección). Solo se pueden bajar resultados de las propias conversaciones y queda registrado en la auditoría.

## Evaluación (objetivos 1, 2 y 4)
`python -m scripts.evaluar --usuario correo@dominio --preguntas datos_prueba/preguntas_demo.jsonl --salida resultados.csv`
Mide tiempo y estado de cada pregunta y deja la respuesta, las citas y el SQL para que el referente las compare con la respuesta de referencia.
El `.jsonl` de ejemplo usa solo el DWH demo.

## Pruebas automáticas
`pytest -q tests` (51 pruebas, sin SQL Server ni OpenAI: usan dobles). Cubren política de claves, bloqueo y sesiones,
RBAC, el validador de SQL (escrituras, columnas ocultas, subconsultas, filtro por área), la proyección, la fragmentación de PDF,
el filtro previo del índice y el orquestador.

## Límites de este entorno (LocalDB, `DB_TRUSTED=yes`)
- Se usa autenticación de Windows. No se crean `asistente_app` ni `asistente_dwh_ro`, así que **no existe el candado a nivel motor**:
  ni "auditoría solo de inserción" (`DENY UPDATE, DELETE`) ni "usuario de solo lectura" sobre el DWH. Lo único que impide escrituras
  es el validador de la aplicación. Con un SQL Server real: `DB_TRUSTED=no`, y el DBA corre `05_usuario_dwh_solo_lectura.sql`.
- Los scripts SQL no se ejecutaron contra SQL Server al escribirlos; solo se revisó su sintaxis con un analizador. Si falla algún
  lote, `instalar_base` muestra el error: corregirlo en `scripts/sql/` y volver a correr (son idempotentes).
- Autenticación con padrón propio de usuarios (no el directorio corporativo). Sin límite de intentos por IP: solo el bloqueo de cuenta.
- El umbral de similitud (`RAG_SCORE_MINIMO=0.30`) y el fragmentado (1200/200 caracteres) son valores iniciales: calibrarlos con las
  preguntas de prueba antes de medir.
- Un solo proceso: el índice vectorial vive en memoria. Reiniciar el servicio recarga el índice guardado en `data/indice`.
- No hay OCR: los PDF escaneados sin texto se rechazan al subirlos.
- Los datos viajan a OpenAI: fragmentos de documentos y filas de resultados. Requiere la autorización que menciona el documento.

## Estructura
`app/` aplicación (`security/`, `rag/`, `datos/`, `web/`) · `scripts/` instalación y utilitarios (`sql/` los scripts T-SQL) ·
`tests/` · `datos_prueba/` · `data/` PDF e índice (no versionar).
