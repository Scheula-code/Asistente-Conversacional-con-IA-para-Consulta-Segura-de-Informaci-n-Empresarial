"""Crea el primer usuario con rol de administracion.   python -m scripts.crear_admin"""
from __future__ import annotations

import getpass
import sys

from app import repo
from app.security import passwords


def main() -> int:
    rol = repo.rol_por_codigo("administracion")
    if not rol:
        print("No existe el rol 'administracion': ejecute antes scripts.instalar_base")
        return 1
    nombre = input("Nombre y apellido: ").strip()
    email = input("Correo: ").strip().lower()
    if repo.usuario_por_email(email):
        print("Ya existe un usuario con ese correo.")
        return 1
    clave = getpass.getpass("Contraseña inicial: ")
    errores = passwords.validar_politica(clave)
    if errores:
        print("\n".join(errores))
        return 1
    if getpass.getpass("Repetir: ") != clave:
        print("No coinciden.")
        return 1
    repo.crear_usuario(nombre, email, None, [rol["id_rol"]], passwords.hashear(clave))
    print("Usuario creado. En el primer ingreso se le pedirá cambiar la contraseña.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
