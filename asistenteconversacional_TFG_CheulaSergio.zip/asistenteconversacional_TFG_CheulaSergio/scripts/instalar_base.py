"""Crea la base propia (y, opcionalmente, el DWH demo) ejecutando los scripts de scripts/sql.

  python -m scripts.instalar_base                 base propia
  python -m scripts.instalar_base --dwh-demo      ademas el datawarehouse de demostracion (datos ficticios)

Con DB_TRUSTED=yes (LocalDB) usa la autenticacion de Windows y NO crea logins ni DENY: ver README.
Sin DB_TRUSTED necesita un usuario con permisos de administrador: INSTALL_USER / INSTALL_PASSWORD.
"""
from __future__ import annotations

import argparse
import getpass
import os
import re
import sys
from pathlib import Path

import pyodbc

from app.config import get_settings

SQL_DIR = Path(__file__).parent / "sql"


def lotes(texto: str) -> list[str]:
    return [b.strip() for b in re.split(r"^\s*GO\s*$", texto, flags=re.IGNORECASE | re.MULTILINE) if b.strip()]


def conectar_master():
    s = get_settings()
    base = f"DRIVER={{{s.odbc_driver}}};SERVER={s.app_db_server};DATABASE=master;TrustServerCertificate={s.db_trust_cert}"
    if s.db_trusted:
        return pyodbc.connect(base + ";Trusted_Connection=yes", autocommit=True)
    usuario = os.environ.get("INSTALL_USER") or input("Usuario administrador de SQL Server: ")
    clave = os.environ.get("INSTALL_PASSWORD") or getpass.getpass("Clave: ")
    return pyodbc.connect(f"{base};UID={usuario};PWD={clave}", autocommit=True)


def ejecutar_script(conn, archivo: str, variables: dict[str, str], omitir_logins: bool) -> None:
    texto = (SQL_DIR / archivo).read_text(encoding="utf-8")
    for k, v in variables.items():
        texto = texto.replace(f"$({k})", v)
    cur = conn.cursor()
    print(f"== {archivo}")
    for i, lote in enumerate(lotes(texto), start=1):
        if omitir_logins and re.search(r"asistente_app|asistente_dwh_ro", lote):
            print(f"   lote {i}: omitido (logins/permisos: no aplica con autenticacion de Windows)")
            continue
        cur.execute(lote)
        while cur.nextset():
            pass


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dwh-demo", action="store_true", help="instala tambien el datawarehouse de demostracion")
    args = ap.parse_args()
    s = get_settings()
    variables = {
        "APP_DB": s.app_db_name, "APP_PASSWORD": s.app_db_password, "DEMO_DB": s.dwh_name or "DWH_DEMO",
        "DWH_PASSWORD": s.dwh_password,
    }
    conn = conectar_master()
    try:
        for archivo in ("01_crear_base_y_login.sql", "02_tablas.sql", "03_permisos_app.sql", "04_datos_iniciales.sql"):
            ejecutar_script(conn, archivo, variables, s.db_trusted)
        if args.dwh_demo:
            ejecutar_script(conn, "90_dwh_demo_opcional.sql", variables, s.db_trusted)
    finally:
        conn.close()
    print("\nListo. Siguiente paso: python -m scripts.crear_admin")
    return 0


if __name__ == "__main__":
    sys.exit(main())
