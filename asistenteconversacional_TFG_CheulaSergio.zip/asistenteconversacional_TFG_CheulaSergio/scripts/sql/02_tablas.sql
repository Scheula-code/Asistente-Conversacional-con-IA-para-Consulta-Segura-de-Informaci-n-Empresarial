/* ============================================================================
   02 - Tablas de la base propia del prototipo (Figura 4 y Tabla 12 del TFG).
   Idempotente: puede ejecutarse mas de una vez.
   Las columnas marcadas "EXTRA" no estan en el diccionario de datos original y
   existen porque la implementacion las necesita (ver CAMBIOS_AL_DOCUMENTO.md).
   Los textos libres son nvarchar (y no varchar) para no perder simbolos habituales
   en documentacion farmaceutica: micro, grados, mayor o igual, etc.
   ============================================================================ */

/* ---------------------------- ROL ---------------------------------------- */
IF OBJECT_ID(N'dbo.ROL') IS NULL
CREATE TABLE dbo.ROL (
    id_rol       int          IDENTITY(1,1) CONSTRAINT PK_ROL PRIMARY KEY,
    codigo       varchar(60)  NOT NULL CONSTRAINT UQ_ROL_codigo UNIQUE,        -- EXTRA: nombre del rol, libre (ej. comercial_todo). 'administracion' es el unico rol del sistema
    descripcion  nvarchar(300) NULL
);
GO

/* ---------------------------- USUARIO ------------------------------------ */
IF OBJECT_ID(N'dbo.USUARIO') IS NULL
CREATE TABLE dbo.USUARIO (
    id_usuario         int           IDENTITY(1,1) CONSTRAINT PK_USUARIO PRIMARY KEY,
    nombre             nvarchar(100) NOT NULL,
    email              varchar(120)  NOT NULL CONSTRAINT UQ_USUARIO_email UNIQUE,
    area               nvarchar(80)  NULL,
    activo             bit           NOT NULL CONSTRAINT DF_USUARIO_activo DEFAULT 1,
    clave_hash         varchar(255)  NOT NULL,                                  -- EXTRA: scrypt con sal por usuario, nunca texto plano
    fecha_clave        datetime2(0)  NOT NULL CONSTRAINT DF_USUARIO_fclave DEFAULT SYSUTCDATETIME(),  -- EXTRA: para el vencimiento a 90 dias
    intentos_fallidos  int           NOT NULL CONSTRAINT DF_USUARIO_int DEFAULT 0,                   -- EXTRA
    bloqueado          bit           NOT NULL CONSTRAINT DF_USUARIO_bloq DEFAULT 0,                  -- EXTRA: solo el administrador lo habilita
    debe_cambiar_clave bit           NOT NULL CONSTRAINT DF_USUARIO_dcc DEFAULT 1,                   -- EXTRA
    fecha_alta         datetime2(0)  NOT NULL CONSTRAINT DF_USUARIO_falta DEFAULT SYSUTCDATETIME()   -- EXTRA
);
GO

/* ---------------------------- USUARIO_ROL (EXTRA) ------------------------ */
/* Un usuario puede tener varios roles: lo que puede ver es la union de lo que concede cada uno. */
IF OBJECT_ID(N'dbo.USUARIO_ROL') IS NULL
CREATE TABLE dbo.USUARIO_ROL (
    id_usuario int NOT NULL CONSTRAINT FK_UR_USUARIO REFERENCES dbo.USUARIO(id_usuario),
    id_rol     int NOT NULL CONSTRAINT FK_UR_ROL     REFERENCES dbo.ROL(id_rol),
    CONSTRAINT PK_USUARIO_ROL PRIMARY KEY (id_usuario, id_rol)
);
GO

/* ---------------------------- HISTORIAL_CLAVE (EXTRA) -------------------- */
IF OBJECT_ID(N'dbo.HISTORIAL_CLAVE') IS NULL
CREATE TABLE dbo.HISTORIAL_CLAVE (
    id_historial  int          IDENTITY(1,1) CONSTRAINT PK_HISTORIAL_CLAVE PRIMARY KEY,
    id_usuario    int          NOT NULL CONSTRAINT FK_HCLAVE_USUARIO REFERENCES dbo.USUARIO(id_usuario),
    clave_hash    varchar(255) NOT NULL,
    fecha         datetime2(0) NOT NULL CONSTRAINT DF_HCLAVE_fecha DEFAULT SYSUTCDATETIME()
);
GO

/* ---------------------------- SESION (EXTRA) ----------------------------- */
IF OBJECT_ID(N'dbo.SESION') IS NULL
CREATE TABLE dbo.SESION (
    id_sesion         bigint       IDENTITY(1,1) CONSTRAINT PK_SESION PRIMARY KEY,
    token_hash        char(64)     NOT NULL CONSTRAINT UQ_SESION_token UNIQUE,   -- SHA-256 del token de la cookie
    id_usuario        int          NOT NULL CONSTRAINT FK_SESION_USUARIO REFERENCES dbo.USUARIO(id_usuario),
    inicio            datetime2(0) NOT NULL CONSTRAINT DF_SESION_inicio DEFAULT SYSUTCDATETIME(),
    ultima_actividad  datetime2(0) NOT NULL CONSTRAINT DF_SESION_ult DEFAULT SYSUTCDATETIME(),
    activa            bit          NOT NULL CONSTRAINT DF_SESION_activa DEFAULT 1,
    motivo_cierre     varchar(30)  NULL,
    ip                varchar(45)  NULL
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SESION_usuario' AND object_id = OBJECT_ID(N'dbo.SESION'))
    CREATE INDEX IX_SESION_usuario ON dbo.SESION (id_usuario, activa);
GO

/* ---------------------------- PERMISO ------------------------------------ */
/* tipo_recurso 'documento': recurso = '*' (todas las categorias) | '<categoria>' (ej. Calidad, Comercial)
   tipo_recurso 'tabla'    : recurso = 'esquema.tabla'
   tipo_recurso 'columna'  : recurso = 'esquema.tabla.columna'
   nivel_acceso            : 'lectura' | 'lectura_area' (solo tablas: filtra los registros por el area del usuario)
                             | 'denegado' (solo columnas)                                                          */
IF OBJECT_ID(N'dbo.PERMISO') IS NULL
CREATE TABLE dbo.PERMISO (
    id_permiso    int          IDENTITY(1,1) CONSTRAINT PK_PERMISO PRIMARY KEY,
    id_rol        int          NOT NULL CONSTRAINT FK_PERMISO_ROL REFERENCES dbo.ROL(id_rol),
    tipo_recurso  varchar(20)  NOT NULL CONSTRAINT CK_PERMISO_tipo CHECK (tipo_recurso IN ('documento','tabla','columna')),
    recurso       nvarchar(120) NOT NULL,
    nivel_acceso  varchar(20)  NOT NULL CONSTRAINT CK_PERMISO_nivel CHECK (nivel_acceso IN ('lectura','lectura_area','denegado')),
    origen        varchar(40)  NOT NULL CONSTRAINT DF_PERMISO_origen DEFAULT 'manual',   -- EXTRA: de que permiso vigente proviene (HU-015)
    CONSTRAINT UQ_PERMISO UNIQUE (id_rol, tipo_recurso, recurso)
);
GO

/* ---------------------------- DOCUMENTO ---------------------------------- */
IF OBJECT_ID(N'dbo.DOCUMENTO') IS NULL
CREATE TABLE dbo.DOCUMENTO (
    id_documento       int           IDENTITY(1,1) CONSTRAINT PK_DOCUMENTO PRIMARY KEY,
    codigo             varchar(30)   NOT NULL,
    titulo             nvarchar(200) NOT NULL,
    tipo               varchar(25)   NOT NULL CONSTRAINT CK_DOC_tipo CHECK (tipo IN ('SOP','PROCESO','GUIA')),
    version            varchar(10)   NOT NULL,
    vigente            bit           NOT NULL CONSTRAINT DF_DOC_vigente DEFAULT 1,
    categoria          nvarchar(80)  NOT NULL,                                -- grupo de documentos al que se asignan permisos (reemplaza area propietaria y nivel de acceso)
    archivo            varchar(260)  NOT NULL,                                -- EXTRA: nombre del PDF guardado en DATA_DIR/documentos
    nombre_original    nvarchar(260) NULL,                                    -- EXTRA
    hash_archivo       char(64)      NOT NULL,                                -- EXTRA: SHA-256 del PDF
    paginas            int           NULL,                                    -- EXTRA
    indexado           bit           NOT NULL CONSTRAINT DF_DOC_indexado DEFAULT 0,   -- EXTRA
    fecha_alta         datetime2(0)  NOT NULL CONSTRAINT DF_DOC_falta DEFAULT SYSUTCDATETIME(),  -- EXTRA
    fecha_indexacion   datetime2(0)  NULL,                                    -- EXTRA
    id_usuario_alta    int           NULL CONSTRAINT FK_DOC_USUARIO REFERENCES dbo.USUARIO(id_usuario),  -- EXTRA
    error_indexacion   nvarchar(500) NULL,                                    -- EXTRA
    proceso_replicado  nvarchar(150) NULL,                                    -- EXTRA: registro del conjunto de validacion (consigna C17)
    capacidad_validada nvarchar(200) NULL,                                    -- EXTRA: idem
    resumen            nvarchar(max) NULL,                                    -- EXTRA: resumen generado por el modelo; se calcula la primera vez que se pide y se borra al reindexar
    CONSTRAINT UQ_DOC_codigo_version UNIQUE (codigo, version)
);
GO

/* ---------------------------- FRAGMENTO ---------------------------------- */
IF OBJECT_ID(N'dbo.FRAGMENTO') IS NULL
CREATE TABLE dbo.FRAGMENTO (
    id_fragmento  bigint        IDENTITY(1,1) CONSTRAINT PK_FRAGMENTO PRIMARY KEY,
    id_documento  int           NOT NULL CONSTRAINT FK_FRAG_DOC REFERENCES dbo.DOCUMENTO(id_documento) ON DELETE CASCADE,
    orden         int           NOT NULL,
    pagina        int           NULL,                      -- EXTRA: para citar la pagina de origen
    seccion       nvarchar(200) NULL,                      -- EXTRA: para citar la seccion de origen (HU-003)
    texto         nvarchar(4000) NOT NULL,
    id_vector     varchar(40)   NULL,                      -- identificador del vector en FAISS (= id_fragmento)
    CONSTRAINT UQ_FRAG_orden UNIQUE (id_documento, orden)
);
GO

/* ---------------------------- TABLA_HABILITADA --------------------------- */
IF OBJECT_ID(N'dbo.TABLA_HABILITADA') IS NULL
CREATE TABLE dbo.TABLA_HABILITADA (
    id_tabla         int           IDENTITY(1,1) CONSTRAINT PK_TABLA_HAB PRIMARY KEY,
    esquema          varchar(40)   NOT NULL,
    nombre_tabla     varchar(120)  NOT NULL,
    objetivo         nvarchar(500) NOT NULL,
    aclaraciones     nvarchar(1000) NULL,
    filtro_registros varchar(120)  NULL,                   -- EXTRA: columna del DWH con el area, para acotar registros (nivel 'lectura_area')
    activa           bit           NOT NULL CONSTRAINT DF_TABHAB_activa DEFAULT 1,
    CONSTRAINT UQ_TABHAB UNIQUE (esquema, nombre_tabla)
);
GO

/* ---------------------------- CONVERSACION / MENSAJE --------------------- */
IF OBJECT_ID(N'dbo.CONVERSACION') IS NULL
CREATE TABLE dbo.CONVERSACION (
    id_conversacion int           IDENTITY(1,1) CONSTRAINT PK_CONVERSACION PRIMARY KEY,
    id_usuario      int           NOT NULL CONSTRAINT FK_CONV_USUARIO REFERENCES dbo.USUARIO(id_usuario),
    titulo          nvarchar(150) NOT NULL,
    fecha_inicio    datetime2(0)  NOT NULL CONSTRAINT DF_CONV_fecha DEFAULT SYSUTCDATETIME()
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_CONV_usuario' AND object_id = OBJECT_ID(N'dbo.CONVERSACION'))
    CREATE INDEX IX_CONV_usuario ON dbo.CONVERSACION (id_usuario, fecha_inicio DESC);
GO

IF OBJECT_ID(N'dbo.MENSAJE') IS NULL
CREATE TABLE dbo.MENSAJE (
    id_mensaje      bigint        IDENTITY(1,1) CONSTRAINT PK_MENSAJE PRIMARY KEY,
    id_conversacion int           NOT NULL CONSTRAINT FK_MSG_CONV REFERENCES dbo.CONVERSACION(id_conversacion) ON DELETE CASCADE,
    emisor          varchar(15)   NOT NULL CONSTRAINT CK_MSG_emisor CHECK (emisor IN ('usuario','asistente')),
    texto           nvarchar(max) NOT NULL,
    fecha           datetime2(0)  NOT NULL CONSTRAINT DF_MSG_fecha DEFAULT SYSUTCDATETIME(),
    detalle_json    nvarchar(max) NULL                      -- EXTRA: citas y tabla de resultados para volver a mostrar el historial
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_MSG_conv' AND object_id = OBJECT_ID(N'dbo.MENSAJE'))
    CREATE INDEX IX_MSG_conv ON dbo.MENSAJE (id_conversacion, id_mensaje);
GO

/* ---------------------------- CONSULTA / CONSULTA_TABLA ------------------ */
IF OBJECT_ID(N'dbo.CONSULTA') IS NULL
CREATE TABLE dbo.CONSULTA (
    id_consulta   bigint        IDENTITY(1,1) CONSTRAINT PK_CONSULTA PRIMARY KEY,
    id_mensaje    bigint        NOT NULL CONSTRAINT FK_CONS_MSG REFERENCES dbo.MENSAJE(id_mensaje) ON DELETE CASCADE,
    tipo          varchar(15)   NOT NULL CONSTRAINT CK_CONS_tipo CHECK (tipo IN ('documental','datos','conversacional')),
    herramienta   varchar(30)   NULL,
    sql_generado  nvarchar(max) NULL,
    sql_ejecutado nvarchar(max) NULL,                       -- EXTRA: la sentencia efectivamente enviada (ya validada y con filtros por rol)
    estado        varchar(20)   NOT NULL CONSTRAINT CK_CONS_estado CHECK (estado IN ('ejecutada','rechazada','con_error','error_modelo')),
    duracion_ms   int           NULL,                       -- EXTRA: tiempo de respuesta, indicador del objetivo especifico 4
    filas         int           NULL                        -- EXTRA
);
GO

IF OBJECT_ID(N'dbo.CONSULTA_TABLA') IS NULL
CREATE TABLE dbo.CONSULTA_TABLA (                          -- resuelve la relacion N:M CONSULTA - TABLA_HABILITADA
    id_consulta bigint NOT NULL CONSTRAINT FK_CT_CONS  REFERENCES dbo.CONSULTA(id_consulta) ON DELETE CASCADE,
    id_tabla    int    NOT NULL CONSTRAINT FK_CT_TABLA REFERENCES dbo.TABLA_HABILITADA(id_tabla),
    CONSTRAINT PK_CONSULTA_TABLA PRIMARY KEY (id_consulta, id_tabla)
);
GO

/* ---------------------------- AUDITORIA ---------------------------------- */
/* Registra consultas Y eventos de acceso (inicio/cierre de sesion, intentos fallidos, bloqueos de cuenta,
   cambios de roles y permisos, altas y bajas de documentos). Por eso id_consulta e id_usuario admiten NULL. */
IF OBJECT_ID(N'dbo.AUDITORIA') IS NULL
CREATE TABLE dbo.AUDITORIA (
    id_auditoria   bigint        IDENTITY(1,1) CONSTRAINT PK_AUDITORIA PRIMARY KEY,
    id_consulta    bigint        NULL CONSTRAINT FK_AUD_CONS REFERENCES dbo.CONSULTA(id_consulta),
    id_usuario     int           NULL,                      -- sin FK a proposito: el registro sobrevive a la baja del usuario
    usuario_ref    varchar(120)  NULL,                      -- EXTRA: correo informado (sirve para intentos con usuarios inexistentes)
    rol            varchar(200)  NULL,                      -- EXTRA: roles con los que actuaba
    tipo_evento    varchar(30)   NOT NULL,                  -- EXTRA: CONSULTA, BLOQUEO, LOGIN_OK, LOGIN_FALLIDO, ...
    fecha          datetime2(0)  NOT NULL CONSTRAINT DF_AUD_fecha DEFAULT SYSUTCDATETIME(),
    resultado      varchar(20)   NOT NULL,                  -- respondida | bloqueada | ok | error
    motivo_bloqueo nvarchar(200) NULL,
    detalle        nvarchar(500) NULL,                      -- EXTRA
    ip             varchar(45)   NULL                       -- EXTRA
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AUD_fecha' AND object_id = OBJECT_ID(N'dbo.AUDITORIA'))
    CREATE INDEX IX_AUD_fecha ON dbo.AUDITORIA (fecha DESC, tipo_evento);
GO
