/* ============================================================================
   04 - Datos iniciales. Idempotente.
   Solo se crea el rol de sistema 'administracion'. Los demas roles (por ejemplo comercial_todo) los define el
   administrador desde Administracion > Roles y permisos, y les asigna categorias de documentos y tablas.
   El usuario administrador inicial se crea con:  python -m scripts.crear_admin
   ============================================================================ */
INSERT INTO dbo.ROL (codigo, descripcion)
SELECT 'administracion', N'Rol del sistema, reservado a Sistemas. Administra usuarios, roles, tablas habilitadas y documentos, y revisa la auditoria. No consulta informacion de negocio.'
WHERE NOT EXISTS (SELECT 1 FROM dbo.ROL WHERE codigo = 'administracion');
GO
