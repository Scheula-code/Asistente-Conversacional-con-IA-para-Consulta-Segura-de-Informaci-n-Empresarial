/* ============================================================================
   05 - Usuario de SOLO LECTURA sobre el datawarehouse (HU-011).
   Lo ejecuta el DBA del datawarehouse, NO se corre desde el instalador.

   Se recomienda conceder SELECT solo sobre los esquemas que se habiliten, en lugar de
   db_datareader sobre toda la base. Reemplazar <ESQUEMA> por cada esquema habilitado.
   ============================================================================ */

USE [master];
GO
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'asistente_dwh_ro')
    CREATE LOGIN [asistente_dwh_ro] WITH PASSWORD = N'<CAMBIAR>', CHECK_POLICY = ON;
GO

USE [<NOMBRE_DEL_DWH>];
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'asistente_dwh_ro')
    CREATE USER [asistente_dwh_ro] FOR LOGIN [asistente_dwh_ro];
GO

-- Un GRANT por esquema habilitado:
GRANT SELECT ON SCHEMA::[<ESQUEMA>] TO [asistente_dwh_ro];
GO

-- Imprescindible para que el asistente pueda leer columnas, tipos y relaciones (lectura del esquema):
GRANT VIEW DEFINITION ON SCHEMA::[<ESQUEMA>] TO [asistente_dwh_ro];
GO

-- Verificacion: no debe tener ningun permiso de escritura.
-- SELECT * FROM sys.fn_my_permissions(NULL, 'DATABASE');   (ejecutar como asistente_dwh_ro)
