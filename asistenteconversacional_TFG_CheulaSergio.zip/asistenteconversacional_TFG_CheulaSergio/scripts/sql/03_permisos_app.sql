/* ============================================================================
   03 - Permisos del login de la aplicacion sobre la base propia.
   La auditoria es solo de insercion: la aplicacion puede agregar y leer registros,
   pero NO modificarlos ni borrarlos (DENY prevalece sobre GRANT).
   La depuracion a los 12 meses de retencion la hace un trabajo del DBA con otro usuario.
   ============================================================================ */
GRANT SELECT, INSERT, UPDATE, DELETE ON SCHEMA::dbo TO [asistente_app];
GO
DENY UPDATE, DELETE ON dbo.AUDITORIA TO [asistente_app];
GO
