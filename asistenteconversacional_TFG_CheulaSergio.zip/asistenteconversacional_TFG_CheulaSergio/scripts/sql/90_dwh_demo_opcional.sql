/* ============================================================================
   90 - DATAWAREHOUSE DE DEMOSTRACION (OPCIONAL) - datos 100 % FICTICIOS.
   Simula un laboratorio farmaceutico: 30 productos, 24 clientes, 7 almacenes, ventas
   mensuales, contribucion marginal, P&L por producto (real y presupuesto), stock por almacen (propios y en
   consignacion en droguerias) y cuenta corriente. NO representa el modelo real del datawarehouse de la organizacion.
   Los productos usan nombres genericos de principios activos; precios, clientes y cifras son inventados.

   Todas las tablas de hechos llevan el periodo (primer dia del mes) y se relacionan con demo.DIM_PERIODO.
   Hay 25 periodos: el mes en curso (INCOMPLETO a proposito) y 24 meses cerrados. Las fechas se calculan
   desde el dia de ejecucion, por lo que la serie siempre termina en el mes actual.

   Filas generadas (exactas salvo las marcadas con ~):
     DIM_PERIODO 25 | DIM_PRODUCTO 30 | DIM_CLIENTE 24 | DIM_ALMACEN 7 | COSTO_UNITARIO 750
     FACT_VENTAS 1500 (25 meses x 30 productos x 2 clientes) | FACT_PYL_PRODUCTO 1500 (750 real + 750 presupuesto)
     FACT_STOCK_ALMACEN 2520 (7 almacenes x 30 productos x 12 cierres) | FACT_CUENTA_CORRIENTE ~1260 (varia con el dia de ejecucion)

   Relacion entre tablas: FACT_PYL_PRODUCTO (escenario Real) se arma sumando FACT_VENTAS, por lo que
   venta neta, costo y contribucion marginal COINCIDEN entre ambas. FACT_VENTAS no trae costos;
   COSTO_UNITARIO existe para mostrar que un rol puede quedar sin acceso a ellos.

   Se reconstruyen las tablas cada vez que se ejecuta (permite refrescar las fechas).
   El archivo es solo ASCII (sin tildes) para que sqlcmd lo lea igual con cualquier pagina de codigos.
   Se instala con:  python -m scripts.instalar_base --dwh-demo      Variable de sqlcmd: $(DEMO_DB)
   ============================================================================ */

IF DB_ID(N'$(DEMO_DB)') IS NULL
    CREATE DATABASE [$(DEMO_DB)] COLLATE Latin1_General_CI_AS;
GO
USE [$(DEMO_DB)];
GO
IF SCHEMA_ID(N'demo') IS NULL EXEC(N'CREATE SCHEMA demo');
GO

DROP TABLE IF EXISTS demo.FACT_PYL_PRODUCTO;
DROP TABLE IF EXISTS demo.FACT_STOCK_ALMACEN;
DROP TABLE IF EXISTS demo.FACT_STOCK_CONSIGNACION;   -- version anterior del modelo (stock por cliente)
DROP TABLE IF EXISTS demo.FACT_CUENTA_CORRIENTE;
DROP TABLE IF EXISTS demo.FACT_VENTAS;
DROP TABLE IF EXISTS demo.COSTO_UNITARIO;
DROP TABLE IF EXISTS demo.DIM_ALMACEN;
DROP TABLE IF EXISTS demo.DIM_CLIENTE;
DROP TABLE IF EXISTS demo.DIM_PRODUCTO;
DROP TABLE IF EXISTS demo.DIM_PERIODO;
GO

/* ------------------------------ dimensiones ----------------------------- */
CREATE TABLE demo.DIM_PERIODO (
    periodo         date        NOT NULL CONSTRAINT PK_DEMO_PERIODO PRIMARY KEY,   -- primer dia del mes
    anio            int         NOT NULL,
    mes             int         NOT NULL,
    trimestre       int         NOT NULL,
    nombre_mes      varchar(12) NOT NULL,
    es_mes_cerrado  bit         NOT NULL,       -- 0 = mes en curso (incompleto)
    meses_atras     int         NOT NULL        -- 0 = mes en curso, 1 = mes anterior, ...
);
GO
CREATE TABLE demo.DIM_PRODUCTO (
    id_producto        int           NOT NULL CONSTRAINT PK_DEMO_PRODUCTO PRIMARY KEY,
    codigo             varchar(20)   NOT NULL,
    nombre             nvarchar(100) NOT NULL,
    linea_terapeutica  nvarchar(50)  NOT NULL,
    categoria          nvarchar(20)  NOT NULL,    -- Etico | OTC | Generico
    forma_farmaceutica nvarchar(30)  NOT NULL,
    precio_lista       decimal(18,2) NOT NULL     -- precio de lista vigente (los periodos anteriores se calculan hacia atras)
);
GO
CREATE TABLE demo.DIM_CLIENTE (
    id_cliente          int           NOT NULL CONSTRAINT PK_DEMO_CLIENTE PRIMARY KEY,
    nombre              nvarchar(100) NOT NULL,
    tipo_cliente        nvarchar(30)  NOT NULL,   -- Drogueria | Cadena de farmacias | Hospital / Clinica | Obra social | Distribuidor
    provincia           nvarchar(40)  NOT NULL,
    area_comercial      nvarchar(50)  NOT NULL,   -- Comercial Norte | Comercial Sur
    condicion_pago_dias int           NOT NULL,
    limite_credito      decimal(18,2) NOT NULL
);
GO

INSERT INTO demo.DIM_PERIODO (periodo, anio, mes, trimestre, nombre_mes, es_mes_cerrado, meses_atras)
SELECT p.periodo, YEAR(p.periodo), MONTH(p.periodo), (MONTH(p.periodo) - 1) / 3 + 1,
       CHOOSE(MONTH(p.periodo), 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto',
              'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'),
       CASE WHEN m.n = 0 THEN 0 ELSE 1 END, m.n
FROM (SELECT TOP (25) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS n FROM sys.all_objects) m
CROSS APPLY (SELECT DATEADD(MONTH, -m.n, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)) AS periodo) p;
GO

INSERT INTO demo.DIM_PRODUCTO (id_producto, codigo, nombre, linea_terapeutica, categoria, forma_farmaceutica, precio_lista) VALUES
    (1,  'MED-001', N'Amoxicilina 500 mg x 16 comp.',          N'Antibioticos',                    N'Etico',    N'Comprimido', 4200.00),
    (2,  'MED-002', N'Azitromicina 500 mg x 3 comp.',          N'Antibioticos',                    N'Etico',    N'Comprimido', 6100.00),
    (3,  'MED-003', N'Ciprofloxacina 500 mg x 10 comp.',       N'Antibioticos',                    N'Generico', N'Comprimido', 3300.00),
    (4,  'MED-004', N'Cefalexina 500 mg x 12 caps.',           N'Antibioticos',                    N'Generico', N'Capsula',    3800.00),
    (5,  'MED-005', N'Enalapril 10 mg x 30 comp.',             N'Cardiovascular',                  N'Generico', N'Comprimido', 2100.00),
    (6,  'MED-006', N'Losartan 50 mg x 30 comp.',              N'Cardiovascular',                  N'Etico',    N'Comprimido', 3900.00),
    (7,  'MED-007', N'Atorvastatina 20 mg x 30 comp.',         N'Cardiovascular',                  N'Etico',    N'Comprimido', 7400.00),
    (8,  'MED-008', N'Amlodipina 5 mg x 30 comp.',             N'Cardiovascular',                  N'Generico', N'Comprimido', 2400.00),
    (9,  'MED-009', N'Bisoprolol 5 mg x 30 comp.',             N'Cardiovascular',                  N'Etico',    N'Comprimido', 4600.00),
    (10, 'MED-010', N'Salbutamol aerosol 100 mcg x 200 dosis', N'Respiratoria',                    N'Etico',    N'Aerosol',    5200.00),
    (11, 'MED-011', N'Montelukast 10 mg x 28 comp.',           N'Respiratoria',                    N'Etico',    N'Comprimido', 8300.00),
    (12, 'MED-012', N'Ambroxol jarabe 120 ml',                 N'Respiratoria',                    N'OTC',      N'Jarabe',     2800.00),
    (13, 'MED-013', N'Loratadina 10 mg x 10 comp.',            N'Respiratoria',                    N'OTC',      N'Comprimido', 1900.00),
    (14, 'MED-014', N'Ibuprofeno 400 mg x 20 comp.',           N'Analgesicos y antiinflamatorios', N'OTC',      N'Comprimido', 2200.00),
    (15, 'MED-015', N'Paracetamol 500 mg x 30 comp.',          N'Analgesicos y antiinflamatorios', N'OTC',      N'Comprimido', 1700.00),
    (16, 'MED-016', N'Diclofenac 75 mg x 10 amp.',             N'Analgesicos y antiinflamatorios', N'Etico',    N'Inyectable', 3600.00),
    (17, 'MED-017', N'Naproxeno 550 mg x 20 comp.',            N'Analgesicos y antiinflamatorios', N'Generico', N'Comprimido', 3100.00),
    (18, 'MED-018', N'Omeprazol 20 mg x 28 caps.',             N'Gastroenterologia',               N'Generico', N'Capsula',    2900.00),
    (19, 'MED-019', N'Pantoprazol 40 mg x 28 comp.',           N'Gastroenterologia',               N'Etico',    N'Comprimido', 5100.00),
    (20, 'MED-020', N'Domperidona 10 mg x 30 comp.',           N'Gastroenterologia',               N'Generico', N'Comprimido', 2000.00),
    (21, 'MED-021', N'Mebeverina 200 mg x 30 caps.',           N'Gastroenterologia',               N'Etico',    N'Capsula',    4300.00),
    (22, 'MED-022', N'Metformina 850 mg x 60 comp.',           N'Diabetes y metabolismo',          N'Generico', N'Comprimido', 3000.00),
    (23, 'MED-023', N'Glimepirida 4 mg x 30 comp.',            N'Diabetes y metabolismo',          N'Etico',    N'Comprimido', 4800.00),
    (24, 'MED-024', N'Levotiroxina 100 mcg x 50 comp.',        N'Diabetes y metabolismo',          N'Etico',    N'Comprimido', 3500.00),
    (25, 'MED-025', N'Betametasona crema 30 g',                N'Dermatologia',                    N'Etico',    N'Crema',      3700.00),
    (26, 'MED-026', N'Clotrimazol crema 20 g',                 N'Dermatologia',                    N'OTC',      N'Crema',      2300.00),
    (27, 'MED-027', N'Mupirocina unguento 15 g',               N'Dermatologia',                    N'Etico',    N'Unguento',   5600.00),
    (28, 'MED-028', N'Sertralina 50 mg x 30 comp.',            N'Sistema nervioso central',        N'Etico',    N'Comprimido', 6800.00),
    (29, 'MED-029', N'Clonazepam 0.5 mg x 30 comp.',           N'Sistema nervioso central',        N'Etico',    N'Comprimido', 3400.00),
    (30, 'MED-030', N'Pregabalina 75 mg x 28 caps.',           N'Sistema nervioso central',        N'Etico',    N'Capsula',    7900.00);
GO

INSERT INTO demo.DIM_CLIENTE (id_cliente, nombre, tipo_cliente, provincia, area_comercial, condicion_pago_dias, limite_credito) VALUES
    (1,  N'Drogueria Demo Salta',        N'Drogueria',           N'Salta',        N'Comercial Norte', 45, 90000000.00),
    (2,  N'Drogueria Demo Tucuman',      N'Drogueria',           N'Tucuman',      N'Comercial Norte', 45, 80000000.00),
    (3,  N'Drogueria Demo Buenos Aires', N'Drogueria',           N'Buenos Aires', N'Comercial Sur',   30, 150000000.00),
    (4,  N'Drogueria Demo Cordoba',      N'Drogueria',           N'Cordoba',      N'Comercial Norte', 30, 110000000.00),
    (5,  N'Farmacias Demo Centro',       N'Cadena de farmacias', N'CABA',         N'Comercial Sur',   30, 60000000.00),
    (6,  N'Farmacias Demo Litoral',      N'Cadena de farmacias', N'Santa Fe',     N'Comercial Norte', 30, 45000000.00),
    (7,  N'Farmacias Demo Cuyo',         N'Cadena de farmacias', N'Mendoza',      N'Comercial Sur',   30, 40000000.00),
    (8,  N'Farmacias Demo Patagonia',    N'Cadena de farmacias', N'Neuquen',      N'Comercial Sur',   30, 35000000.00),
    (9,  N'Farmacias Demo del Norte',    N'Cadena de farmacias', N'Salta',        N'Comercial Norte', 30, 30000000.00),
    (10, N'Farmacias Demo Barrio',       N'Cadena de farmacias', N'Buenos Aires', N'Comercial Sur',   30, 25000000.00),
    (11, N'Clinica Demo San Martin',     N'Hospital / Clinica',  N'CABA',         N'Comercial Sur',   60, 50000000.00),
    (12, N'Hospital Demo Provincial',    N'Hospital / Clinica',  N'Cordoba',      N'Comercial Norte', 90, 70000000.00),
    (13, N'Sanatorio Demo del Sur',      N'Hospital / Clinica',  N'Buenos Aires', N'Comercial Sur',   60, 55000000.00),
    (14, N'Clinica Demo Tucuman',        N'Hospital / Clinica',  N'Tucuman',      N'Comercial Norte', 60, 40000000.00),
    (15, N'Hospital Demo Regional',      N'Hospital / Clinica',  N'Neuquen',      N'Comercial Sur',   90, 45000000.00),
    (16, N'Sanatorio Demo Rosario',      N'Hospital / Clinica',  N'Santa Fe',     N'Comercial Norte', 60, 48000000.00),
    (17, N'Obra Social Demo A',          N'Obra social',         N'CABA',         N'Comercial Sur',   60, 120000000.00),
    (18, N'Obra Social Demo B',          N'Obra social',         N'Cordoba',      N'Comercial Norte', 75, 100000000.00),
    (19, N'Obra Social Demo C',          N'Obra social',         N'Buenos Aires', N'Comercial Sur',   60, 95000000.00),
    (20, N'Obra Social Demo D',          N'Obra social',         N'Mendoza',      N'Comercial Sur',   90, 85000000.00),
    (21, N'Distribuidora Demo Cuyo',     N'Distribuidor',        N'Mendoza',      N'Comercial Sur',   30, 65000000.00),
    (22, N'Distribuidora Demo NOA',      N'Distribuidor',        N'Tucuman',      N'Comercial Norte', 30, 60000000.00),
    (23, N'Distribuidora Demo Litoral',  N'Distribuidor',        N'Santa Fe',     N'Comercial Norte', 45, 58000000.00),
    (24, N'Distribuidora Demo AMBA',     N'Distribuidor',        N'Buenos Aires', N'Comercial Sur',   30, 75000000.00);
GO

/* ------------------------- costos unitarios (750 filas) ------------------ */
/* Tabla "sensible": el costo unitario por producto y mes. Un rol comercial no deberia alcanzarla. */
CREATE TABLE demo.COSTO_UNITARIO (
    id_producto    int           NOT NULL CONSTRAINT FK_DEMO_CU_PROD REFERENCES demo.DIM_PRODUCTO(id_producto),
    periodo        date          NOT NULL CONSTRAINT FK_DEMO_CU_PER  REFERENCES demo.DIM_PERIODO(periodo),
    costo_unitario decimal(18,2) NOT NULL,
    CONSTRAINT PK_DEMO_COSTO PRIMARY KEY (id_producto, periodo)
);
GO
INSERT INTO demo.COSTO_UNITARIO (id_producto, periodo, costo_unitario)
SELECT p.id_producto, per.periodo,
       CAST(p.precio_lista * (0.40 + (p.id_producto % 6) * 0.05) * (1 - 0.008 * per.meses_atras) AS decimal(18,2))
FROM demo.DIM_PRODUCTO p CROSS JOIN demo.DIM_PERIODO per;
GO

/* ------------------------------ ventas (1500 filas) ---------------------- */
/* Grano: periodo x producto x cliente. Cada producto vende a 2 clientes distintos por mes (seleccion deterministica).
   Precio y costo suben con el tiempo (los periodos viejos son mas baratos); la linea Respiratoria tiene estacionalidad
   (mayo a agosto); las unidades tienen tendencia creciente. El descuento depende del tipo de cliente. */
CREATE TABLE demo.FACT_VENTAS (
    id_venta              int           IDENTITY(1,1) CONSTRAINT PK_DEMO_VENTAS PRIMARY KEY,
    periodo               date          NOT NULL CONSTRAINT FK_DEMO_V_PER  REFERENCES demo.DIM_PERIODO(periodo),
    id_producto           int           NOT NULL CONSTRAINT FK_DEMO_V_PROD REFERENCES demo.DIM_PRODUCTO(id_producto),
    id_cliente            int           NOT NULL CONSTRAINT FK_DEMO_V_CLI  REFERENCES demo.DIM_CLIENTE(id_cliente),
    area                  nvarchar(50)  NOT NULL,           -- area comercial del cliente (para acotar registros por area)
    unidades              int           NOT NULL,
    venta_bruta           decimal(18,2) NOT NULL,
    descuentos            decimal(18,2) NOT NULL,
    venta_neta            decimal(18,2) NOT NULL,
    contribucion_marginal decimal(18,2) NOT NULL,           -- venta neta menos costo de ventas
    CONSTRAINT UQ_DEMO_VENTAS UNIQUE (periodo, id_producto, id_cliente)
);
GO
INSERT INTO demo.FACT_VENTAS (periodo, id_producto, id_cliente, area, unidades, venta_bruta, descuentos, venta_neta, contribucion_marginal)
SELECT per.periodo, p.id_producto, c.id_cliente, c.area_comercial, u.unidades, b.venta_bruta, d.descuentos,
       b.venta_bruta - d.descuentos,
       (b.venta_bruta - d.descuentos) - CAST(u.unidades * cu.costo_unitario AS decimal(18,2))
FROM demo.DIM_PERIODO per
CROSS JOIN demo.DIM_PRODUCTO p
CROSS JOIN (SELECT 0 AS j UNION ALL SELECT 1) sel
JOIN demo.DIM_CLIENTE c ON c.id_cliente = ((p.id_producto * 7 + per.meses_atras * 3 + sel.j * 5) % 24) + 1
JOIN demo.COSTO_UNITARIO cu ON cu.id_producto = p.id_producto AND cu.periodo = per.periodo
CROSS APPLY (SELECT 40 + (ABS(CHECKSUM(p.id_producto * 100 + c.id_cliente, per.meses_atras)) % 120)
                        + (24 - per.meses_atras) * 2
                        + CASE WHEN p.linea_terapeutica = N'Respiratoria' AND per.mes IN (5, 6, 7, 8) THEN 60 ELSE 0 END AS unidades) u
CROSS APPLY (SELECT CAST(u.unidades * p.precio_lista * (1 - 0.01 * per.meses_atras) AS decimal(18,2)) AS venta_bruta,
                    CASE c.tipo_cliente WHEN N'Drogueria' THEN 0.18 WHEN N'Cadena de farmacias' THEN 0.12
                                        WHEN N'Hospital / Clinica' THEN 0.08 WHEN N'Obra social' THEN 0.22 ELSE 0.15 END AS pct) b
CROSS APPLY (SELECT CAST(b.venta_bruta * b.pct AS decimal(18,2)) AS descuentos) d;
GO

/* ----------------------- P&L por producto (1500 filas) ------------------- */
/* Escenario Real = suma de FACT_VENTAS por periodo y producto (coincide con ella) mas las lineas de gasto.
   Escenario Presupuesto = el real multiplicado por un factor entre 0.92 y 1.08 (para comparar real contra presupuesto).
   Estructura del estado de resultados:
     venta bruta - descuentos = venta neta
     venta neta - costo de ventas (materia prima + mano de obra + fabricacion) = contribucion marginal
     contribucion marginal - gastos comerciales - marketing - distribucion - estructura = resultado operativo */
CREATE TABLE demo.FACT_PYL_PRODUCTO (
    id_pyl               int           IDENTITY(1,1) CONSTRAINT PK_DEMO_PYL PRIMARY KEY,
    periodo              date          NOT NULL CONSTRAINT FK_DEMO_PYL_PER  REFERENCES demo.DIM_PERIODO(periodo),
    id_producto          int           NOT NULL CONSTRAINT FK_DEMO_PYL_PROD REFERENCES demo.DIM_PRODUCTO(id_producto),
    escenario            nvarchar(12)  NOT NULL,          -- Real | Presupuesto
    unidades             int           NOT NULL,
    venta_bruta          decimal(18,2) NOT NULL,
    descuentos           decimal(18,2) NOT NULL,
    venta_neta           decimal(18,2) NOT NULL,
    costo_materia_prima  decimal(18,2) NOT NULL,
    costo_mano_obra      decimal(18,2) NOT NULL,
    costo_fabricacion    decimal(18,2) NOT NULL,
    costo_ventas         decimal(18,2) NOT NULL,
    contribucion_marginal decimal(18,2) NOT NULL,
    gastos_comerciales   decimal(18,2) NOT NULL,
    gastos_marketing     decimal(18,2) NOT NULL,
    gastos_distribucion  decimal(18,2) NOT NULL,
    gastos_estructura    decimal(18,2) NOT NULL,
    resultado_operativo  decimal(18,2) NOT NULL,
    CONSTRAINT UQ_DEMO_PYL UNIQUE (periodo, id_producto, escenario)
);
GO
INSERT INTO demo.FACT_PYL_PRODUCTO (periodo, id_producto, escenario, unidades, venta_bruta, descuentos, venta_neta,
    costo_materia_prima, costo_mano_obra, costo_fabricacion, costo_ventas, contribucion_marginal,
    gastos_comerciales, gastos_marketing, gastos_distribucion, gastos_estructura, resultado_operativo)
SELECT v.periodo, v.id_producto, e.escenario, a.unidades, a.venta_bruta, a.venta_bruta - a.venta_neta, a.venta_neta,
       c.mp, c.mo, a.costo_ventas - c.mp - c.mo, a.costo_ventas,
       a.venta_neta - a.costo_ventas,
       g.comerciales, g.marketing, g.distribucion, g.estructura,
       (a.venta_neta - a.costo_ventas) - g.comerciales - g.marketing - g.distribucion - g.estructura
FROM (SELECT f.periodo, f.id_producto, SUM(f.unidades) AS unidades, SUM(f.venta_bruta) AS venta_bruta,
             SUM(f.venta_neta) AS venta_neta, SUM(f.venta_neta) - SUM(f.contribucion_marginal) AS costo_ventas
      FROM demo.FACT_VENTAS f GROUP BY f.periodo, f.id_producto) v
JOIN demo.DIM_PRODUCTO p ON p.id_producto = v.id_producto
CROSS JOIN (VALUES (N'Real'), (N'Presupuesto')) AS e(escenario)
CROSS APPLY (SELECT CASE e.escenario WHEN N'Real' THEN CAST(1.0 AS decimal(9,4))
                    ELSE CAST(0.92 + (ABS(CHECKSUM(v.id_producto, DATEDIFF(MONTH, v.periodo, GETDATE()))) % 17) / 100.0 AS decimal(9,4)) END AS k) q
CROSS APPLY (SELECT CAST(v.unidades * q.k AS int) AS unidades,
                    CAST(v.venta_bruta * q.k AS decimal(18,2)) AS venta_bruta,
                    CAST(v.venta_neta * q.k AS decimal(18,2)) AS venta_neta,
                    CAST(v.costo_ventas * q.k AS decimal(18,2)) AS costo_ventas) a
CROSS APPLY (SELECT CAST(a.costo_ventas * 0.55 AS decimal(18,2)) AS mp,
                    CAST(a.costo_ventas * 0.20 AS decimal(18,2)) AS mo) c
CROSS APPLY (SELECT CAST(a.venta_neta * (0.05 + (p.id_producto % 4) * 0.005) AS decimal(18,2)) AS comerciales,
                    CAST(a.venta_neta * CASE p.categoria WHEN N'Etico' THEN 0.09 WHEN N'OTC' THEN 0.12 ELSE 0.02 END AS decimal(18,2)) AS marketing,
                    CAST(a.venta_neta * 0.025 AS decimal(18,2)) AS distribucion,
                    CAST(a.venta_neta * 0.04 AS decimal(18,2)) AS estructura) g;
GO

/* ----------------------------- almacenes (7 filas) ------------------------ */
/* El stock se guarda en ALMACENES, no en clientes. Hay almacenes propios y almacenes en consignacion, que son depositos
   ubicados en una drogueria: ahi la drogueria es la titular del lugar (id_cliente), pero la mercaderia sigue siendo del laboratorio. */
CREATE TABLE demo.DIM_ALMACEN (
    id_almacen      int           NOT NULL CONSTRAINT PK_DEMO_ALMACEN PRIMARY KEY,
    nombre          nvarchar(100) NOT NULL,
    tipo_almacen    nvarchar(20)  NOT NULL,       -- Propio | Consignacion
    id_cliente      int           NULL CONSTRAINT FK_DEMO_AL_CLI REFERENCES demo.DIM_CLIENTE(id_cliente),   -- drogueria titular (solo Consignacion)
    provincia       nvarchar(40)  NOT NULL,
    area_comercial  nvarchar(50)  NOT NULL
);
GO
INSERT INTO demo.DIM_ALMACEN (id_almacen, nombre, tipo_almacen, id_cliente, provincia, area_comercial) VALUES
    (1, N'Almacen Demo Central',                  N'Propio',       NULL, N'Buenos Aires', N'Comercial Sur'),
    (2, N'Almacen Demo Distribucion Norte',       N'Propio',       NULL, N'Cordoba',      N'Comercial Norte'),
    (3, N'Almacen Demo Distribucion Sur',         N'Propio',       NULL, N'Neuquen',      N'Comercial Sur'),
    (4, N'Consignacion Drogueria Demo Salta',     N'Consignacion', 1,    N'Salta',        N'Comercial Norte'),
    (5, N'Consignacion Drogueria Demo Tucuman',   N'Consignacion', 2,    N'Tucuman',      N'Comercial Norte'),
    (6, N'Consignacion Drogueria Demo Buenos Aires', N'Consignacion', 3, N'Buenos Aires', N'Comercial Sur'),
    (7, N'Consignacion Drogueria Demo Cordoba',   N'Consignacion', 4,    N'Cordoba',      N'Comercial Norte');
GO

/* ------------------------- stock por almacen (2520 filas) ----------------- */
/* Stock de cierre mensual de cada producto en cada almacen, 12 cierres (el mes en curso no tiene cierre).
   Los almacenes propios guardan mas unidades y ademas tienen mercaderia en cuarentena (pendiente de liberacion de calidad);
   la cuarentena no esta disponible para la venta. El valor se expresa a precio de lista. */
CREATE TABLE demo.FACT_STOCK_ALMACEN (
    id_stock               int           IDENTITY(1,1) CONSTRAINT PK_DEMO_STOCK PRIMARY KEY,
    periodo                date          NOT NULL CONSTRAINT FK_DEMO_S_PER  REFERENCES demo.DIM_PERIODO(periodo),
    fecha                  date          NOT NULL,                  -- ultimo dia del mes (cierre)
    id_almacen             int           NOT NULL CONSTRAINT FK_DEMO_S_ALM  REFERENCES demo.DIM_ALMACEN(id_almacen),
    id_producto            int           NOT NULL CONSTRAINT FK_DEMO_S_PROD REFERENCES demo.DIM_PRODUCTO(id_producto),
    area                   nvarchar(50)  NOT NULL,                  -- area comercial del almacen (para acotar registros por area)
    unidades_disponibles   int           NOT NULL,
    unidades_cuarentena    int           NOT NULL,
    valor_precio_lista     decimal(18,2) NOT NULL,                  -- (disponibles + cuarentena) a precio de lista del periodo
    CONSTRAINT UQ_DEMO_STOCK UNIQUE (periodo, id_almacen, id_producto)
);
GO
INSERT INTO demo.FACT_STOCK_ALMACEN (periodo, fecha, id_almacen, id_producto, area, unidades_disponibles, unidades_cuarentena, valor_precio_lista)
SELECT per.periodo, EOMONTH(per.periodo), a.id_almacen, p.id_producto, a.area_comercial, u.disp, u.cuar,
       CAST((u.disp + u.cuar) * p.precio_lista * (1 - 0.01 * per.meses_atras) AS decimal(18,2))
FROM demo.DIM_PERIODO per
CROSS JOIN demo.DIM_PRODUCTO p
CROSS JOIN demo.DIM_ALMACEN a
CROSS APPLY (SELECT CASE a.tipo_almacen
                      WHEN N'Propio' THEN 400 + (ABS(CHECKSUM(p.id_producto, a.id_almacen, per.meses_atras)) % 1200) + (p.id_producto % 5) * 60
                      ELSE 30 + (ABS(CHECKSUM(p.id_producto, a.id_almacen, per.meses_atras)) % 250) + (p.id_producto % 5) * 20 END AS disp,
                    CASE a.tipo_almacen
                      WHEN N'Propio' THEN ABS(CHECKSUM(p.id_producto, a.id_almacen, per.meses_atras + 100)) % 80
                      ELSE 0 END AS cuar) u
WHERE per.meses_atras BETWEEN 1 AND 12;
GO

/* ------------------- cuenta corriente (~1260 filas) ---------------------- */
/* Una factura por cliente y mes cerrado (= venta neta del cliente + 21 % de IVA), vencimiento segun la condicion de pago;
   un recibo en la fecha de vencimiento por entre el 85 % y el 100 % de la factura (queda saldo); y una nota de credito
   del 3 % en una de cada cuatro facturas. Solo se generan movimientos con fecha hasta hoy.
   Saldo de un cliente = suma de debe menos suma de haber. */
CREATE TABLE demo.FACT_CUENTA_CORRIENTE (
    id_movimiento     int           IDENTITY(1,1) CONSTRAINT PK_DEMO_CC PRIMARY KEY,
    periodo           date          NOT NULL CONSTRAINT FK_DEMO_CC_PER REFERENCES demo.DIM_PERIODO(periodo),
    fecha             date          NOT NULL,
    id_cliente        int           NOT NULL CONSTRAINT FK_DEMO_CC_CLI REFERENCES demo.DIM_CLIENTE(id_cliente),
    area              nvarchar(50)  NOT NULL,
    tipo_comprobante  nvarchar(20)  NOT NULL,        -- Factura | Recibo | Nota de credito
    comprobante       varchar(30)   NOT NULL,
    comprobante_ref   varchar(30)   NULL,            -- factura a la que se aplica un recibo o una nota de credito
    fecha_vencimiento date          NULL,            -- solo facturas
    debe              decimal(18,2) NOT NULL,
    haber             decimal(18,2) NOT NULL
);
GO
INSERT INTO demo.FACT_CUENTA_CORRIENTE (periodo, fecha, id_cliente, area, tipo_comprobante, comprobante, comprobante_ref, fecha_vencimiento, debe, haber)
SELECT v.periodo, EOMONTH(v.periodo), v.id_cliente, c.area_comercial, N'Factura',
       CONCAT('FAC-', CONVERT(char(6), v.periodo, 112), '-', RIGHT('00' + CAST(v.id_cliente AS varchar(3)), 3)), NULL,
       DATEADD(DAY, c.condicion_pago_dias, EOMONTH(v.periodo)),
       CAST(v.venta_neta * 1.21 AS decimal(18,2)), 0
FROM (SELECT f.periodo, f.id_cliente, SUM(f.venta_neta) AS venta_neta
      FROM demo.FACT_VENTAS f
      JOIN demo.DIM_PERIODO per ON per.periodo = f.periodo AND per.es_mes_cerrado = 1
      GROUP BY f.periodo, f.id_cliente) v
JOIN demo.DIM_CLIENTE c ON c.id_cliente = v.id_cliente;
GO
INSERT INTO demo.FACT_CUENTA_CORRIENTE (periodo, fecha, id_cliente, area, tipo_comprobante, comprobante, comprobante_ref, fecha_vencimiento, debe, haber)
SELECT DATEFROMPARTS(YEAR(f.fecha_vencimiento), MONTH(f.fecha_vencimiento), 1), f.fecha_vencimiento, f.id_cliente, f.area,
       N'Recibo', REPLACE(f.comprobante, 'FAC-', 'REC-'), f.comprobante, NULL, 0,
       CAST(f.debe * (0.85 + (ABS(CHECKSUM(f.id_cliente, MONTH(f.fecha), YEAR(f.fecha))) % 16) / 100.0) AS decimal(18,2))
FROM demo.FACT_CUENTA_CORRIENTE f
WHERE f.tipo_comprobante = N'Factura' AND f.fecha_vencimiento <= CAST(GETDATE() AS date);
GO
INSERT INTO demo.FACT_CUENTA_CORRIENTE (periodo, fecha, id_cliente, area, tipo_comprobante, comprobante, comprobante_ref, fecha_vencimiento, debe, haber)
SELECT DATEFROMPARTS(YEAR(DATEADD(DAY, 10, f.fecha)), MONTH(DATEADD(DAY, 10, f.fecha)), 1), DATEADD(DAY, 10, f.fecha), f.id_cliente, f.area,
       N'Nota de credito', REPLACE(f.comprobante, 'FAC-', 'NCR-'), f.comprobante, NULL, 0, CAST(f.debe * 0.03 AS decimal(18,2))
FROM demo.FACT_CUENTA_CORRIENTE f
WHERE f.tipo_comprobante = N'Factura' AND (f.id_cliente + MONTH(f.fecha)) % 4 = 0
  AND DATEADD(DAY, 10, f.fecha) <= CAST(GETDATE() AS date);
GO

/* Usuario de solo lectura sobre el esquema demo (el instalador reemplaza la clave) */
USE [master];
GO
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'asistente_dwh_ro')
    CREATE LOGIN [asistente_dwh_ro] WITH PASSWORD = N'$(DWH_PASSWORD)', CHECK_POLICY = ON;
GO
USE [$(DEMO_DB)];
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'asistente_dwh_ro')
    CREATE USER [asistente_dwh_ro] FOR LOGIN [asistente_dwh_ro];
GO
GRANT SELECT, VIEW DEFINITION ON SCHEMA::demo TO [asistente_dwh_ro];
GO
