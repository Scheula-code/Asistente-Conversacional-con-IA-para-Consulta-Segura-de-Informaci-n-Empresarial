/* ============================================================================
   01 - Crea la base propia del prototipo y el login de la aplicacion.
   Se ejecuta en el SQL Server que la organizacion ya administra (base master).
   Variables de sqlcmd:  $(APP_DB)        nombre de la base       (ej. ASISTENTE_IA)
                         $(APP_PASSWORD)  clave del login asistente_app
   Lo normal es correrlo con:  python -m scripts.instalar_base
   ============================================================================ */

IF DB_ID(N'$(APP_DB)') IS NULL
    CREATE DATABASE [$(APP_DB)] COLLATE Latin1_General_CI_AS;
GO

IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'asistente_app')
    CREATE LOGIN [asistente_app] WITH PASSWORD = N'$(APP_PASSWORD)', CHECK_POLICY = ON;
GO

USE [$(APP_DB)];
GO

IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'asistente_app')
    CREATE USER [asistente_app] FOR LOGIN [asistente_app];
GO
