/* ============================================================================
   06 - MIGRACION: agrega DOCUMENTO.resumen a una base TFG_ASISTENTE ya creada (sin borrar nada).
   Ejecutar en la base TFG_ASISTENTE:
       sqlcmd -S "(localdb)\\MSSQLLocalDB" -E -d TFG_ASISTENTE -i 06_migracion_resumen.sql
   Es idempotente. Si se recrea la base con recrear_todo_*.sql, la columna ya viene incluida.
   ============================================================================ */
IF COL_LENGTH(N'dbo.DOCUMENTO', N'resumen') IS NULL
    ALTER TABLE dbo.DOCUMENTO ADD resumen nvarchar(max) NULL;
GO
