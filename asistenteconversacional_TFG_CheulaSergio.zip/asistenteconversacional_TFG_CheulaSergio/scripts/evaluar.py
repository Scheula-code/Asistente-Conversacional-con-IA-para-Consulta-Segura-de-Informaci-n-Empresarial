"""Corre un conjunto de preguntas como un usuario y mide tiempo y estado (objetivos especificos 1, 2 y 4).

  python -m scripts.evaluar --usuario ana@empresa.com --preguntas datos_prueba/preguntas_demo.jsonl --salida resultados.csv

Cada linea del .jsonl: {"id": "D01", "tipo": "documental|datos|mixta", "pregunta": "...", "referencia": "..."}
El script NO decide si la respuesta es correcta: deja la respuesta, la fuente y las citas para que el
referente la compare con la de referencia (el documento exige validacion humana).
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time

from app import orquestador, repo
from app.security.auth import Contexto


def contexto_de(email: str) -> Contexto:
    u = repo.usuario_por_email(email)
    if not u:
        raise SystemExit(f"No existe el usuario {email}")
    roles = repo.roles_de_usuario(u["id_usuario"])
    return Contexto(0, u["id_usuario"], u["nombre"], u["email"], u["area"], tuple(r["id_rol"] for r in roles),
                    tuple(r["codigo"] for r in roles), False, "evaluacion")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--usuario", required=True)
    ap.add_argument("--preguntas", required=True)
    ap.add_argument("--salida", default="resultados_evaluacion.csv")
    a = ap.parse_args()
    ctx = contexto_de(a.usuario)
    filas = []
    with open(a.preguntas, encoding="utf-8") as f:
        for linea in f:
            if not linea.strip():
                continue
            q = json.loads(linea)
            t0 = time.perf_counter()
            try:
                r = orquestador.responder(ctx, q["pregunta"], None)
                fila = [q.get("id"), q.get("tipo"), q["pregunta"], r.fuente, r.estado, int((time.perf_counter() - t0) * 1000),
                        r.texto, "; ".join(f"{c['codigo']} v{c['version']}" for c in r.citas),
                        (r.datos or {}).get("sql") or "", q.get("referencia", "")]
            except Exception as e:
                fila = [q.get("id"), q.get("tipo"), q["pregunta"], "", "excepcion", int((time.perf_counter() - t0) * 1000), str(e), "", "", ""]
            filas.append(fila)
            print(fila[0], fila[3], fila[4], f"{fila[5]} ms")
    with open(a.salida, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["id", "tipo_esperado", "pregunta", "fuente", "estado", "duracion_ms", "respuesta", "citas", "sql", "referencia"])
        w.writerows(filas)
    print(f"\n{len(filas)} preguntas. Resultado en {a.salida}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
