"""Reconstruye el indice vectorial desde los PDF guardados.   python -m scripts.reindexar --todo"""
from __future__ import annotations

import argparse
import sys

from app.rag import servicio


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--todo", action="store_true", required=True)
    ap.parse_args()
    r = servicio.reindexar_todo(None)
    print(f"Indexados: {r['indexados']}")
    for e in r["errores"]:
        print("  ERROR:", e)
    return 1 if r["errores"] else 0


if __name__ == "__main__":
    sys.exit(main())
